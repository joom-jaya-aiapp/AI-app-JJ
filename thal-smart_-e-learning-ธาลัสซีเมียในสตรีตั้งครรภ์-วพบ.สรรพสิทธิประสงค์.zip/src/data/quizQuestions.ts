import { QuizQuestion } from '../types';
import { quizQuestionsPart1 } from './quizQuestionsPart1';
import { quizQuestionsPart2 } from './quizQuestionsPart2';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  ...quizQuestionsPart1,
  ...quizQuestionsPart2,
];
