export interface KnowledgeSection {
  id: string;
  title: string;
  subtitle: string;
  gate?: 'gate1_match' | 'gate2_pregnancy' | 'gate3_birth' | 'foundation';
  iconName: string;
  summary: string;
  keyPoints: string[];
  clinicalRelevance: string;
  contentHtml: string;
  tableData?: {
    headers: string[];
    rows: (string | number)[][];
  };
}

export const KNOWLEDGE_SECTIONS: KnowledgeSection[] = [
  {
    id: 'epidemiology',
    title: 'ระบาดวิทยาและสถานการณ์ธาลัสซีเมียในประเทศไทย',
    subtitle: 'ข้อมูลสถิติประเทศและบริบทภาคอีสาน (สอดคล้องกับพื้นที่บริการ วพบ.สรรพสิทธิประสงค์)',
    gate: 'foundation',
    iconName: 'MapPin',
    summary: 'ประเทศไทยมีประชากรกว่า 71.6 ล้านคน โดย 1 ใน 3 (ประมาณ 30-40%) มีพาหะธาลัสซีเมียแฝง และมีผู้ป่วยโรคธาลัสซีเมียประมาณ 1% ทารกแรกเกิดเป็นโรคปีละ 12,500 ราย',
    keyPoints: [
      'ประชากรไทย 1 ใน 3 มีพาหะธาลัสซีเมียแฝง (30-40%)',
      'ในสตรีตั้งครรภ์ 10,000 ราย มีโอกาสมีบุตรเป็นโรคธาลัสซีเมียชนิดรุนแรง 500-600 ราย',
      'ภาคตะวันออกเฉียงเหนือ (อีสาน) พบความชุกของ Hb E สูงที่สุดในประเทศ ถึงร้อยละ 20-60%',
      'ภาคเหนือพบ α-thal trait สูงถึง 30% และ β-thal trait 9-10%',
      'ค่าใช้จ่ายในการดูแลรักษาผู้ป่วยชนิดรุนแรงตลอดอายุขัย 1.26 - 6.68 ล้านบาทต่อคน (เฉลี่ย 10,550 บาท/เดือน)',
      'กระทรวงสาธารณสุขใช้งบประมาณดูแลผู้ป่วยธาลัสซีเมียปีละกว่า 700 ล้านบาท',
    ],
    clinicalRelevance: 'นักศึกษาพยาบาลในเขตสุขภาพที่ 10 (อุบลราชธานี ศรีสะเกษ ยโสธร อำนาจเจริญ มุกดาหาร) จะพบหญิงตั้งครรภ์และคู่สมรสที่มี Hb E และ α-thalassemia สูงมาก จึงต้องเชี่ยวชาญการคัดกรองคู่เสี่ยงชนิดรุนแรง',
    contentHtml: `
      <p class="mb-3">โรคโลหิตจางธาลัสซีเมียเป็นปัญหาสาธารณสุขที่สำคัญของประเทศไทย นโยบายระดับชาติจึงมุ่งเน้น <strong>การป้องกันและควบคุมไม่ให้มีผู้ป่วยรายใหม่ที่เกิดเป็นโรคธาลัสซีเมียชนิดรุนแรง 3 โรค</strong> ควบคู่กับการดูแลผู้ป่วยเดิมให้มีคุณภาพชีวิตดีที่สุด</p>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 my-4 text-sm">
        <div class="p-3 bg-pink-50 rounded-lg border border-pink-200">
          <h4 class="font-bold text-pink-900 mb-1">ความชุกในภาคอีสาน (วพบ.สรรพสิทธิประสงค์)</h4>
          <ul class="list-disc pl-5 space-y-1 text-slate-700">
            <li>Hb E trait: 20 - 60% (สูงที่สุดในประเทศ)</li>
            <li>α-thalassemia trait: 20%</li>
            <li>β-thalassemia trait: 6%</li>
          </ul>
        </div>
        <div class="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <h4 class="font-bold text-blue-900 mb-1">3 โรคเป้าหมายรุนแรงระดับชาติ</h4>
          <ol class="list-decimal pl-5 space-y-1 text-slate-700">
            <li>Hb Bart's hydrops fetalis (เสียชีวิตในครรภ์/แรกคลอด)</li>
            <li>Homozygous β-thalassemia (ซีดรุนแรง พึ่งพาเลือด)</li>
            <li>β-thalassemia / Hb E (พบมากที่สุดในอีสาน)</li>
          </ol>
        </div>
      </div>
    `,
    tableData: {
      headers: ['ภาค', 'α-thal trait', 'β-thal trait', 'Hb E trait'],
      rows: [
        ['ภาคอีสาน', '20%', '6%', '20 - 60%'],
        ['ภาคเหนือ', '30%', '9 - 10%', '8%'],
        ['ภาคกลาง', '20 - 25%', '3%', '13 - 19%'],
        ['ภาคใต้', '16%', '2 - 4%', '9 - 11%'],
      ],
    },
  },
  {
    id: 'pathophysiology',
    title: 'โครงสร้างฮีโมโกลบิน พันธุศาสตร์ และพยาธิสรีรวิทยา',
    subtitle: 'Autosomal Recessive, Globin Chains balance, และ Ineffective Erythropoiesis',
    gate: 'foundation',
    iconName: 'Dna',
    summary: 'ฮีโมโกลบินปกติประกอบด้วย Heme 1 หน่วย และ 4 Globin chains รวมเป็น Tetramer โดยยีนควบคุมสายแอลฟ่าอยู่บนโครโมโซมคู่ที่ 16 และสายเบต้าอยู่บนโครโมโซมคู่ที่ 11',
    keyPoints: [
      'Hb ผู้ใหญ่ปกติ: Hb A (α2β2) > 97%, Hb A2 (α2δ2) ไม่เกิน 3.5%, Hb F (α2γ2) 0.5-1%',
      'Hb ทารกในครรภ์: Hb F (α2γ2) เด่นชัด ค่อยๆ ถูกแทนที่ด้วย Hb A เมื่อครบอายุ 1 ปี',
      'ยีน α-globin มี 4 ยีน (โครโมโซม 16 แขนสั้น ข้างละ 2 ยีน: αα/αα)',
      'ยีน β-globin มี 2 ยีน (โครโมโซม 11 แขนสั้น ข้างละ 1 ยีน: β/β)',
      'พยาธิสรีรวิทยา: เมื่อสายโกลบินสายใดสายหนึ่งขาดหายไป อีกสายที่เหลือจะเกินและจับตัวตกตะกอนในตัวอ่อนเม็ดเลือดแดงในไขกระดูก เกิด Ineffective Erythropoiesis และ Apoptosis',
      'เม็ดเลือดแดงตัวแก่แตกง่ายเรื้อรัง (Chronic Hemolysis) ส่งผลให้ตับม้ามโต และไขกระดูกขยายตัวผิดปกติ (Thalassemia facies)',
    ],
    clinicalRelevance: 'การขาดสมดุลของสายโกลบินเป็นตัวกำหนดความรุนแรง หากขาดสายอัลฟ่าทั้งหมดจะเกิด γ4 (Hb Bart\'s) ซึ่งจับออกซิเจนแน่นแต่ไม่ยอมปล่อยให้เนื้อเยื่อ ทารกจึงขาดออกซิเจนขั้นรุนแรงจนบวมน้ำและหัวใจล้มเหลว',
    contentHtml: `
      <p class="mb-3">การถ่ายทอดเป็นแบบ <strong>Autosomal Recessive (ยีนด้อยบนโครโมโซมร่างกาย)</strong>:</p>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3 my-3 text-center text-sm">
        <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
          <div class="font-bold text-emerald-800">คนปกติ (Normal)</div>
          <div class="text-xs text-slate-600 mt-1">ยีนสมบูรณ์ครบถ้วน ไม่มียีนกลายพันธุ์</div>
        </div>
        <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <div class="font-bold text-amber-800">พาหะ (Carrier / Trait)</div>
          <div class="text-xs text-slate-600 mt-1">มียีนผิดปกติ 1 ชุด สุขภาพปกติ แต่ถ่ายทอดสู่ลูกได้</div>
        </div>
        <div class="p-3 bg-rose-50 border border-rose-200 rounded-lg">
          <div class="font-bold text-rose-800">ผู้ป่วย (Disease)</div>
          <div class="text-xs text-slate-600 mt-1">มียีนผิดปกติทั้ง 2 ชุด แสดงอาการโลหิตจาง</div>
        </div>
      </div>
    `,
  },
  {
    id: 'gate1_screening',
    title: 'ประตูที่ 1: "เลือกคู่" และการตรวจคัดกรองพาหะ (Screening & Premarital)',
    subtitle: 'เกณฑ์ Cut-off MCV, MCH, DCIP, OF และอัลกอริทึมของกระทรวงสาธารณสุข',
    gate: 'gate1_match',
    iconName: 'HeartHandshake',
    summary: 'การค้นหาคู่เสี่ยงเริ่มตั้งแต่ระยะก่อนสมรส หรือขณะมาฝากครรภ์ครั้งแรก (First ANC) ทันที โดยตรวจคัดกรองคู่สมรสพร้อมกัน',
    keyPoints: [
      'ตรวจดัชนีเม็ดเลือดแดง: MCV < 80 fL หรือ MCH < 27 pg ถือว่าผิดปกติ (Microcytosis)',
      'One tube Osmotic Fragility Test (OF): ให้ผลบวกใน α-thalassemia และ β-thalassemia',
      'DCIP precipitation test หรือ Hb E screen: ให้ผลบวกใน Hb E trait, Homozygous Hb E, β-thal/Hb E และ Hb H',
      'คู่ที่มีผลคัดกรองเป็นบวก (แม้เพียงฝ่ายใดฝ่ายหนึ่ง) ต้องตรวจยืนยันด้วย Hb typing ทันที',
      'หาก Hb typing เป็น A2A ปกติ (A2 < 3.5%) แต่ MCV < 80 fL ต้องส่งตรวจ PCR for α-thalassemia 1 เสมอ',
      'คู่เสี่ยงสูง 3 โรค: (1) α-thal 1 + α-thal 1 (2) β-thal trait + β-thal trait (3) β-thal trait + Hb E trait/Homozygous Hb E',
    ],
    clinicalRelevance: 'บทบาทพยาบาลคือการชี้แจงความสำคัญของการตรวจคู่สมรส หากตรวจเฉพาะหญิงตั้งครรภ์ฝ่ายเดียวจะไม่สามารถบอกความเสี่ยงของลูกได้',
    contentHtml: `
      <div class="p-4 bg-sky-50 rounded-xl border border-sky-200 mb-4">
        <h4 class="font-bold text-sky-900 mb-2">ตารางสรุปเกณฑ์คัดกรอง (Screening Cut-offs)</h4>
        <div class="overflow-x-auto">
          <table class="w-full text-xs text-left">
            <thead class="bg-sky-100 text-sky-900 uppercase">
              <tr>
                <th class="p-2">ชนิดการตรวจ</th>
                <th class="p-2">ใช้คัดกรอง</th>
                <th class="p-2">เกณฑ์ตัดสิน (Cut-off)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-sky-200 text-slate-700">
              <tr><td class="p-2 font-medium">MCV</td><td class="p-2">α-trait, β-trait (เกือบ 100%), Hb E (60-70%)</td><td class="p-2 text-rose-600 font-bold">&le; 80 fL</td></tr>
              <tr><td class="p-2 font-medium">MCH</td><td class="p-2">α-trait, β-trait (เกือบ 100%), Hb E (60-70%)</td><td class="p-2 text-rose-600 font-bold">&le; 26 - 27 pg</td></tr>
              <tr><td class="p-2 font-medium">DCIP</td><td class="p-2">Unstable Hb, Hb E, Hb H</td><td class="p-2 text-rose-600 font-bold">Positive (+)</td></tr>
              <tr><td class="p-2 font-medium">Hb A2</td><td class="p-2">β-thalassemia trait</td><td class="p-2 text-rose-600 font-bold">4 - 10% (&gt;3.5%)</td></tr>
              <tr><td class="p-2 font-medium">PCR α-thal 1</td><td class="p-2">α-thalassemia 1 (SEA, THAI deletion)</td><td class="p-2 text-rose-600 font-bold">Positive (+)</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `,
  },
  {
    id: 'gate2_pregnancy',
    title: 'ประตูที่ 2: "เลือกครรภ์" และการตรวจวินิจฉัยก่อนคลอด (PND & Counseling)',
    subtitle: 'หัตถการ PND, ข้อจำกัด, ความเสี่ยง และหลักการให้คำปรึกษาทางพันธุศาสตร์',
    gate: 'gate2_pregnancy',
    iconName: 'Baby',
    summary: 'เมื่อคู่สมรสได้รับการยืนยันว่าเป็น "คู่เสี่ยงสูง" ต่อ 3 โรครุนแรง จะต้องเข้าสู่กระบวนการให้คำปรึกษาและเลือกตรวจวินิจฉัยทารกในครรภ์ (Prenatal Diagnosis: PND)',
    keyPoints: [
      'Chorionic Villus Sampling (CVS): ทำที่อายุครรภ์ 9-12 สัปดาห์ เสี่ยงแท้ง 3-5% ตรวจ DNA analysis',
      'Amniocentesis (เจาะน้ำคร่ำ): ทำที่อายุครรภ์ 16-18 สัปดาห์ เสี่ยงแท้งต่ำเพียง 0.3-0.5% ตรวจ DNA analysis',
      'Cordocentesis (เจาะเลือดสายสะดือ): ทำที่อายุครรภ์ 18-22 สัปดาห์ เสี่ยงแท้ง 2-3% ตรวจ Hb typing (HPLC) ทราบผลรวดเร็ว',
      'Serial Ultrasound: ติดตามทุก 2-4 สัปดาห์ ตั้งแต่อายุครรภ์ 20 สัปดาห์ขึ้นไป ดูสัญญาณบวมน้ำ (Hydrops), รกหนาตัว (Placentomegaly), หัวใจโต ในกลุ่มเสี่ยง Hb Bart’s',
      'หลักการให้คำปรึกษา: แจ้งผลพร้อมกันทั้งสองฝ่ายในห้องที่เป็นส่วนตัว, ให้เวลาอยู่ตามลำพัง, ประคับประคองจิตใจ "ไม่ใช่ความผิดของฝ่ายใด แต่เกิดจากธรรมชาติ", ไม่ชี้นำการตัดสินใจ',
      'ทางเลือกเมื่อทารกเป็นโรครุนแรง: ยุติการตั้งครรภ์ (Termination of Pregnancy) หรือ ตั้งครรภ์ต่อไป (Continue Pregnancy) ภายใต้การดูแลร่วมกับสูติแพทย์',
    ],
    clinicalRelevance: 'พยาบาลเป็นผู้สนับสนุนทางอารมณ์และข้อมูล ห้ามพูดในเชิงตำหนิหรือเปรียบเทียบ และต้องอธิบายอัตราความเสี่ยงให้ชัดเจน เช่น 25% หมายถึงในทุกการตั้งครรภ์แต่ละครั้ง ไม่ใช่มีลูก 4 คนแล้วเป็นคนเดียว',
    contentHtml: `
      <div class="space-y-4 text-sm">
        <div class="p-3 bg-pink-50 border-l-4 border-pink-500 rounded-r-lg">
          <h5 class="font-bold text-pink-900">กระบวนการแจ้งผลและการให้คำปรึกษา (Genetic Counseling Protocol)</h5>
          <ol class="list-decimal pl-5 mt-2 space-y-1 text-slate-700">
            <li>แจ้งผลแก่สตรีตั้งครรภ์และคู่สมรสพร้อมกันในสถานที่มิดชิดเป็นส่วนตัว</li>
            <li>อธิบายข้อเท็จจริงอย่างละเอียดว่าทารกเป็น thalassemia ชนิดใด และธรรมชาติของโรค</li>
            <li>ให้เวลาทั้งสองฝ่ายได้อยู่ร่วมกันตามลำพังเพื่อประมวลผลอารมณ์</li>
            <li>เน้นย้ำว่า <em>"ไม่ใช่ความผิดของพ่อหรือแม่ เป็นความผิดปกติที่เกิดขึ้นเองตามธรรมชาติที่ไม่มีใครสามารถป้องกันได้"</em></li>
            <li>อภิปรายทางเลือกทั้ง 2 ทาง (ยุติการตั้งครรภ์ หรือ ตั้งครรภ์ต่อ) โดยเคารพการตัดสินใจของครอบครัว</li>
          </ol>
        </div>
      </div>
    `,
  },
  {
    id: 'gate3_birth',
    title: 'ประตูที่ 3: "เลือกคลอด" และการพยาบาลมารดา-ทารกครบวงจร',
    subtitle: 'การพยาบาลระยะตั้งครรภ์ (ANC), ระยะคลอด (Labor), และระยะหลังคลอด (Postpartum)',
    gate: 'gate3_birth',
    iconName: 'ShieldCheck',
    summary: 'การดูแลหญิงตั้งครรภ์ที่เป็นโรคธาลัสซีเมีย หรือตั้งครรภ์ทารกกลุ่มเสี่ยง ต้องอาศัยการทำงานเป็นทีมสหวิชาชีพ เพื่อป้องกันภาวะแทรกซ้อนรุนแรงทั้งมารดาและทารก',
    keyPoints: [
      'รักษาระดับ Hb ไม่ให้ต่ำกว่า 7-8 g/dL หากซีดมากต้องให้ Packed Red Cells (PRC)',
      'ให้ Folic acid 5 mg/day ช่วยในการสร้างเม็ดเลือดแดง',
      'หลีกเลี่ยงการให้ยาธาตุเหล็ก (Iron) และอาหารที่มีธาตุเหล็กสูง เช่น เลือด ตับ เครื่องใน ยกเว้นพิสูจน์แล้วว่ามีภาวะขาดธาตุเหล็กจริง (Ferritin ต่ำ)',
      'แนะนำอาหารที่ช่วยลดการดูดซึมธาตุเหล็ก เช่น ชา นม น้ำเต้าหู้',
      'ตรวจคัดกรองเบาหวาน (GTT) เนื่องจากธาตุเหล็กสะสมในตับอ่อนทำให้ดื้ออินซูลิน',
      'ประเมินการทำงานของหัวใจไตรมาสละ 1 ครั้ง เฝ้าระวัง Heart failure',
      'ยาขับธาตุเหล็ก Desferrioxamine ต้องหยุดในไตรมาสแรก (T1) และพิจารณาใน T2-T3 เฉพาะเมื่อ Ferritin > 1,000 mcg/L',
      'ระยะคลอด: นอนศีรษะสูงหรือนอนตะแคงซ้ายศีรษะสูงเพื่อลดการใช้ออกซิเจนและเพิ่ม cardiac output, บรรเทาปวด, เฝ้าระวัง PPH อย่างเข้มงวด',
      'ระยะหลังคลอด: ป้องกันการตกเลือดหลังคลอด (PPH) และการติดเชื้อ, วางแผนคุมกำเนิดที่เหมาะสม',
    ],
    clinicalRelevance: 'หญิงตั้งครรภ์โรคธาลัสซีเมียมีความต้านทานต่อการเสียเลือดต่ำมาก การเสียเลือดเพียงเล็กน้อยอาจกระตุ้นให้เกิด Hypovolemic shock หรือ Heart failure ได้อย่างรวดเร็ว',
    contentHtml: `
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs my-3">
        <div class="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <h5 class="font-bold text-blue-900 mb-1">ระยะตั้งครรภ์ (ANC)</h5>
          <ul class="list-disc pl-4 space-y-1 text-slate-700">
            <li>Hb &ge; 7-8 g/dL</li>
            <li>Folic acid 5 mg/day</li>
            <li>งดยาธาตุเหล็กและเครื่องในสัตว์</li>
            <li>ประเมินหัวใจไตรมาสละครั้ง</li>
            <li>ระวังไข้สูง (เม็ดเลือดแตกเร็ว)</li>
          </ul>
        </div>
        <div class="p-3 bg-pink-50 border border-pink-200 rounded-lg">
          <h5 class="font-bold text-pink-900 mb-1">ระยะคลอด (Intrapartum)</h5>
          <ul class="list-disc pl-4 space-y-1 text-slate-700">
            <li>นอนศีรษะสูง / ตะแคงซ้ายศีรษะสูง</li>
            <li>ลดการใช้ออกซิเจน</li>
            <li>ดูแลบรรเทาความเจ็บปวด</li>
            <li>ติดตาม FHR สม่ำเสมอ</li>
            <li>เตรียมพร้อมรับมือ PPH ทันที</li>
          </ul>
        </div>
        <div class="p-3 bg-indigo-50 border border-indigo-200 rounded-lg">
          <h5 class="font-bold text-indigo-900 mb-1">ระยะหลังคลอด (Postpartum)</h5>
          <ul class="list-disc pl-4 space-y-1 text-slate-700">
            <li>เฝ้าระวังตกเลือดหลังคลอด 2 ชม.แรก</li>
            <li>ป้องกันการติดเชื้ออย่างเคร่งครัด</li>
            <li>ส่งเสริมการเลี้ยงลูกด้วยนมแม่</li>
            <li>ให้คำแนะนำการคุมกำเนิด</li>
            <li>นัด Follow up สุขภาพแม่และลูก</li>
          </ul>
        </div>
      </div>
    `,
  },
  {
    id: 'pingpong_traffic_lights',
    title: 'มาตรการคัดกรองเฝ้าระวัง ควบคุม ป้องกันโรคธาลัสซีเมีย ด้วยปิงปองจราจร ๖ สี',
    subtitle: 'เกณฑ์การซักประวัติ ตรวจร่างกาย ๑๕ ข้อ ในหญิงตั้งครรภ์ เด็กแรกคลอด วัยรุ่น (๐-๑๕ ปี) ร่วมกับผล Hb typing และมาตรการ ๓ อ ๓ ลด',
    gate: 'foundation',
    iconName: 'Activity',
    summary: 'ระบบคัดกรองและจัดระดับความรุนแรงของโรคธาลัสซีเมียตามแนวทางของกระทรวงสาธารณสุข โดยประเมินการซักประวัติ ๔ ข้อ และตรวจร่างกาย ๑๑ ข้อ (รวม ๑๕ ข้อ ๑๕ คะแนน) ร่วมกับผลการตรวจเลือดทางพันธุกรรม Hb typing เพื่อจำแนกเป็น ๖ ระดับปิงปองจราจร (ขาว เขียว เหลือง ส้ม แดง ดำ) พร้อมแนวทางส่งเสริมสุขภาพ "๓ อ ๓ ลด" และการดูแลรักษาทางการพยาบาล',
    keyPoints: [
      'กลุ่มเป้าหมายคัดกรอง: หญิงตั้งครรภ์, เด็กแรกคลอด, และเด็กวัยรุ่น (อายุ ๐ - ๑๕ ปี)',
      'เกณฑ์ประเมิน ๑๕ ข้อ: ซักประวัติ ๔ ข้อ (ซีดบ่อยๆ หายๆ, ได้รับเลือดเพราะซีด, ตัวเหลืองดีซ่านเป็นๆ หายๆ, พี่น้องหรือญาติเป็นโรคซีด) + ตรวจร่างกาย ๑๑ ข้อ (ซีดดูที่เปลือกตาด้านใน, หน้าผากแบนนูนสูง, ตาห่าง, ดั้งจมูกแฟบ, โหนกแก้มสูง, ฟันหน้ายื่น, ตาขาวมีสีเหลือง, ตัวเตี้ยแคระแกร็นหรือขาดสารอาหาร, น้ำหนักน้อยขาดสารอาหาร, ท้องโตตับหรือม้ามโต, ผิวหนังสีเทาดำคล้ำ)',
      'ปิงปองสีขาว (คะแนน ๐ - ๔): ปกติ / ไม่เป็นโรคฯ ตรวจเลือดไม่ซีด เม็ดเลือดแดงปกติ (Hb ปกติ, RBC ปกติ, Hb typing ปกติ) ดูแลสุขภาพด้วย "๓ อ ๓ ลด"',
      'ปิงปองสีเขียว (คะแนน ๕ - ๑๐): สงสัยเป็นโรค ตรวจเลือดพบซีด เม็ดเลือดแดงผิดปกติ แต่ Hb typing ปกติ ดูแลด้วย "๓ อ ๓ ลด" และส่งตรวจเพิ่มเติม (Serum ferritin หรือ PCR DNA α-thal 1)',
      'ปิงปองสีเหลือง (คะแนน ๑๑ - ๑๕): เสี่ยงเป็นโรค ตรวจเลือดพบซีด เม็ดเลือดแดงผิดปกติ และ Hb typing ผิดปกติ ดูแลด้วย "๓ อ ๓ ลด" ส่งพบแพทย์ผู้เชี่ยวชาญ/อายุรแพทย์โรคเลือด',
      'ปิงปองสีส้ม (คะแนน ๑๕ - กลุ่มอาการรุนแรงน้อย / Intermedia): อาการปกติ ซีดเหลืองเล็กน้อย เจ็บป่วยบ่อย มีดีซ่าน ต้องให้เลือดทุกครั้งที่ป่วย ตรวจเลือดและ Hb typing ผิดปกติ ดูแลรักษาด้วย Folic Acid, การให้เลือดเมื่อเจ็บป่วย, ยาขับเหล็ก',
      'ปิงปองสีแดง (คะแนน ๑๕ - กลุ่มอาการรุนแรงมาก / Major): แรกเกิดยังไม่มีอาการ แต่อายุได้ ๓-๖ เดือน เริ่มตาเหลือง อ่อนเพลีย ตัวเตี้ยแคระแกร็น ตับม้ามโต ใบหน้าเปลี่ยนแปลง (Thalassemia facies) หน้าผากตั้งชั้น โหนกแก้มสูง ดั้งจมูกแบน ฟันยื่น ยิ่งอายุมากยิ่งชัด ต้องให้เลือดประจำ ถ้าไม่ได้รักษาต่อเนื่องจะเสียชีวิตช่วงอายุ ๑๘-๒๐ ปี รักษาด้วย Folic Acid, ให้เลือดประจำ (Regular transfusion), ยาขับเหล็ก',
      'ปิงปองสีดำ (คะแนน ๑๕ - กลุ่มอาการรุนแรงสูงสุด / Hb Bart\'s Hydrops Fetalis): ทารกบวมน้ำ แรกคลอดลำบาก ตับม้ามโต ส่วนใหญ่เสียชีวิตในครรภ์หรือหลังคลอด มารดามีโอกาสเกิดภาวะครรภ์เป็นพิษ (Maternal Mirror Syndrome) บวม ความดันโลหิตสูง ปวดศีรษะ ตามัว ชัก และเสียชีวิตได้ การดูแลรักษาคือ "ยุติการตั้งครรภ์ (Termination of Pregnancy)"',
      'มาตรการ "๓ อ ๓ ลด": อ.๑ อาหาร (กินครบหมู่ เน้นผักผลไม้อ่อนหวาน เลี่ยงปรุงหวานมันเค็ม เลี่ยงตับ/เลือด/เครื่องในสัตว์ในผู้ป่วย), อ.๒ ออกกำลังกาย (เคลื่อนไหวตามกำลัง ไม่หักโหม ๒๐-๓๐ นาที ๒-๕ วัน/สัปดาห์ เลี่ยงการกระแทกหน้าท้องหากม้ามโต), อ.๓ อารมณ์ (จิตใจสดชื่น ฝึกสติ คิดบวก) / ลด ๑ ลดความอ้วน, ลด ๒ ลดสุราเครื่องดื่มแอลกอฮอล์ (ป้องกันตับแข็ง), ลด ๓ ลดบุหรี่บุหรี่ไฟฟ้า (ป้องกันขาดออกซิเจน)',
    ],
    clinicalRelevance: 'ระบบปิงปองจราจร ๖ สีช่วยให้นักศึกษาพยาบาลมีเครื่องมือจัดลำดับความเร่งด่วนทางคลินิก (Triage & Staging) ที่ชัดเจน สามารถเชื่อมโยงการตรวจร่างกายเข้ากับผลทางห้องปฏิบัติการ และให้สุขศึกษาแก่ผู้ป่วยและประชาชนในพื้นที่อย่างเป็นรูปธรรมด้วยหลัก ๓ อ ๓ ลด',
    contentHtml: `
      <div class="space-y-4">
        <div class="p-4 bg-gradient-to-r from-pink-50 via-slate-50 to-sky-50 rounded-2xl border border-pink-200">
          <h4 class="font-bold text-slate-900 text-sm mb-1">ภาพรวมของมาตรการปิงปองจราจร ๖ สี (6-Color Traffic Ping-Pong Overview)</h4>
          <p class="text-xs text-slate-700 leading-relaxed">
            เป็นการบูรณาการการคัดกรอง <strong>ซักประวัติ ๔ ข้อ + ตรวจร่างกาย ๑๑ ข้อ (รวม ๑๕ ข้อ ๑๕ คะแนน)</strong> ในกลุ่มหญิงตั้งครรภ์ เด็กแรกคลอด และวัยรุ่น (๐-๑๕ ปี) ร่วมกับการตรวจทางห้องปฏิบัติการพันธุกรรม Hb typing เพื่อคัดกรองจัดกลุ่มความเสี่ยงและการดูแลรักษาที่จำเพาะ
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          <div class="p-3.5 rounded-xl border-2 border-slate-300 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-slate-800 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-slate-200 border border-slate-400 inline-block"></span>
                <span>สีขาว: ปกติ</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">๐-๔ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">ไม่เป็นโรคฯ ไม่ซีด เม็ดเลือดแดงปกติ Hb ปกติ Hb typing ปกติ</p>
            <div class="text-[11px] font-semibold text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-100">
              การดูแล: สุขภาพด้วย ๓ อ ๓ ลด
            </div>
          </div>

          <div class="p-3.5 rounded-xl border-2 border-emerald-400 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-emerald-900 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-emerald-500 inline-block"></span>
                <span>สีเขียว: สงสัยเป็นโรค</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">๕-๑๐ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">เสี่ยงเป็นโรคฯ ให้ส่งตรวจเลือด พบซีด เม็ดเลือดแดงผิดปกติ แต่ Hb typing ปกติ</p>
            <div class="text-[11px] font-semibold text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-100">
              การดูแล: สุขภาพด้วย ๓ อ ๓ ลด &amp; ส่งตรวจเพิ่ม
            </div>
          </div>

          <div class="p-3.5 rounded-xl border-2 border-amber-400 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-amber-900 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-amber-400 inline-block"></span>
                <span>สีเหลือง: เสี่ยงเป็นโรค</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[10px]">๑๑-๑๕ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">เสี่ยงเป็นโรคฯ ให้ส่งตรวจเลือด พบซีด เม็ดเลือดแดงผิดปกติ Hb typing ผิดปกติ</p>
            <div class="text-[11px] font-semibold text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-100">
              การดูแล: สุขภาพด้วย ๓ อ ๓ ลด &amp; ตรวจยืนยันพันธุกรรม
            </div>
          </div>

          <div class="p-3.5 rounded-xl border-2 border-orange-400 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-orange-900 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-orange-500 inline-block"></span>
                <span>สีส้ม: รุนแรงน้อย</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 font-bold text-[10px]">๑๕ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">กลุ่มอาการรุนแรงน้อย ปกติอาการไม่มาก ซีดเหลืองเล็กน้อย เจ็บป่วยบ่อย มีดีซ่าน ต้องให้เลือดทุกครั้งที่ป่วย</p>
            <div class="text-[11px] font-semibold text-orange-800 bg-orange-50 p-2 rounded-lg border border-orange-100">
              การดูแล: Folic Acid, ให้เลือดเมื่อป่วย, ยาขับเหล็ก
            </div>
          </div>

          <div class="p-3.5 rounded-xl border-2 border-rose-400 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-rose-900 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-rose-600 inline-block"></span>
                <span>สีแดง: รุนแรงมาก</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold text-[10px]">๑๕ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">แรกเกิดไม่มีอาการ เริ่มมีอาการ ๓-๖ ด. ตาเหลือง ตัวเตี้ย ตับม้ามโต ใบหน้าเปลี่ยน ฟันยื่น ให้เลือดประจำ เสียชีวิต ๑๘-๒๐ ปี</p>
            <div class="text-[11px] font-semibold text-rose-800 bg-rose-50 p-2 rounded-lg border border-rose-100">
              การดูแล: Folic Acid, ให้เลือดประจำ, ยาขับเหล็ก
            </div>
          </div>

          <div class="p-3.5 rounded-xl border-2 border-slate-800 bg-white shadow-xs">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-slate-900 flex items-center gap-1.5">
                <span class="w-3.5 h-3.5 rounded-full bg-slate-950 inline-block"></span>
                <span>สีดำ: รุนแรงสูงสุด</span>
              </span>
              <span class="px-2 py-0.5 rounded-full bg-slate-900 text-white font-bold text-[10px]">๑๕ คะแนน</span>
            </div>
            <p class="text-slate-600 mb-2">ทารกบวมน้ำ คลอดลำบาก ตับม้ามโต เสียชีวิตในครรภ์/หลังคลอด แม่เสี่ยงครรภ์เป็นพิษ บวม ชัก เสียชีวิต</p>
            <div class="text-[11px] font-semibold text-slate-900 bg-slate-100 p-2 rounded-lg border border-slate-300">
              การดูแล: ยุติการตั้งครรภ์ (เพื่อความปลอดภัยของแม่)
            </div>
          </div>
        </div>
      </div>
    `,
    tableData: {
      headers: ['ระดับปิงปองจราจร', 'เกณฑ์คะแนน (๑๕ ข้อ)', 'ลักษณะอาการทางคลินิก', 'ผลการตรวจเลือด & Hb typing', 'แนวทางการดูแลรักษา'],
      rows: [
        ['สีขาว (ปกติ)', '๐ - ๔ คะแนน', 'ไม่มีอาการซีด ร่างกายสมบูรณ์แข็งแรงดี', 'ไม่ซีด เม็ดเลือดแดงปกติ, Hb typing ปกติ', 'ดูแลสุขภาพด้วย ๓ อ ๓ ลด'],
        ['สีเขียว (สงสัยเป็นโรค)', '๕ - ๑๐ คะแนน', 'ซีดเล็กน้อยเป็นๆ หายๆ อาจมีญาติพี่น้องซีด', 'พบซีด เม็ดเลือดแดงผิดปกติ, Hb typing ปกติ', 'ดูแลสุขภาพด้วย ๓ อ ๓ ลด, ส่งตรวจเลือดเพิ่มเติม'],
        ['สีเหลือง (เสี่ยงเป็นโรค)', '๑๑ - ๑๕ คะแนน', 'ซีดชัดเจน มีตาเหลืองประปราย หรือเริ่มมีตับม้ามโต', 'พบซีด เม็ดเลือดแดงผิดปกติ, Hb typing ผิดปกติ', 'ดูแลสุขภาพด้วย ๓ อ ๓ ลด, ส่งตรวจยืนยันพันธุกรรม'],
        ['สีส้ม (รุนแรงน้อย)', '๑๕ คะแนน', 'ซีดเหลืองเล็กน้อย เจ็บป่วยบ่อย มีดีซ่าน ต้องให้เลือดทุกครั้งที่ป่วย', 'ผลเลือดผิดปกติ, Hb typing ผิดปกติ', 'Folic Acid, ให้เลือดเมื่อป่วย, ยาขับเหล็ก'],
        ['สีแดง (รุนแรงมาก)', '๑๕ คะแนน', 'เริ่มมีอาการ ๓-๖ ด. ตาเหลือง ตับม้ามโต หน้าเปลี่ยน ฟันยื่น ให้เลือดประจำ เสียชีวิต ๑๘-๒๐ ปี', 'ซีดรุนแรง, Hb typing ผิดปกติรุนแรง (เช่น β-thal major, β/E severe)', 'Folic Acid, ให้เลือดประจำ (Regular), ยาขับเหล็ก'],
        ['สีดำ (รุนแรงสูงสุด)', '๑๕ คะแนน', 'ทารกบวมน้ำ คลอดลำบาก ตับม้ามโต เสียชีวิตในครรภ์/หลังคลอด แม่เสี่ยงครรภ์เป็นพิษ ชัก เสียชีวิต', 'Ultrasound พบ Hydrops fetalis, Hb Bart\'s 80-100%', 'ยุติการตั้งครรภ์ (เพื่อความปลอดภัยของมารดา)'],
      ],
    },
  },
];
