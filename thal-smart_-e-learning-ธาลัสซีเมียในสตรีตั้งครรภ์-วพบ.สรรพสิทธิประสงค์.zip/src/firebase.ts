import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { StudentProfile, QuizResult, LearnerScoreRecord } from './types';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const INSTRUCTOR_EMAIL = 'sunanthajaya23@gmail.com';
export const COURSE_ID = 'bcnsp-thal-smart' as const;

// Blueprint validation constants (synced verbatim with firebase-blueprint.json & firestore.rules)
export const ID_REGEX = /^[a-zA-Z0-9_\-]+$/;
export const MAX_UID_LENGTH = 128;
export const MAX_STUDENT_NAME_LENGTH = 120;
export const MAX_STUDENT_ID_LENGTH = 40;
export const MAX_COHORT_LENGTH = 120;
export const MAX_COLLEGE_LENGTH = 150;
export const MAX_DATE_LENGTH = 80;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection to Firestore on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

export function sanitizeIdToken(raw: string, maxLen = 40, fallback = '6611400001'): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_\-]/g, '').slice(0, maxLen);
  return cleaned.length > 0 && ID_REGEX.test(cleaned) ? cleaned : fallback;
}

export function clampInt(val: number, min: number, max: number): number {
  const n = Math.round(Number(val) || 0);
  return Math.max(min, Math.min(max, n));
}

export function sanitizeString(val: string, maxLen: number, fallback: string): string {
  const trimmed = (val || '').trim().slice(0, maxLen);
  return trimmed.length > 0 ? trimmed : fallback;
}

export async function signInWithGoogle() {
  return signInWithPopup(auth, googleProvider);
}

export async function signOutUser() {
  return signOut(auth);
}

export async function fetchServerLearnerRecords(): Promise<LearnerScoreRecord[]> {
  try {
    const res = await fetch('/api/learner-scores');
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data?.records) ? data.records : [];
  } catch {
    return [];
  }
}

export async function syncLearnerRecordToFirestore(params: {
  student: StudentProfile;
  quizResult: QuizResult | null;
  liveQuizProgress?: { answeredCount: number; correctCount: number };
  completedCasesCount: number;
  totalCasesScore: number;
}): Promise<LearnerScoreRecord[]> {
  const currentUser = auth.currentUser;
  const safeStudentId = sanitizeIdToken(
    params.student.studentId,
    MAX_STUDENT_ID_LENGTH,
    '6611400001'
  );
  const safeStudentName = sanitizeString(
    params.student.name,
    MAX_STUDENT_NAME_LENGTH,
    currentUser?.displayName || 'นักศึกษาพยาบาล'
  );
  const safeCohort = sanitizeString(
    params.student.cohort,
    MAX_COHORT_LENGTH,
    'นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4'
  );
  const safeCollege = sanitizeString(
    params.student.college,
    MAX_COLLEGE_LENGTH,
    'วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์'
  );

  const isCompleted = Boolean(params.quizResult?.completed);
  const rawScore = isCompleted
    ? params.quizResult?.score ?? 0
    : params.liveQuizProgress?.correctCount ?? 0;
  const quizScore = clampInt(rawScore, 0, 40);
  const totalQuestions = 40;
  const answeredCount = isCompleted
    ? 40
    : clampInt(
        params.liveQuizProgress?.answeredCount ??
          Object.keys(params.quizResult?.userAnswers || {}).length,
        0,
        40
      );
  const percentage = isCompleted
    ? clampInt(params.quizResult?.percentage ?? Math.round((quizScore / 40) * 100), 0, 100)
    : clampInt(Math.round((quizScore / 40) * 100), 0, 100);
  const passed = isCompleted
    ? Boolean(params.quizResult?.passed)
    : percentage >= 70 && answeredCount === 40;

  const completedCasesCount = clampInt(params.completedCasesCount, 0, 8);
  const totalCasesScore = clampInt(params.totalCasesScore, 0, 200);

  const defaultDate = new Date().toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const dateCompleted = sanitizeString(
    params.quizResult?.dateCompleted || defaultDate,
    MAX_DATE_LENGTH,
    defaultDate
  );

  // 1. Always sync to shared server API so all students' scores are recorded even without Google Sign-In
  let serverRecords: LearnerScoreRecord[] = [];
  try {
    const res = await fetch('/api/learner-scores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid: currentUser?.uid || `student_${safeStudentId}`,
        courseId: COURSE_ID,
        studentName: safeStudentName,
        studentId: safeStudentId,
        cohort: safeCohort,
        college: safeCollege,
        quizCompleted: isCompleted,
        quizScore,
        totalQuestions,
        percentage,
        passed,
        answeredCount,
        completedCasesCount,
        totalCasesScore,
        dateCompleted,
      }),
    });
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json?.records)) {
        serverRecords = json.records;
      }
    }
  } catch (err) {
    console.error('Failed to sync with /api/learner-scores:', err);
  }

  // 2. Also sync to Firestore if the user is authenticated with a verified Google account
  if (!currentUser || !currentUser.emailVerified) {
    return serverRecords;
  }

  const safeUid = sanitizeIdToken(currentUser.uid, MAX_UID_LENGTH, currentUser.uid);
  const recordId = sanitizeIdToken(`${safeUid}_${safeStudentId}`, MAX_UID_LENGTH, safeUid);
  const docPath = `learnerScores/${recordId}`;
  const docRef = doc(db, 'learnerScores', recordId);

  let existingSnap;
  try {
    existingSnap = await getDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, docPath);
  }

  if (!existingSnap.exists()) {
    try {
      await setDoc(docRef, {
        uid: safeUid,
        courseId: COURSE_ID,
        studentName: safeStudentName,
        studentId: safeStudentId,
        cohort: safeCohort,
        college: safeCollege,
        status: 'active',
        quizCompleted: isCompleted,
        quizScore,
        totalQuestions,
        percentage,
        passed,
        answeredCount,
        completedCasesCount,
        totalCasesScore,
        dateCompleted,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, docPath);
    }
  } else {
    const existingData = existingSnap.data();
    const isCurrentAdmin = currentUser.email === INSTRUCTOR_EMAIL;
    if (existingData?.status === 'locked' && !isCurrentAdmin) {
      return serverRecords;
    }

    try {
      await updateDoc(docRef, {
        studentName: safeStudentName,
        studentId: safeStudentId,
        cohort: safeCohort,
        college: safeCollege,
        quizCompleted: isCompleted,
        quizScore,
        totalQuestions,
        percentage,
        passed,
        answeredCount,
        completedCasesCount,
        totalCasesScore,
        dateCompleted,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, docPath);
    }
  }

  return serverRecords;
}

export async function deleteLearnerRecordFromFirestore(
  recordId: string,
  studentId?: string
): Promise<void> {
  try {
    await fetch(`/api/learner-scores/${encodeURIComponent(studentId || recordId)}`, {
      method: 'DELETE',
    });
  } catch (e) {
    console.error('Failed to delete from server API:', e);
  }

  if (auth.currentUser && auth.currentUser.emailVerified && !recordId.startsWith('std_')) {
    const safeId = sanitizeIdToken(recordId, MAX_UID_LENGTH, recordId);
    const docPath = `learnerScores/${safeId}`;
    try {
      await deleteDoc(doc(db, 'learnerScores', safeId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, docPath);
    }
  }
}
