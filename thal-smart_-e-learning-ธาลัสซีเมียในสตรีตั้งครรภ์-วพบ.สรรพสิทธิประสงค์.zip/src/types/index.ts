export type GateType = 'gate1_match' | 'gate2_pregnancy' | 'gate3_birth';

export interface StudentProfile {
  name: string;
  studentId: string;
  cohort: string;
  college: string;
  completedGates?: GateType[];
}

export interface LabResult {
  mcv: number | '';
  mch: number | '';
  dcip: 'Positive' | 'Negative' | 'Not tested';
  ofTest?: 'Positive' | 'Negative' | 'Not tested';
  hbTyping: string;
  hbePercent?: number | '';
  hba2Percent?: number | '';
  hbfPercent?: number | '';
  hbaPercent?: number | '';
  pcrAlpha1?: 'Positive' | 'Negative' | 'Not tested';
}

export interface PingPongColorTag {
  colorKey: 'white' | 'green' | 'yellow' | 'orange' | 'red' | 'black';
  colorName: string;
  label: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  dotColor: string;
  title: string;
  description: string;
}

export interface LabInterpretationResult {
  conditionName: string;
  genotype: string;
  severityCategory: 'Normal / Non-significant' | 'Trait / Carrier' | 'Disease' | 'High Risk';
  details: string;
  recommendation: string;
  isCarrierOfSevereDisease: boolean;
  severeDiseaseType?: 'alpha' | 'beta' | 'none';
  pingPongTag?: PingPongColorTag;
}

export interface CoupleRiskAssessment {
  riskLevel: 'High Risk (คู่เสี่ยงรุนแรง)' | 'Low Risk / Carrier Only' | 'Normal / Safe';
  targetDisease: string;
  diseaseChance: number; // percentage e.g. 25
  carrierChance: number; // percentage e.g. 50
  normalChance: number;  // percentage e.g. 25
  explanation: string;
  punnettSquare: {
    fatherGametes: [string, string];
    motherGametes: [string, string];
    combinations: [string, string, string, string];
    phenotypes: [string, string, string, string];
    phenotypePingPongs?: PingPongColorTag[];
  };
  recommendedNextSteps: string[];
  wifePingPong?: PingPongColorTag;
  husbandPingPong?: PingPongColorTag;
  diseasePingPong?: PingPongColorTag;
  carrierPingPong?: PingPongColorTag;
  normalPingPong?: PingPongColorTag;
}

export interface CaseStudy {
  id: string;
  caseNumber: number;
  title: string;
  gate: GateType;
  patientProfile: {
    name: string;
    age: number;
    gravida: string;
    ga: string;
    occupation: string;
    location: string;
    history: string;
    vitals: {
      bp: string;
      pr: string;
      fundalHeight?: string;
      fhr?: string;
    };
  };
  maternalLab: {
    cbc: { hb: string; hct: string; mcv: string; mch: string; wbc: string; plt: string };
    screening: { dcip: string; of?: string };
    hbTyping?: string;
    pcrAlpha?: string;
    others?: string;
  };
  partnerLab?: {
    cbc?: { hb: string; hct: string; mcv: string; mch: string };
    screening?: { dcip: string };
    hbTyping?: string;
    pcrAlpha?: string;
  };
  stages: {
    stageNumber: number;
    stageTitle: string;
    scenarioText: string;
    question: string;
    options: {
      id: string;
      text: string;
      isCorrect: boolean;
      rationale: string;
      clinicalPoints: number;
    }[];
  }[];
  summaryLearningPoints: string[];
}

export interface QuizQuestion {
  id: number;
  gate: GateType;
  category: 'การคัดกรองด้วยปิงปองจราจร 6 สี' | 'การคัดกรองและการแปลผลแล็บ' | 'การตรวจวินิจฉัยก่อนคลอด (PND)' | 'การให้คำปรึกษาทางพันธุศาสตร์' | 'การพยาบาลระยะตั้งครรภ์และคลอด' | 'พันธุศาสตร์และพยาธิสภาพ';
  question: string;
  options: string[];
  correctAnswer: number; // 0, 1, 2, 3
  rationale: string;
  slideRef?: string;
}

export interface QuizResult {
  completed: boolean;
  score: number;
  totalQuestions: number;
  percentage: number;
  userAnswers: Record<number, number>;
  categoryScores: Record<string, { correct: number; total: number }>;
  gateScores: Record<GateType, { correct: number; total: number }>;
  dateCompleted: string;
  passed: boolean;
}

export interface QuickCheckQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  rationale: string;
  keyTakeaway?: string;
}

export interface QuickCheckResult {
  moduleId: string;
  score: number;
  total: number;
  passed: boolean;
  completedAt: string;
}

export interface LearnerScoreRecord {
  id: string;
  uid: string;
  courseId: 'bcnsp-thal-smart';
  studentName: string;
  studentId: string;
  cohort: string;
  college: string;
  status: 'active' | 'locked';
  quizCompleted: boolean;
  quizScore: number;
  totalQuestions: number;
  percentage: number;
  passed: boolean;
  answeredCount: number;
  completedCasesCount: number;
  totalCasesScore: number;
  dateCompleted: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

