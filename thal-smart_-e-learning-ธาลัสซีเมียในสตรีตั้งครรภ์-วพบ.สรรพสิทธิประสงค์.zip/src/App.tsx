/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { Header } from './components/Header';
import { ThreeGatesOverview } from './components/ThreeGatesOverview';
import { KnowledgeBaseView } from './components/KnowledgeBaseView';
import { LabEngineView } from './components/LabEngineView';
import { CasesView } from './components/CasesView';
import { QuizView } from './components/QuizView';
import { AnalyticsView } from './components/AnalyticsView';
import { LearnerRosterView } from './components/LearnerRosterView';
import { NeedsAnalysisModal } from './components/NeedsAnalysisModal';
import { CertificateModal } from './components/CertificateModal';
import { StudentProfileModal } from './components/StudentProfileModal';
import { StudentProfile, QuizResult, QuickCheckResult } from './types';
import {
  auth,
  signInWithGoogle,
  signOutUser,
  syncLearnerRecordToFirestore,
} from './firebase';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('gates');

  // Firebase Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);

  // Student Profile State (with localStorage persistence)
  const [student, setStudent] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('thal_student_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      name: 'นศ.พย. นภาพร สุขสมบูรณ์',
      studentId: '6611400088',
      college: 'วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์',
      cohort: 'นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4 (รุ่นที่ 73)',
      completedGates: [],
    };
  });

  // Quiz Result State
  const [quizResult, setQuizResult] = useState<QuizResult | null>(() => {
    const saved = localStorage.getItem('thal_quiz_result');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return null;
  });

  // Live Quiz Progress (for real-time score tracking while taking the 40-question exam)
  const [liveQuizProgress, setLiveQuizProgress] = useState<{
    answeredCount: number;
    correctCount: number;
  }>({
    answeredCount: quizResult ? Object.keys(quizResult.userAnswers || {}).length : 0,
    correctCount: quizResult?.score || 0,
  });

  // Cases Completion State
  const [completedCases, setCompletedCases] = useState<
    Record<string, { completed: boolean; score: number }>
  >(() => {
    const saved = localStorage.getItem('thal_completed_cases');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {};
  });

  // Quick Check Results State (reinforcement quizzes after modules)
  const [quickCheckResults, setQuickCheckResults] = useState<
    Record<string, QuickCheckResult>
  >(() => {
    const saved = localStorage.getItem('thal_quick_checks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {};
  });

  // Modals state
  const [isNeedsModalOpen, setIsNeedsModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isCertificateModalOpen, setIsCertificateModalOpen] = useState(false);

  const completedCasesCount = Object.values(completedCases).filter((c) => c.completed).length;
  const totalCasesScore = Object.values(completedCases).reduce((acc, c) => acc + c.score, 0);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('thal_student_profile', JSON.stringify(student));
  }, [student]);

  useEffect(() => {
    if (quizResult) {
      localStorage.setItem('thal_quiz_result', JSON.stringify(quizResult));
    }
  }, [quizResult]);

  useEffect(() => {
    localStorage.setItem('thal_completed_cases', JSON.stringify(completedCases));
  }, [completedCases]);

  useEffect(() => {
    localStorage.setItem('thal_quick_checks', JSON.stringify(quickCheckResults));
  }, [quickCheckResults]);

  // Automatically sync learner record to Server API & Firestore whenever profile or scores change
  useEffect(() => {
    syncLearnerRecordToFirestore({
      student,
      quizResult,
      liveQuizProgress,
      completedCasesCount,
      totalCasesScore,
    }).catch((err) => {
      console.error('Failed to auto-sync learner record:', err);
    });
  }, [
    authReady,
    currentUser,
    student,
    quizResult,
    liveQuizProgress,
    completedCasesCount,
    totalCasesScore,
  ]);

  const handleUpdateStudentProfile = (updated: StudentProfile) => {
    const isDifferentStudent = updated.studentId !== student.studentId;
    if (isDifferentStudent) {
      // Save current student's quiz result keyed by studentId
      if (quizResult) {
        localStorage.setItem(`thal_quiz_result_${student.studentId}`, JSON.stringify(quizResult));
      }
      // Load existing quiz result for the switched studentId if any, otherwise start fresh
      const savedForNew = localStorage.getItem(`thal_quiz_result_${updated.studentId}`);
      if (savedForNew) {
        try {
          const parsed: QuizResult = JSON.parse(savedForNew);
          setQuizResult(parsed);
          setLiveQuizProgress({
            answeredCount: Object.keys(parsed.userAnswers || {}).length,
            correctCount: parsed.score || 0,
          });
        } catch {
          setQuizResult(null);
          setLiveQuizProgress({ answeredCount: 0, correctCount: 0 });
        }
      } else {
        localStorage.removeItem('thal_quiz_result');
        setQuizResult(null);
        setLiveQuizProgress({ answeredCount: 0, correctCount: 0 });
      }
    }
    setStudent(updated);
  };

  const handleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error('Google Sign-In failed:', error);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOutUser();
    } catch (error) {
      console.error('Sign-Out failed:', error);
    }
  };

  const handleSyncNow = async () => {
    await syncLearnerRecordToFirestore({
      student,
      quizResult,
      liveQuizProgress,
      completedCasesCount,
      totalCasesScore,
    });
  };

  const handleCompleteCaseStage = (
    caseId: string,
    stageIdx: number,
    isCorrect: boolean,
    points: number
  ) => {
    setCompletedCases((prev) => {
      const current = prev[caseId] || { completed: false, score: 0 };
      const newScore = isCorrect ? current.score + points : current.score;
      return {
        ...prev,
        [caseId]: {
          completed: true,
          score: newScore,
        },
      };
    });
  };

  const handleResetCase = (caseId: string) => {
    setCompletedCases((prev) => {
      const updated = { ...prev };
      delete updated[caseId];
      return updated;
    });
  };

  const handleSaveQuizResult = (result: QuizResult) => {
    setQuizResult(result);
    setLiveQuizProgress({
      answeredCount: result.totalQuestions,
      correctCount: result.score,
    });
  };

  const handleQuizProgressChange = (answeredCount: number, correctCount: number) => {
    setLiveQuizProgress({ answeredCount, correctCount });
  };

  const handleCompleteQuickCheck = (result: QuickCheckResult) => {
    setQuickCheckResults((prev) => ({
      ...prev,
      [result.moduleId]: result,
    }));
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col selection:bg-pink-500 selection:text-white">
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        student={student}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenNeeds={() => setIsNeedsModalOpen(true)}
        completedCasesCount={completedCasesCount}
        quizCompleted={!!quizResult?.completed}
        quizScore={quizResult?.score || 0}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'gates' && (
          <ThreeGatesOverview
            onNavigateToModule={(mod) => setActiveTab(mod)}
            student={student}
            completedCases={completedCases}
            quizResult={quizResult}
            quickCheckResults={quickCheckResults}
            onCompleteQuickCheck={handleCompleteQuickCheck}
          />
        )}

        {activeTab === 'knowledge' && (
          <KnowledgeBaseView
            onNavigateToModule={(mod) => setActiveTab(mod)}
            onCompleteQuickCheck={handleCompleteQuickCheck}
          />
        )}

        {activeTab === 'lab' && <LabEngineView />}

        {activeTab === 'cases' && (
          <CasesView
            completedCases={completedCases}
            onCompleteStage={handleCompleteCaseStage}
            onResetCase={handleResetCase}
            onNavigateToModule={(mod) => setActiveTab(mod)}
            onCompleteQuickCheck={handleCompleteQuickCheck}
          />
        )}

        {activeTab === 'quiz' && (
          <QuizView
            key={student.studentId}
            quizResult={quizResult}
            onSaveQuizResult={handleSaveQuizResult}
            onProgressChange={handleQuizProgressChange}
            onGoToAnalytics={() => setActiveTab('analytics')}
            onGoToRoster={() => setActiveTab('roster')}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            student={student}
            quizResult={quizResult}
            completedCasesCount={completedCasesCount}
            totalCasesScore={totalCasesScore}
            quickCheckResults={quickCheckResults}
            onOpenCertificate={() => setIsCertificateModalOpen(true)}
            onGoToQuiz={() => setActiveTab('quiz')}
            onGoToCases={() => setActiveTab('cases')}
          />
        )}

        {activeTab === 'roster' && (
          <LearnerRosterView
            currentUser={currentUser}
            authReady={authReady}
            onSignIn={handleSignIn}
            onSignOut={handleSignOut}
            student={student}
            quizResult={quizResult}
            liveQuizProgress={liveQuizProgress}
            completedCasesCount={completedCasesCount}
            totalCasesScore={totalCasesScore}
            onSyncNow={handleSyncNow}
            onOpenProfileModal={() => setIsProfileModalOpen(true)}
            onGoToQuiz={() => setActiveTab('quiz')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="no-print bg-white border-t border-slate-200 py-6 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-md bg-blue-900 text-white flex items-center justify-center font-bold text-[11px]">
              ส
            </div>
            <div>
              <span className="font-semibold text-slate-800">
                วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ (BCNSP)
              </span>
              <p className="text-[10px] text-slate-400">
                กลุ่มวิชาการพยาบาลมารดาทารกและการผดุงครรภ์ &bull; หลักสูตรพยาบาลศาสตรบัณฑิต
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setActiveTab('roster')}
              className="text-emerald-700 hover:text-emerald-600 font-semibold transition"
            >
              ดูรายชื่อผู้เรียนและคะแนนสอบทั้งหมด
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setIsNeedsModalOpen(true)}
              className="text-slate-600 hover:text-pink-600 font-medium transition"
            >
              การวิเคราะห์ผู้เรียนและความต้องการ
            </button>
            <span>&bull;</span>
            <span className="text-slate-400">
              อ้างอิง: มติคณะกรรมการมูลนิธิโรคโลหิตจางธาลัสซีเมียฯ และมาตรฐานการคัดกรองเฝ้าระวัง ควบคุม ป้องกันโรคเลือดจางธาลัสซีเมียด้วยปิงปองจราจรชีวิต 6 สี
            </span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <NeedsAnalysisModal
        isOpen={isNeedsModalOpen}
        onClose={() => setIsNeedsModalOpen(false)}
      />

      <StudentProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        student={student}
        onSave={handleUpdateStudentProfile}
      />

      <CertificateModal
        isOpen={isCertificateModalOpen}
        onClose={() => setIsCertificateModalOpen(false)}
        student={student}
        quizResult={quizResult}
      />
    </div>
  );
}
