import { LabResult, LabInterpretationResult, CoupleRiskAssessment, PingPongColorTag } from '../types';

export const PING_PONG_TAGS: Record<'white' | 'green' | 'yellow' | 'orange' | 'red' | 'black', PingPongColorTag> = {
  white: {
    colorKey: 'white',
    colorName: 'สีขาว',
    label: 'ปิงปองสีขาว: ปกติ / ไม่เป็นโรคฯ',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-300',
    badgeText: 'ปิงปองสีขาว (ปกติ)',
    borderColor: 'border-slate-300',
    dotColor: 'bg-slate-300 border-2 border-slate-400',
    title: 'ปกติ (Normal)',
    description: 'ผลตรวจเลือดและคัดกรองปกติ ไม่พบยีนแฝงโรครุนแรง แนะนำดูแลสุขภาพตามหลัก 3 อ 3 ลด',
  },
  green: {
    colorKey: 'green',
    colorName: 'สีเขียว',
    label: 'ปิงปองสีเขียว: สงสัยเป็นโรค / เม็ดเลือดเล็ก',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    badgeText: 'ปิงปองสีเขียว (สงสัยเป็นโรค)',
    borderColor: 'border-emerald-400',
    dotColor: 'bg-emerald-500 border-2 border-emerald-600',
    title: 'สงสัยเป็นโรค (Suspected / Microcytosis)',
    description: 'เม็ดเลือดแดงขนาดเล็ก (MCV < 80 fL) แต่ Hb typing ปกติ ต้องส่งตรวจ Ferritin และ PCR α-thal 1 ยืนยัน',
  },
  yellow: {
    colorKey: 'yellow',
    colorName: 'สีเหลือง',
    label: 'ปิงปองสีเหลือง: เสี่ยงเป็นโรค / พาหะยีนแฝง',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
    badgeText: 'ปิงปองสีเหลือง (เสี่ยงเป็นโรค)',
    borderColor: 'border-amber-400',
    dotColor: 'bg-amber-400 border-2 border-amber-500',
    title: 'เสี่ยงเป็นโรค (Carrier / ยืนยันพาหะ)',
    description: 'เป็นพาหะธาลัสซีเมีย (เช่น EA, β-thal trait, α-thal 1) สุขภาพแข็งแรงดีแต่ถ่ายทอดยีนสู่ลูกได้',
  },
  orange: {
    colorKey: 'orange',
    colorName: 'สีส้ม',
    label: 'ปิงปองสีส้ม: รุนแรงน้อย (Thal Intermedia)',
    badgeBg: 'bg-orange-100 text-orange-900 border-orange-300',
    badgeText: 'ปิงปองสีส้ม (รุนแรงน้อย)',
    borderColor: 'border-orange-400',
    dotColor: 'bg-orange-500 border-2 border-orange-600',
    title: 'รุนแรงน้อย (Intermedia / Hb H disease, EE)',
    description: 'อาการซีดเหลืองเล็กน้อย ให้เลือดเมื่อเจ็บป่วยติดเชื้อ ห้ามซื้อยาบำรุงธาตุเหล็กรับประทานเอง',
  },
  red: {
    colorKey: 'red',
    colorName: 'สีแดง',
    label: 'ปิงปองสีแดง: รุนแรงมาก (Thal Major)',
    badgeBg: 'bg-rose-100 text-rose-900 border-rose-300',
    badgeText: 'ปิงปองสีแดง (รุนแรงมาก)',
    borderColor: 'border-rose-400',
    dotColor: 'bg-rose-600 border-2 border-rose-700',
    title: 'รุนแรงมาก (Major / β0-thal major, β-thal/Hb E)',
    description: 'ซีดมาก ตับม้ามโต โครงหน้าเปลี่ยน ต้องรับเลือดประจำสม่ำเสมอและยาขับธาตุเหล็กตลอดชีวิต',
  },
  black: {
    colorKey: 'black',
    colorName: 'สีดำ',
    label: 'ปิงปองสีดำ: รุนแรงสูงสุด (Hb Bart’s Hydrops)',
    badgeBg: 'bg-slate-900 text-white border-slate-700',
    badgeText: 'ปิงปองสีดำ (รุนแรงสูงสุด)',
    borderColor: 'border-slate-800',
    dotColor: 'bg-slate-950 border-2 border-slate-700',
    title: 'รุนแรงสูงสุด (Lethal / Hb Bart’s hydrops fetalis)',
    description: 'ทารกบวมน้ำเสียชีวิตในครรภ์หรือหลังคลอด มารดาเสี่ยงครรภ์เป็นพิษรุนแรง (Maternal Mirror Syndrome)',
  },
};

/**
 * Interprets individual laboratory results based on MOPH Thailand guidelines
 * and maps directly to the 6-color ping-pong traffic light classification.
 */
export function interpretIndividualLab(lab: LabResult, label: string = 'ผู้รับการตรวจ'): LabInterpretationResult {
  const mcv = typeof lab.mcv === 'number' ? lab.mcv : 85;
  const mch = typeof lab.mch === 'number' ? lab.mch : 29;
  const dcip = lab.dcip;
  const typing = (lab.hbTyping || '').trim().toUpperCase();
  const ePct = typeof lab.hbePercent === 'number' ? lab.hbePercent : 0;
  const a2Pct = typeof lab.hba2Percent === 'number' ? lab.hba2Percent : 0;
  const fPct = typeof lab.hbfPercent === 'number' ? lab.hbfPercent : 0;
  const pcr = lab.pcrAlpha1 || 'Not tested';

  const isMicrocytic = mcv < 80 || mch < 27;

  // Check PCR if explicitly positive
  if (pcr === 'Positive') {
    if (typing === 'EA' || (dcip === 'Positive' && ePct > 0)) {
      return {
        conditionName: 'พาหะฮีโมโกลบิน อี ร่วมกับ พาหะอัลฟ่า-ธาลัสซีเมีย 1 (Hb E trait with α-thal 1 trait)',
        genotype: '--/αα, β/βE',
        severityCategory: 'Trait / Carrier',
        details: 'ผลการตรวจพบทั้งยีน Hb E และตรวจยีน PCR ให้ผลบวก α-thal 1 (SEA or THAI deletion) ซึ่งสามารถถ่ายทอดได้ทั้งสองยีน',
        recommendation: 'ต้องตรวจคัดกรองคู่สมรสอย่างละเอียด ทั้ง α-thal 1 และ β-thalassemia',
        isCarrierOfSevereDisease: true,
        severeDiseaseType: 'alpha',
        pingPongTag: PING_PONG_TAGS.yellow,
      };
    }
    return {
      conditionName: 'พาหะอัลฟ่า-ธาลัสซีเมีย 1 (α-thalassemia 1 trait)',
      genotype: '--/αα (SEA or THAI deletion)',
      severityCategory: 'Trait / Carrier',
      details: 'ตรวจพบการขาดหายไปของยีนอัลฟ่า-โกลบิน 2 ยีนบนโครโมโซมคู่ที่ 16 ส่งผลให้เม็ดเลือดแดงมีขนาดเล็ก (MCV < 80 fL)',
      recommendation: 'หากคู่สมรสเป็นพาหะ α-thal 1 เหมือนกัน จะมีความเสี่ยง 25% ที่ทารกจะเป็นโรค Hb Bart’s hydrops fetalis ซึ่งเสียชีวิตในครรภ์',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'alpha',
      pingPongTag: PING_PONG_TAGS.yellow,
    };
  }

  // Hb Typing based interpretation: Hb H disease
  if (typing.includes('BART') || typing.includes('HB H') || typing === 'A2AH' || typing === 'A2A BART\'S H') {
    return {
      conditionName: 'โรคฮีโมโกลบิน เอช (Hb H disease)',
      genotype: '--/-α หรือ --/αcsα',
      severityCategory: 'Disease',
      details: 'ขาดจีนอัลฟ่า 3 ยีน ทำให้เกิดการรวมตัวของ β4 (Hb H) หรือ γ4 (Hb Bart\'s) มีภาวะซีด ตับม้ามโต เม็ดเลือดแดงแตกเรื้อรัง และซีดเฉียบพลันเมื่อติดเชื้อ',
      recommendation: 'ดูแลติดตามระดับ Hb ไม่ให้ต่ำกว่า 7-8 g/dL ให้ Folic acid 5 mg/วัน และตรวจสุขภาพทารกสม่ำเสมอ',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'alpha',
      pingPongTag: PING_PONG_TAGS.orange,
    };
  }

  // Beta thal / Hb E
  if (typing === 'EF' || typing === 'EFA' || (ePct > 0 && fPct >= 10)) {
    const isBeta0 = fPct >= 20 || typing === 'EF';
    return {
      conditionName: isBeta0 ? 'โรคเบต้า-ธาลัสซีเมีย / ฮีโมโกลบิน อี (β0-thal/Hb E)' : 'โรคเบต้า-ธาลัสซีเมีย / ฮีโมโกลบิน อี (β+-thal/Hb E)',
      genotype: isBeta0 ? 'β0/βE' : 'β+/βE',
      severityCategory: 'Disease',
      details: isBeta0 
        ? 'สไลด์ 44: ผล Hb typing EF (ไม่มี Hb A, Hb F >= 20%) บ่งชี้ β0-thal/Hb E ชนิดรุนแรงมาก ถือเป็นคู่เสี่ยงที่รุนแรงชนิดที่ 3'
        : 'สไลด์ 44: ผล Hb typing EFA (มี Hb A เล็กน้อย, Hb F >= 10%) บ่งชี้ β+-thal/Hb E ซึ่งสร้างสาย β-globin ได้บางส่วน',
      recommendation: 'ถือเป็น 1 ใน 3 โรคธาลัสซีเมียชนิดรุนแรงตามนโยบายกระทรวงสาธารณสุข ต้องประเมินภาวะซีด หัวใจ และการเจริญเติบโตของทารก',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'beta',
      pingPongTag: PING_PONG_TAGS.red,
    };
  }

  // Beta thal disease (Homozygous beta thal / A2F / A2FA) - Slide 42
  if (typing === 'A2F' || typing === 'A2FA' || typing === 'FA' || (fPct >= 10 && ePct === 0 && (typing.includes('F') || typing === 'A2'))) {
    const isBeta0 = typing === 'A2F' || typing === 'FA' || fPct >= 20;
    return {
      conditionName: isBeta0 ? 'โรคเบต้า-ธาลัสซีเมีย ชนิดโฮโมไซกัส (Homozygous β0-thalassemia major)' : 'โรคเบต้า-ธาลัสซีเมีย (β+-thalassemia disease)',
      genotype: isBeta0 ? 'β0/β0' : 'β+/β0 หรือ β+/β+',
      severityCategory: 'Disease',
      details: isBeta0
        ? 'สไลด์ 42: ผล Hb typing A2F (ไม่มี Hb A, Hb F >= 20%) บ่งชี้ β0-thalassemia major ร่างกายสร้างสาย β-globin ไม่ได้เลย เป็น 1 ใน 3 โรคชนิดรุนแรง'
        : 'สไลด์ 42: ผล Hb typing A2FA (มี Hb A เหลืออยู่, Hb F >= 10%) บ่งชี้ β+-thalassemia disease สาย β-globin สร้างได้ลดลง',
      recommendation: 'คู่เสี่ยงที่รุนแรงชนิดที่ 2 ผู้ป่วยจะมีอาการซีดรุนแรง ตับม้ามโต หากตั้งครรภ์ต้องดูแลในคลินิกครรภ์เสี่ยงสูงร่วมกับแพทย์เฉพาะทาง',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'beta',
      pingPongTag: PING_PONG_TAGS.red,
    };
  }

  // Homozygous Hb E
  if (typing === 'EE' || ePct >= 80) {
    if (fPct > 5 && fPct < 20) {
      return {
        conditionName: 'สงสัย Homozygous Hb E หรือ β0-thal/Hb E (รายงาน EE/EF)',
        genotype: 'βE/βE หรือ β0/βE',
        severityCategory: 'High Risk',
        details: 'มี Hb E เด่นชัด (>80%) แต่มี Hb F สูง (5-20%) จำเป็นต้องตรวจยืนยันเพิ่มเติมเพื่อแยกกับ β-thal/Hb E',
        recommendation: 'ส่งตรวจตรวจ DNA หรือ Family study เพื่อแยกแยะโรค',
        isCarrierOfSevereDisease: true,
        severeDiseaseType: 'beta',
        pingPongTag: PING_PONG_TAGS.orange,
      };
    }
    return {
      conditionName: 'ฮีโมโกลบิน อี ชนิดโฮโมไซกัส (Homozygous Hb E)',
      genotype: 'βE/βE',
      severityCategory: 'Trait / Carrier',
      details: 'มีเม็ดเลือดแดงขนาดเล็ก ติดสีจาง (MCV < 80 fL) ส่วนใหญ่ไม่มีอาการทางคลินิกหรือมีซีดเล็กน้อย แต่เมื่อแต่งงานกับพาหะ β-thal มีความเสี่ยงลูกเป็น β-thal/Hb E',
      recommendation: 'หากคู่สมรสเป็นพาหะ β-thalassemia trait จะมีความเสี่ยงสูงที่ลูกจะเป็นโรค β-thal/Hb E',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'beta',
      pingPongTag: PING_PONG_TAGS.orange,
    };
  }

  // Hb E Trait
  if (typing === 'EA' || (dcip === 'Positive' && ePct >= 20 && ePct <= 40)) {
    const combinedAlpha = isMicrocytic && (ePct < 25 || a2Pct + ePct < 25);
    return {
      conditionName: combinedAlpha 
        ? 'พาหะฮีโมโกลบิน อี สงสัยร่วมกับพาหะอัลฟ่า-ธาลัสซีเมีย (Hb E trait suspected with α-thal)'
        : 'พาหะฮีโมโกลบิน อี (Hb E trait)',
      genotype: combinedAlpha ? 'β/βE with possible -α/αα or --/αα' : 'β/βE (αα/αα)',
      severityCategory: 'Trait / Carrier',
      details: combinedAlpha 
        ? 'Hb E < 25% ร่วมกับ MCV < 80 fL มักเกิดจากการขาดหายไปของสายอัลฟ่าร่วมด้วย ทำให้สร้างสาย Hb E ได้น้อยลง'
        : 'Hb E อยู่ระหว่าง 25-35%, DCIP ให้ผลบวก ร่างกายปกติแข็งแรง ไม่มีอาการซีด',
      recommendation: combinedAlpha
        ? 'จำเป็นต้องส่งตรวจ PCR for α-thal 1 เพิ่มเติมเพื่อแยกความเสี่ยงต่อโรค Hb Bart’s hydrops fetalis'
        : 'คู่สมรสต้องตรวจคัดกรอง หากคู่สมรสเป็นพาหะ β-thalassemia จะมีความเสี่ยงลูกเป็นโรค β-thal/Hb E 25%',
      isCarrierOfSevereDisease: true,
      severeDiseaseType: 'beta',
      pingPongTag: PING_PONG_TAGS.yellow,
    };
  }

  // Beta thal trait
  if (typing === 'A2A' || typing === 'A2' || typing === 'NORMAL') {
    if (a2Pct > 3.5 || (a2Pct >= 3.6 && a2Pct <= 8)) {
      return {
        conditionName: 'พาหะเบต้า-ธาลัสซีเมีย (β-thalassemia trait)',
        genotype: 'β0/β หรือ β+/β',
        severityCategory: 'Trait / Carrier',
        details: 'Hb A2 มีค่าสูงกว่าปกติ (> 3.5%) เม็ดเลือดแดงตัวเล็ก (MCV < 80 fL) สุขภาพแข็งแรงดีแต่เป็นพาหะทางพันธุกรรม',
        recommendation: 'หากคู่สมรสเป็น β-thal trait หรือ Hb E trait หรือ Homozygous Hb E ลูกจะมีความเสี่ยงเป็นโรคธาลัสซีเมียรุนแรง (Homozygous β-thal หรือ β-thal/Hb E)',
        isCarrierOfSevereDisease: true,
        severeDiseaseType: 'beta',
        pingPongTag: PING_PONG_TAGS.yellow,
      };
    }

    // A2A with normal A2 (< 3.5%)
    if (isMicrocytic) {
      if (pcr === 'Negative') {
        return {
          conditionName: 'พาหะอัลฟ่า-ธาลัสซีเมีย 2 หรือภาวะขาดธาตุเหล็ก (α-thal 2 trait or Iron deficiency)',
          genotype: '-α/αα หรือ Normal with IDA',
          severityCategory: 'Normal / Non-significant',
          details: 'MCV < 80 fL แต่ Hb A2 ปกติ (<3.5%) และ PCR α-thal 1 ให้ผลลบ ไม่เสี่ยงต่อ 3 โรครุนแรงของทารก',
          recommendation: 'ตรวจระดับ Serum Ferritin เพื่อแยกภาวะขาดธาตุเหล็ก หากขาดธาตุเหล็กให้เสริมยาธาตุเหล็กตามเกณฑ์',
          isCarrierOfSevereDisease: false,
          severeDiseaseType: 'none',
          pingPongTag: PING_PONG_TAGS.green,
        };
      }
      return {
        conditionName: 'สงสัยพาหะอัลฟ่า-ธาลัสซีเมีย (Suspected α-thalassemia trait)',
        genotype: 'รอผลยืนยัน PCR α-thal 1 (--/αα หรือ -α/αα)',
        severityCategory: 'High Risk',
        details: 'Hb typing A2A ปกติ (A2 < 3.5%) แต่ MCV < 80 fL หรือ MCH < 27 pg แสดงว่าเม็ดเลือดแดงขนาดเล็ก ต้องแยก α-thal 1 trait ออกจาก α-thal 2 trait',
        recommendation: 'จำเป็นต้องส่งตรวจ PCR for α-thal 1 (SEA & THAI deletion) เพื่อประเมินความเสี่ยงต่อโรค Hb Bart’s hydrops fetalis',
        isCarrierOfSevereDisease: true,
        severeDiseaseType: 'alpha',
        pingPongTag: PING_PONG_TAGS.green,
      };
    }

    return {
      conditionName: 'ปกติ ไม่เป็นพาหะธาลัสซีเมียชนิดรุนแรง (Normal non-clinical significant)',
      genotype: 'αα/αα, β/β',
      severityCategory: 'Normal / Non-significant',
      details: 'ดัชนีเม็ดเลือดแดง MCV >= 80 fL, MCH >= 27 pg, DCIP ผลลบ, Hb typing A2A (A2 2.5-3.5%)',
      recommendation: 'ไม่มีความเสี่ยงในการถ่ายทอดโรคธาลัสซีเมียชนิดรุนแรง 3 โรค ให้การดูแลสุขภาพการตั้งครรภ์ตามมาตรฐานปกติ',
      isCarrierOfSevereDisease: false,
      severeDiseaseType: 'none',
      pingPongTag: PING_PONG_TAGS.white,
    };
  }

  // Default fallback if DCIP is positive without detailed typing
  if (dcip === 'Positive') {
    return {
      conditionName: 'ผลตรวจคัดกรอง DCIP เป็นบวก (Positive DCIP Screen)',
      genotype: 'รอตรวจยืนยัน Hb Typing',
      severityCategory: 'High Risk',
      details: 'DCIP บวกบ่งชี้ถึง Unstable Hb โดยเฉพาะ Hb E หรือ Hb H',
      recommendation: 'ต้องส่งตรวจยืนยันด้วยวิธี Hb Typing (HPLC/CE) ทันที',
      isCarrierOfSevereDisease: true,
      pingPongTag: PING_PONG_TAGS.yellow,
    };
  }

  if (isMicrocytic) {
    return {
      conditionName: 'เม็ดเลือดแดงขนาดเล็กผิดปกติ (Microcytic RBC)',
      genotype: 'MCV < 80 fL หรือ MCH < 27 pg',
      severityCategory: 'High Risk',
      details: 'ผลคัดกรองผิดปกติ อาจเป็นพาหะธาลัสซีเมีย (α-thal หรือ β-thal) หรือภาวะขาดธาตุเหล็ก',
      recommendation: 'ส่งตรวจ Hb Typing และหาก Hb A2 ปกติ (<3.5%) ให้ส่ง PCR α-thal 1 ร่วมด้วย',
      isCarrierOfSevereDisease: true,
      pingPongTag: PING_PONG_TAGS.green,
    };
  }

  return {
    conditionName: 'ผลการตรวจคัดกรองเบื้องต้นปกติ',
    genotype: 'Normal Screening',
    severityCategory: 'Normal / Non-significant',
    details: 'MCV >= 80 fL และ DCIP ให้ผลลบ',
    recommendation: 'ตรวจคู่สมรสตามแนวทางกระทรวงสาธารณสุข',
    isCarrierOfSevereDisease: false,
    pingPongTag: PING_PONG_TAGS.white,
  };
}

/**
 * Evaluates couple risk and calculates exact genetic risk percentages, Punnett square,
 * and attaches 6-color ping-pong traffic light tags for mother, father, and offspring outcomes.
 */
export function evaluateCoupleRisk(
  wifeLab: LabResult,
  husbandLab: LabResult
): CoupleRiskAssessment {
  const wifeInterp = interpretIndividualLab(wifeLab, 'ภรรยา');
  const husbandInterp = interpretIndividualLab(husbandLab, 'สามี');

  const wifeHasAlpha1 = wifeInterp.conditionName.includes('α-thalassemia 1') || 
    wifeInterp.conditionName.includes('α-thal 1') || 
    (wifeInterp.genotype.includes('--/αα') && wifeLab.pcrAlpha1 === 'Positive');

  const husbandHasAlpha1 = husbandInterp.conditionName.includes('α-thalassemia 1') || 
    husbandInterp.conditionName.includes('α-thal 1') || 
    (husbandInterp.genotype.includes('--/αα') && husbandLab.pcrAlpha1 === 'Positive');

  const wifeHasBetaTrait = wifeInterp.conditionName.includes('β-thalassemia trait') || 
    (wifeLab.hba2Percent && Number(wifeLab.hba2Percent) > 3.5);

  const husbandHasBetaTrait = husbandInterp.conditionName.includes('β-thalassemia trait') || 
    (husbandLab.hba2Percent && Number(husbandLab.hba2Percent) > 3.5);

  const wifeHasBetaDisease = wifeInterp.conditionName.includes('β0-thalassemia') ||
    wifeInterp.conditionName.includes('β+-thalassemia') ||
    wifeLab.hbTyping.toUpperCase() === 'A2F' ||
    wifeLab.hbTyping.toUpperCase() === 'A2FA';

  const husbandHasBetaDisease = husbandInterp.conditionName.includes('β0-thalassemia') ||
    husbandInterp.conditionName.includes('β+-thalassemia') ||
    husbandLab.hbTyping.toUpperCase() === 'A2F' ||
    husbandLab.hbTyping.toUpperCase() === 'A2FA';

  const wifeHasE = wifeInterp.conditionName.includes('ฮีโมโกลบิน อี') || 
    wifeLab.hbTyping.toUpperCase() === 'EA' || 
    wifeLab.hbTyping.toUpperCase() === 'EE';

  const husbandHasE = husbandInterp.conditionName.includes('ฮีโมโกลบิน อี') || 
    husbandLab.hbTyping.toUpperCase() === 'EA' || 
    husbandLab.hbTyping.toUpperCase() === 'EE';

  const wifeIsEE = wifeLab.hbTyping.toUpperCase() === 'EE' || (wifeLab.hbePercent && Number(wifeLab.hbePercent) >= 80);
  const husbandIsEE = husbandLab.hbTyping.toUpperCase() === 'EE' || (husbandLab.hbePercent && Number(husbandLab.hbePercent) >= 80);

  // 1. Hb Bart's Hydrops Fetalis: both alpha-thal 1
  if (wifeHasAlpha1 && husbandHasAlpha1) {
    return {
      riskLevel: 'High Risk (คู่เสี่ยงรุนแรง)',
      targetDisease: 'โรคทารกบวมน้ำ ฮีโมโกลบิน บาร์ท (Hb Bart’s hydrops fetalis)',
      diseaseChance: 25,
      carrierChance: 50,
      normalChance: 25,
      explanation: 'คู่สมรสทั้งสองฝ่ายเป็นพาหะ α-thalassemia 1 (--/αα) ลูกมีโอกาส 25% (1 ใน 4) ที่จะได้รับโครโมโซมคู่ที่ขาดหายทั้ง 4 ยีน กลายเป็น --/-- (Hb Bart’s hydrops fetalis) ซึ่งทารกจะเสียชีวิตในครรภ์หรือหลังคลอด และมารดาเสี่ยงครรภ์เป็นพิษรุนแรง ตกเลือดหลังคลอด',
      punnettSquare: {
        fatherGametes: ['--', 'αα'],
        motherGametes: ['--', 'αα'],
        combinations: ['--/--', '--/αα', '--/αα', 'αα/αα'],
        phenotypes: [
          'เป็นโรค Hb Bart’s hydrops fetalis (25%)',
          'พาหะ α-thal 1 trait (25%)',
          'พาหะ α-thal 1 trait (25%)',
          'ปกติ (25%)',
        ],
        phenotypePingPongs: [
          PING_PONG_TAGS.black,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.white,
        ],
      },
      recommendedNextSteps: [
        'อธิบายผลและประคับประคองจิตใจทั้งคู่พร้อมกันในห้องส่วนตัว',
        'ให้ทางเลือกการตรวจวินิจฉัยก่อนคลอด (PND): CVS (9-12 สัปดาห์) หรือ Amniocentesis (16-18 สัปดาห์) หรือ Cordocentesis (18-22 สัปดาห์)',
        'อัลตราซาวด์ติดตามขนาดรก (Placental thickness) และภาวะบวมน้ำ (Hydrops)',
        'หากทารกเป็นโรค แนะนำทางเลือกยุติการตั้งครรภ์เพื่อความปลอดภัยของมารดา หรือตั้งครรภ์ต่อภายใต้การดูแลใกล้ชิด',
      ],
      wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.yellow,
      husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.yellow,
      diseasePingPong: PING_PONG_TAGS.black,
      carrierPingPong: PING_PONG_TAGS.yellow,
      normalPingPong: PING_PONG_TAGS.white,
    };
  }

  // 2. Homozygous Beta-thalassemia
  if (wifeHasBetaTrait && husbandHasBetaTrait) {
    return {
      riskLevel: 'High Risk (คู่เสี่ยงรุนแรง)',
      targetDisease: 'โรคเบต้า-ธาลัสซีเมีย เมเจอร์ (Homozygous β-thalassemia)',
      diseaseChance: 25,
      carrierChance: 50,
      normalChance: 25,
      explanation: 'คู่สมรสทั้งสองฝ่ายเป็นพาหะ β-thalassemia trait (β0/β หรือ β+/β) ลูกมีโอกาส 25% ที่จะเป็นโรค β-thalassemia major (β0/β0) อาการซีดรุนแรงตั้งแต่ขวบปีแรก ตับม้ามโต ใบหน้า thalassemia face ต้องรับเลือดและยาขับธาตุเหล็กตลอดชีวิต',
      punnettSquare: {
        fatherGametes: ['β0', 'β'],
        motherGametes: ['β0', 'β'],
        combinations: ['β0/β0', 'β0/β', 'β/β0', 'β/β'],
        phenotypes: [
          'เป็นโรค Homozygous β-thal (25%)',
          'พาหะ β-thal trait (25%)',
          'พาหะ β-thal trait (25%)',
          'ปกติ (25%)',
        ],
        phenotypePingPongs: [
          PING_PONG_TAGS.red,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.white,
        ],
      },
      recommendedNextSteps: [
        'ให้คำปรึกษาทางพันธุศาสตร์ (Genetic counseling) ร่วมกันทั้งคู่',
        'ส่งตรวจวินิจฉัยก่อนคลอด (PND): Amniocentesis หรือ CVS ตรวจ DNA mapping',
        'ให้ข้อมูลธรรมชาติของโรค การดูแลรักษา ค่าใช้จ่าย และทางเลือกในการตัดสินใจ',
      ],
      wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.yellow,
      husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.yellow,
      diseasePingPong: PING_PONG_TAGS.red,
      carrierPingPong: PING_PONG_TAGS.yellow,
      normalPingPong: PING_PONG_TAGS.white,
    };
  }

  // 3. Beta-thalassemia / Hb E
  if (((wifeHasBetaTrait || wifeHasBetaDisease) && husbandHasE) || ((husbandHasBetaTrait || husbandHasBetaDisease) && wifeHasE)) {
    const isOneEE = wifeIsEE || husbandIsEE;
    const isOneBetaDisease = wifeHasBetaDisease || husbandHasBetaDisease;
    const diseaseChance = (isOneEE || isOneBetaDisease) ? 50 : 25;
    const carrierChance = (isOneEE || isOneBetaDisease) ? 50 : 50;
    const normalChance = (isOneEE || isOneBetaDisease) ? 0 : 25;

    let explanationText = '';
    if (isOneBetaDisease) {
      explanationText = 'สไลด์ 45 (Family Study): ฝ่ายที่เป็นโรค β0-thalassemia major (A2F: β0/β0) จะส่งต่อยีน β0 ให้แก่ลูกทุกคน (100%) และอีกฝ่ายเป็นพาหะ Hb E trait (EA: β/βE) ที่ส่งต่อยีนปกติ β (50%) หรือยีน βE (50%) ผลลัพธ์คือลูกไม่มีโอกาสปกติเลย (0%) โดยมีโอกาสเป็นโรค β-thal/Hb E (β0/βE) ร้อยละ 50 และเป็นพาหะ β-thal trait (β0/β) ร้อยละ 50';
    } else if (isOneEE) {
      explanationText = 'ฝ่ายหนึ่งเป็น Homozygous Hb E (βE/βE) และอีกฝ่ายเป็น β-thal trait (β0/β) ลูกมีโอกาส 50% ที่จะเป็นโรค β-thal/Hb E (β0/βE) และ 50% เป็นพาหะ';
    } else {
      explanationText = 'ฝ่ายหนึ่งเป็น β-thal trait (β0/β) และอีกฝ่ายเป็น Hb E trait (β/βE) ลูกมีโอกาส 25% ที่จะเป็นโรค β-thal/Hb E ซึ่งพบได้บ่อยที่สุดในภาคอีสาน อาการซีด ปานกลางถึงรุนแรงมาก ตับม้ามโต';
    }

    const fatherGametes: [string, string] = husbandHasBetaDisease 
      ? ['β0', 'β0'] 
      : (wifeHasBetaTrait || wifeHasBetaDisease) 
        ? (husbandIsEE ? ['βE', 'βE'] : ['β', 'βE']) 
        : ['β0', 'β'];

    const motherGametes: [string, string] = wifeHasBetaDisease
      ? ['β0', 'β0']
      : (wifeHasBetaTrait || wifeHasBetaDisease)
        ? ['β0', 'β']
        : (wifeIsEE ? ['βE', 'βE'] : ['β', 'βE']);

    const combinations: [string, string, string, string] = isOneBetaDisease
      ? ['β0/β', 'β0/βE', 'β0/β', 'β0/βE']
      : isOneEE 
        ? ['β0/βE', 'β0/βE', 'β/βE', 'β/βE']
        : ['β0/βE', 'β0/β', 'β/βE', 'β/β'];

    const phenotypes: [string, string, string, string] = isOneBetaDisease
      ? ['พาหะ β-thal trait (50%)', 'เป็นโรค β-thal/Hb E (50%)', 'พาหะ β-thal trait (50%)', 'เป็นโรค β-thal/Hb E (50%)']
      : isOneEE
        ? ['เป็นโรค β-thal/Hb E (50%)', 'เป็นโรค β-thal/Hb E (50%)', 'พาหะ Hb E (50%)', 'พาหะ Hb E (50%)']
        : ['เป็นโรค β-thal/Hb E (25%)', 'พาหะ β-thal trait (25%)', 'พาหะ Hb E trait (25%)', 'ปกติ (25%)'];

    const phenotypePingPongs: PingPongColorTag[] = isOneBetaDisease
      ? [PING_PONG_TAGS.yellow, PING_PONG_TAGS.red, PING_PONG_TAGS.yellow, PING_PONG_TAGS.red]
      : isOneEE
        ? [PING_PONG_TAGS.red, PING_PONG_TAGS.red, PING_PONG_TAGS.yellow, PING_PONG_TAGS.yellow]
        : [PING_PONG_TAGS.red, PING_PONG_TAGS.yellow, PING_PONG_TAGS.yellow, PING_PONG_TAGS.white];

    return {
      riskLevel: 'High Risk (คู่เสี่ยงรุนแรง)',
      targetDisease: 'โรคเบต้า-ธาลัสซีเมีย / ฮีโมโกลบิน อี (β-thalassemia / Hb E disease)',
      diseaseChance,
      carrierChance,
      normalChance,
      explanation: explanationText,
      punnettSquare: {
        fatherGametes,
        motherGametes,
        combinations,
        phenotypes,
        phenotypePingPongs,
      },
      recommendedNextSteps: [
        'ให้ข้อมูลทางเลือกในการตรวจก่อนคลอด (PND) เช่น Amniocentesis เพื่อวิเคราะห์ยีนของทารก',
        'อธิบายถึงความแปรปรวนทางคลินิกของโรค β-thal/Hb E และการวางแผนดูแล (อ้างอิงสไลด์ 44-45)',
        'สนับสนุนการตัดสินใจของบิดามารดาด้วยความเคารพและไม่ชี้นำ',
      ],
      wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.yellow,
      husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.yellow,
      diseasePingPong: PING_PONG_TAGS.red,
      carrierPingPong: PING_PONG_TAGS.yellow,
      normalPingPong: PING_PONG_TAGS.white,
    };
  }

  // Need more tests: e.g. One or both have microcytosis without PCR
  const wifeNeedsPcr = (wifeLab.mcv !== '' && Number(wifeLab.mcv) < 80 && wifeLab.hbTyping.toUpperCase().includes('A2A') && wifeLab.pcrAlpha1 === 'Not tested');
  const husbandNeedsPcr = (husbandLab.mcv !== '' && Number(husbandLab.mcv) < 80 && husbandLab.hbTyping.toUpperCase().includes('A2A') && husbandLab.pcrAlpha1 === 'Not tested');

  if (wifeNeedsPcr || husbandNeedsPcr) {
    return {
      riskLevel: 'Low Risk / Carrier Only',
      targetDisease: 'ยังไม่สามารถตัดความเสี่ยง Hb Bart’s hydrops fetalis ได้',
      diseaseChance: 0,
      carrierChance: 50,
      normalChance: 50,
      explanation: 'พบเม็ดเลือดแดงขนาดเล็ก (MCV < 80 fL) แต่ Hb typing เป็น A2A ปกติ จำเป็นต้องตรวจ PCR for α-thalassemia 1 เพื่อพิสูจน์ว่าเป็นพาหะ α-thal 1 หรือไม่ หากทั้งคู่เป็นพาหะ α-thal 1 จะกลายเป็นคู่เสี่ยงสูง 25%',
      punnettSquare: {
        fatherGametes: ['?', '?'],
        motherGametes: ['?', '?'],
        combinations: ['รอผล', 'รอผล', 'รอผล', 'รอผล'],
        phenotypes: ['รอผล PCR ยืนยัน', 'รอผล PCR ยืนยัน', 'รอผล PCR ยืนยัน', 'รอผล PCR ยืนยัน'],
        phenotypePingPongs: [
          PING_PONG_TAGS.green,
          PING_PONG_TAGS.green,
          PING_PONG_TAGS.green,
          PING_PONG_TAGS.green,
        ],
      },
      recommendedNextSteps: [
        'ส่งตรวจ PCR for α-thalassemia 1 (SEA deletion & THAI deletion) ด่วน',
        'นัดฟังผลและตรวจยืนยันก่อนตัดสินใจวางแผนตั้งครรภ์ต่อไป',
      ],
      wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.green,
      husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.green,
      diseasePingPong: PING_PONG_TAGS.green,
      carrierPingPong: PING_PONG_TAGS.green,
      normalPingPong: PING_PONG_TAGS.white,
    };
  }

  // Safe or only trait combinations that don't cause the 3 severe diseases
  // e.g. Homozygous Hb E + Alpha thal trait -> baby will only be double trait (E trait + alpha trait), not severe disease
  if ((wifeIsEE && husbandHasAlpha1) || (husbandIsEE && wifeHasAlpha1)) {
    return {
      riskLevel: 'Low Risk / Carrier Only',
      targetDisease: 'ไม่มีความเสี่ยงต่อ 3 โรครุนแรง (เสี่ยงเป็นพาหะคู่เท่านั้น)',
      diseaseChance: 0,
      carrierChance: 100,
      normalChance: 0,
      explanation: 'ฝ่ายหนึ่งมีปัญหาที่ยีนเบต้า (Homozygous Hb E, βE/βE) แต่อีกฝ่ายมีความผิดปกติที่ยีนอัลฟ่า (--/αα) ยีนอยู่คนละโครโมโซม ลูกจะได้รับยีน βE 1 ยีน และมีโอกาส 50% ได้รับยีน α-thal 1 ทำให้ลูกอาจเป็นพาหะร่วม (Hb EA with α-thal 1) ซึ่งไม่มีอาการรุนแรง',
      punnettSquare: {
        fatherGametes: wifeIsEE ? ['--', 'αα'] : ['βE', 'βE'],
        motherGametes: wifeIsEE ? ['βE', 'βE'] : ['--', 'αα'],
        combinations: ['βE/β + --/αα', 'βE/β + αα/αα', 'βE/β + --/αα', 'βE/β + αα/αα'],
        phenotypes: [
          'พาหะ EA ร่วมกับ α-thal 1 (50%)',
          'พาหะ Hb E trait (50%)',
          'พาหะ EA ร่วมกับ α-thal 1 (50%)',
          'พาหะ Hb E trait (50%)',
        ],
        phenotypePingPongs: [
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.yellow,
          PING_PONG_TAGS.yellow,
        ],
      },
      recommendedNextSteps: [
        'อธิบายให้คู่สมรสคลายความกังวลว่าลูกไม่มีความเสี่ยงต่อ 3 โรครุนแรงที่เสียชีวิตหรือต้องถ่ายเลือดตลอดชีวิต',
        'ให้การดูแลฝากครรภ์ตามมาตรฐานปกติ',
      ],
      wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.orange,
      husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.yellow,
      diseasePingPong: PING_PONG_TAGS.white,
      carrierPingPong: PING_PONG_TAGS.yellow,
      normalPingPong: PING_PONG_TAGS.white,
    };
  }

  return {
    riskLevel: 'Normal / Safe',
    targetDisease: 'ไม่พบความเสี่ยงต่อโรคธาลัสซีเมียชนิดรุนแรง 3 โรค',
    diseaseChance: 0,
    carrierChance: wifeInterp.isCarrierOfSevereDisease || husbandInterp.isCarrierOfSevereDisease ? 50 : 0,
    normalChance: wifeInterp.isCarrierOfSevereDisease || husbandInterp.isCarrierOfSevereDisease ? 50 : 100,
    explanation: 'จากผลการตรวจคัดกรองและการตรวจยืนยันของคู่สมรส ไม่พบความเสี่ยงที่จะให้กำเนิดบุตรเป็นโรคธาลัสซีเมียชนิดรุนแรง 3 โรคตามนโยบายกระทรวงสาธารณสุข',
    punnettSquare: {
      fatherGametes: ['N', 'N'],
      motherGametes: ['N', 'N'],
      combinations: ['N/N', 'N/N', 'N/N', 'N/N'],
      phenotypes: ['ปกติ (100%)', 'ปกติ (100%)', 'ปกติ (100%)', 'ปกติ (100%)'],
      phenotypePingPongs: [
        PING_PONG_TAGS.white,
        PING_PONG_TAGS.white,
        PING_PONG_TAGS.white,
        PING_PONG_TAGS.white,
      ],
    },
    recommendedNextSteps: [
      'ให้คำแนะนำการส่งเสริมสุขภาพขณะตั้งครรภ์ รับประทานอาหารครบ 5 หมู่ ตามหลัก 3 อ 3 ลด',
      'ตรวจสุขภาพและนัดตรวจตามมาตรฐานการฝากครรภ์คุณภาพ (WBC, Hb, Blood group, Syphilis, HIV, Hepatitis B)',
    ],
    wifePingPong: wifeInterp.pingPongTag || PING_PONG_TAGS.white,
    husbandPingPong: husbandInterp.pingPongTag || PING_PONG_TAGS.white,
    diseasePingPong: PING_PONG_TAGS.white,
    carrierPingPong: PING_PONG_TAGS.yellow,
    normalPingPong: PING_PONG_TAGS.white,
  };
}
