import React, { useState, useEffect } from 'react';
import { 
  FileCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  RotateCcw, 
  Flag, 
  ChevronLeft, 
  ChevronRight, 
  Send,
  BookOpen,
  Award,
  Lock,
  MousePointerClick
} from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data/quizQuestions';
import { QuizResult, GateType } from '../types';

interface QuizViewProps {
  quizResult: QuizResult | null;
  onSaveQuizResult: (result: QuizResult) => void;
  onProgressChange?: (answeredCount: number, correctCount: number) => void;
  onGoToAnalytics: () => void;
  onGoToRoster?: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({
  quizResult,
  onSaveQuizResult,
  onProgressChange,
  onGoToAnalytics,
  onGoToRoster,
}) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>(quizResult?.userAnswers || {});
  const [flagged, setFlagged] = useState<Record<number, boolean>>({});
  const [submitted, setSubmitted] = useState<boolean>(quizResult?.completed || false);
  const [timerSeconds, setTimerSeconds] = useState<number>(3600); // 60 mins

  // Timer effect while taking exam
  useEffect(() => {
    if (submitted) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSubmitExam(answers);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [submitted, answers]);

  const currentQ = QUIZ_QUESTIONS[currentIdx];
  const isCurrentAnswered = answers[currentQ.id] !== undefined;
  const selectedOpt = answers[currentQ.id];

  const handleSubmitExam = (currentAnswers: Record<number, number> = answers) => {
    let correctCount = 0;
    const categoryScores: Record<string, { correct: number; total: number }> = {};
    const gateScores: Record<GateType, { correct: number; total: number }> = {
      gate1_match: { correct: 0, total: 0 },
      gate2_pregnancy: { correct: 0, total: 0 },
      gate3_birth: { correct: 0, total: 0 },
    };

    QUIZ_QUESTIONS.forEach((q) => {
      if (!categoryScores[q.category]) {
        categoryScores[q.category] = { correct: 0, total: 0 };
      }
      categoryScores[q.category].total += 1;
      gateScores[q.gate].total += 1;

      if (currentAnswers[q.id] === q.correctAnswer) {
        correctCount += 1;
        categoryScores[q.category].correct += 1;
        gateScores[q.gate].correct += 1;
      }
    });

    const percentage = Math.round((correctCount / QUIZ_QUESTIONS.length) * 100);
    const passed = percentage >= 70; // 70% passing grade

    const result: QuizResult = {
      completed: true,
      score: correctCount,
      totalQuestions: QUIZ_QUESTIONS.length,
      percentage,
      userAnswers: currentAnswers,
      categoryScores,
      gateScores,
      dateCompleted: new Date().toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
      passed,
    };

    setSubmitted(true);
    onSaveQuizResult(result);
  };

  // Allow clicking to select an answer ONLY ONCE per question, then immediately show explanation
  const handleSelectAnswer = (qId: number, optIdx: number) => {
    if (answers[qId] !== undefined || submitted) return;

    const updatedAnswers = {
      ...answers,
      [qId]: optIdx,
    };
    setAnswers(updatedAnswers);

    const newAnsweredCount = Object.keys(updatedAnswers).length;
    const newCorrectCount = QUIZ_QUESTIONS.reduce(
      (acc, q) =>
        updatedAnswers[q.id] !== undefined && updatedAnswers[q.id] === q.correctAnswer
          ? acc + 1
          : acc,
      0
    );
    if (onProgressChange) {
      onProgressChange(newAnsweredCount, newCorrectCount);
    }

    // If all 40 questions have been answered, automatically save the final score while keeping explanation visible
    if (newAnsweredCount === QUIZ_QUESTIONS.length) {
      handleSubmitExam(updatedAnswers);
    }
  };

  const toggleFlag = (qId: number) => {
    setFlagged((prev) => ({
      ...prev,
      [qId]: !prev[qId],
    }));
  };

  const handleResetExam = () => {
    setAnswers({});
    setFlagged({});
    setSubmitted(false);
    setCurrentIdx(0);
    setTimerSeconds(3600);
    if (onProgressChange) {
      onProgressChange(0, 0);
    }
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(answers).length;
  const currentCorrectCount = QUIZ_QUESTIONS.reduce(
    (acc, q) => (answers[q.id] !== undefined && answers[q.id] === q.correctAnswer ? acc + 1 : acc),
    0
  );

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold mb-2">
              <FileCheck className="w-3.5 h-3.5" />
              <span>One-Attempt Immediate Feedback Assessment</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              แบบทดสอบประเมินผลสัมฤทธิ์ 40 ข้อ (4 ตัวเลือก)
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              แต่ละข้อสามารถ<strong>คลิกเลือกคำตอบได้เพียง 1 ครั้งเท่านั้น</strong> เมื่อคลิกเลือกแล้วระบบจะล็อกคำตอบและแสดงคำอธิบายเฉลย (Rationale) ทันที เกณฑ์ผ่านร้อยละ 70 เพื่อรับใบประกาศนียบัตรอิเล็กทรอนิกส์ (E-Certificate)
            </p>
          </div>

          {/* Status & Timer */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {onGoToRoster && (
              <button
                onClick={onGoToRoster}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow transition flex items-center gap-1.5"
              >
                <Award className="w-3.5 h-3.5" />
                <span>ดูคะแนนของผู้เรียนทุกคน</span>
              </button>
            )}

            <div className="bg-slate-950/70 px-3.5 py-2 rounded-xl border border-slate-800 flex items-center gap-2 text-xs">
              <Lock className="w-3.5 h-3.5 text-pink-400" />
              <span className="text-slate-200 font-semibold">ตอบได้ 1 ครั้ง/ข้อ • เฉลยทันที</span>
            </div>

            {!submitted && (
              <div className="flex items-center gap-2 bg-slate-950/70 px-3.5 py-2 rounded-xl border border-slate-800 text-sky-300 font-mono text-xs">
                <Clock className="w-4 h-4 text-sky-400" />
                <span>{formatTimer(timerSeconds)}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Submission Result Ribbon if submitted */}
      {submitted && (
        <div
          className={`p-5 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md ${
            quizResult?.passed
              ? 'bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-300'
              : 'bg-gradient-to-r from-amber-50 to-rose-50 border-amber-300'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-white shadow-md ${
                quizResult?.passed ? 'bg-emerald-600' : 'bg-amber-500'
              }`}
            >
              {quizResult?.passed ? <Award className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                {quizResult?.passed ? 'ยินดีด้วย! คุณผ่านเกณฑ์การประเมิน' : 'ยังไม่ผ่านเกณฑ์การประเมิน (เกณฑ์ 70%)'}
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                คะแนนของคุณ: <strong className="text-slate-900">{quizResult?.score} / 40 ข้อ ({quizResult?.percentage}%)</strong> &bull; วันที่ประเมิน: {quizResult?.dateCompleted}
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <button
              onClick={handleResetExam}
              className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ทำแบบทดสอบใหม่</span>
            </button>
            {onGoToRoster && (
              <button
                onClick={onGoToRoster}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-xs transition flex items-center gap-1.5"
              >
                <Award className="w-3.5 h-3.5" />
                <span>ดูคะแนนผู้เรียนทุกคน</span>
              </button>
            )}
            <button
              onClick={onGoToAnalytics}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-sm transition flex items-center gap-1.5"
            >
              <Award className="w-3.5 h-3.5 text-pink-400" />
              <span>ดูผลวิเคราะห์ & เกียรติบัตร</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Quiz Layout: Question Workspace + Navigation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Question Panel */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
          {/* Question Metadata */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-900 text-white">
                ข้อที่ {currentQ.id} / 40
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {currentQ.category}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {isCurrentAnswered ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                  <Lock className="w-3.5 h-3.5 text-slate-500" />
                  <span>ตอบแล้ว (เลือกข้อ {String.fromCharCode(65 + selectedOpt)})</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200">
                  <MousePointerClick className="w-3.5 h-3.5" />
                  <span>คลิกเลือกคำตอบได้ 1 ครั้ง</span>
                </span>
              )}

              <button
                onClick={() => toggleFlag(currentQ.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium border transition ${
                  flagged[currentQ.id]
                    ? 'bg-amber-50 text-amber-700 border-amber-300 font-bold'
                    : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                }`}
                title="ทำเครื่องหมายข้อนี้ไว้ทบทวน"
              >
                <Flag className={`w-3.5 h-3.5 ${flagged[currentQ.id] ? 'fill-amber-500 text-amber-500' : ''}`} />
                <span className="hidden sm:inline">ปักหมุด</span>
              </button>
            </div>
          </div>

          {/* Question Text */}
          <div className="text-sm sm:text-base font-bold text-slate-900 leading-relaxed">
            {currentQ.question}
          </div>

          {/* 4 Options - Locked after 1 click */}
          <div className="space-y-2.5">
            {currentQ.options.map((opt, optIdx) => {
              const isSelected = selectedOpt === optIdx;
              const isCorrect = currentQ.correctAnswer === optIdx;
              const showFeedback = isCurrentAnswered || submitted;

              let style = 'border-slate-200 hover:border-pink-400 hover:bg-pink-50/30 text-slate-800 cursor-pointer';
              let badgeStyle = 'border-slate-300 text-slate-700 bg-white';

              if (showFeedback) {
                if (isCorrect) {
                  style = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-semibold ring-1 ring-emerald-500 cursor-default';
                  badgeStyle = 'border-emerald-600 bg-emerald-600 text-white';
                } else if (isSelected && !isCorrect) {
                  style = 'border-rose-400 bg-rose-50 text-rose-950 font-semibold ring-1 ring-rose-400 cursor-default';
                  badgeStyle = 'border-rose-600 bg-rose-600 text-white';
                } else {
                  style = 'border-slate-200 opacity-55 text-slate-400 bg-slate-50/50 cursor-default';
                  badgeStyle = 'border-slate-300 text-slate-400 bg-slate-100';
                }
              }

              return (
                <button
                  key={optIdx}
                  disabled={isCurrentAnswered || submitted}
                  onClick={() => handleSelectAnswer(currentQ.id, optIdx)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs sm:text-sm flex items-start gap-3 ${style}`}
                >
                  <span className={`w-6 h-6 rounded-full border font-bold flex items-center justify-center flex-shrink-0 text-xs mt-0.5 ${badgeStyle}`}>
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span className="flex-1 leading-relaxed">{opt}</span>
                  {showFeedback && isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  )}
                  {showFeedback && isSelected && !isCorrect && (
                    <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Rationale & Feedback (Shown immediately after selecting an answer) */}
          {isCurrentAnswered && (
            <div
              className={`p-4 rounded-xl text-xs leading-relaxed space-y-2 transition-all ${
                selectedOpt === currentQ.correctAnswer
                  ? 'bg-emerald-50/90 border border-emerald-300 text-emerald-950'
                  : 'bg-rose-50/90 border border-rose-300 text-rose-950'
              }`}
            >
              <div className="font-bold flex items-center justify-between flex-wrap gap-2 text-[13px]">
                <div className="flex items-center gap-1.5">
                  {selectedOpt === currentQ.correctAnswer ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span>
                        คำตอบถูกต้อง! (คุณเลือกข้อ {String.fromCharCode(65 + selectedOpt)})
                      </span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                      <span>
                        คำตอบยังไม่ถูกต้อง (คุณเลือกข้อ {String.fromCharCode(65 + selectedOpt)} &bull; คำตอบที่ถูกต้องคือ ข้อ {String.fromCharCode(65 + currentQ.correctAnswer)})
                      </span>
                    </>
                  )}
                </div>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-white/80 border border-current/20">
                  เฉลยข้อที่ {currentQ.id}
                </span>
              </div>

              <div className="pt-1 border-t border-current/10">
                <p className="text-xs leading-relaxed">
                  <strong className="font-semibold">คำอธิบายเหตุผล (Rationale): </strong>
                  {currentQ.rationale}
                </p>
              </div>

              {currentQ.slideRef && (
                <div className="text-[11px] opacity-80 flex items-center gap-1 pt-1">
                  <BookOpen className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>อ้างอิง: {currentQ.slideRef}</span>
                </div>
              )}
            </div>
          )}

          {/* Navigation Prev / Next */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <button
              onClick={() => setCurrentIdx((prev) => Math.max(0, prev - 1))}
              disabled={currentIdx === 0}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:hover:bg-transparent transition"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>ข้อก่อนหน้า</span>
            </button>

            <span className="text-xs text-slate-500 font-medium">
              ข้อ {currentIdx + 1} จาก {QUIZ_QUESTIONS.length}
            </span>

            {currentIdx < QUIZ_QUESTIONS.length - 1 ? (
              <button
                onClick={() => setCurrentIdx((prev) => Math.min(QUIZ_QUESTIONS.length - 1, prev + 1))}
                className="inline-flex items-center gap-1 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition"
              >
                <span>ข้อถัดไป</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => handleSubmitExam(answers)}
                className="inline-flex items-center gap-1 px-4 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-pink-600 to-sky-600 hover:from-pink-500 hover:to-sky-500 text-white shadow-sm transition"
              >
                <Send className="w-3.5 h-3.5" />
                <span>สรุปผลคะแนน (Submit)</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Navigation & Question Matrix */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h4 className="font-bold text-slate-900 text-xs">
                ผังข้อสอบ 40 ข้อ (Question Sheet)
              </h4>
              <span className="text-xs font-semibold text-pink-600">
                ตอบแล้ว {answeredCount} / 40 (ถูก {currentCorrectCount} ข้อ)
              </span>
            </div>

            {/* Matrix Legend */}
            <div className="flex items-center gap-3 text-[10px] text-slate-500 flex-wrap">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-emerald-600"></span> ตอบถูก
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-rose-500"></span> ตอบผิด
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-slate-100 border border-slate-300"></span> ยังไม่ตอบ
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-amber-400"></span> ปักหมุด
              </span>
            </div>

            {/* 40 Question Grid */}
            <div className="grid grid-cols-8 sm:grid-cols-8 gap-1.5 text-xs font-semibold">
              {QUIZ_QUESTIONS.map((q, idx) => {
                const isCurrent = currentIdx === idx;
                const isAnswered = answers[q.id] !== undefined;
                const isCorrectAnswer = isAnswered && answers[q.id] === q.correctAnswer;
                const isFlagged = flagged[q.id];

                let bg = 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100';
                if (isAnswered) {
                  bg = isCorrectAnswer
                    ? 'bg-emerald-600 text-white border-emerald-700'
                    : 'bg-rose-500 text-white border-rose-600';
                }
                if (isFlagged) {
                  bg = 'bg-amber-400 text-slate-950 border-amber-500 font-bold';
                }
                if (isCurrent) {
                  bg += ' ring-2 ring-blue-500 ring-offset-1 scale-105';
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentIdx(idx)}
                    className={`h-8 rounded-lg border flex items-center justify-center transition-all text-xs ${bg}`}
                  >
                    {q.id}
                  </button>
                );
              })}
            </div>

            {/* Progress Bar */}
            <div className="pt-2">
              <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                <span>ความคืบหน้าการทำข้อสอบ</span>
                <span>{Math.round((answeredCount / 40) * 100)}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-pink-500 to-sky-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${(answeredCount / 40) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Submit Button */}
            {!submitted && (
              <button
                onClick={() => handleSubmitExam(answers)}
                className="w-full py-2.5 bg-gradient-to-r from-pink-600 to-sky-600 hover:from-pink-500 hover:to-sky-500 text-white rounded-xl text-xs font-bold shadow transition flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>ส่งข้อสอบและสรุปผลคะแนน</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
