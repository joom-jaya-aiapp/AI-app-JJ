import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  ArrowRight, 
  RotateCcw, 
  Award, 
  FileCheck, 
  ChevronRight,
  HelpCircle,
  BookOpen
} from 'lucide-react';
import { QuickCheckQuestion, QuickCheckResult } from '../types';
import { QUICK_CHECKS_DATA, QuickCheckModuleData } from '../data/quickChecks';

export interface QuickCheckSectionProps {
  moduleId: string; // e.g. 'gate1_match', 'gate2_pregnancy', 'gate3_birth', 'epidemiology', etc.
  customData?: QuickCheckModuleData;
  onNavigateToModule?: (moduleId: string) => void;
  onComplete?: (result: QuickCheckResult) => void;
}

export const QuickCheckSection: React.FC<QuickCheckSectionProps> = ({
  moduleId,
  customData,
  onNavigateToModule,
  onComplete,
}) => {
  const quizData = customData || QUICK_CHECKS_DATA[moduleId];

  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showFinished, setShowFinished] = useState<boolean>(false);

  // Reset state if moduleId changes
  useEffect(() => {
    setCurrentIdx(0);
    setSelectedAnswers({});
    setShowFinished(false);
  }, [moduleId]);

  if (!quizData || quizData.questions.length === 0) {
    return null;
  }

  const questions = quizData.questions;
  const currentQ = questions[currentIdx];
  const hasAnsweredCurrent = selectedAnswers[currentIdx] !== undefined;
  const selectedOpt = selectedAnswers[currentIdx];

  const handleSelectOption = (optIdx: number) => {
    if (hasAnsweredCurrent) return; // Prevent changing after selection
    const newAnswers = { ...selectedAnswers, [currentIdx]: optIdx };
    setSelectedAnswers(newAnswers);

    // If this is the last question, show finished after short moment or when user clicks next
    if (Object.keys(newAnswers).length === questions.length) {
      // Calculate score
      let correct = 0;
      questions.forEach((q, idx) => {
        if (newAnswers[idx] === q.correctAnswer) {
          correct += 1;
        }
      });
      const passed = correct >= Math.ceil(questions.length * 0.6);
      const result: QuickCheckResult = {
        moduleId,
        score: correct,
        total: questions.length,
        passed,
        completedAt: new Date().toISOString(),
      };

      // Save to localStorage
      try {
        const saved = JSON.parse(localStorage.getItem('thal_quick_checks') || '{}');
        saved[moduleId] = result;
        localStorage.setItem('thal_quick_checks', JSON.stringify(saved));
      } catch (e) {
        console.error('Failed to save quick check result', e);
      }

      if (onComplete) {
        onComplete(result);
      }
    }
  };

  const handleNext = () => {
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setShowFinished(true);
    }
  };

  const handleRestart = () => {
    setSelectedAnswers({});
    setCurrentIdx(0);
    setShowFinished(false);
  };

  // Score calculation
  let correctCount = 0;
  questions.forEach((q, idx) => {
    if (selectedAnswers[idx] === q.correctAnswer) {
      correctCount += 1;
    }
  });
  const scorePercent = Math.round((correctCount / questions.length) * 100);
  const isMastered = scorePercent >= 70;

  return (
    <div 
      id={`quick-check-${moduleId}`}
      aria-label="แบบทดสอบสั้นเสริมความรู้ Quick Check"
      className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-lg border border-indigo-800/50 space-y-5"
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-indigo-900/60">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Quick Check: ตรวจสอบความเข้าใจทันทีหลังจบบทเรียน</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
            {quizData.title}
          </h3>
          <p className="text-xs text-indigo-200/80 mt-0.5">
            {quizData.description}
          </p>
        </div>

        {/* Progress Tracker */}
        <div className="flex items-center gap-2 self-end sm:self-auto bg-slate-950/60 px-3 py-1.5 rounded-xl border border-indigo-800/40 text-xs">
          <span className="text-slate-400">ข้อที่:</span>
          <span className="font-mono font-bold text-emerald-400">
            {currentIdx + 1} / {questions.length}
          </span>
          <div className="flex items-center gap-1 ml-1.5">
            {questions.map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-all ${
                  selectedAnswers[i] !== undefined
                    ? selectedAnswers[i] === questions[i].correctAnswer
                      ? 'bg-emerald-400 ring-2 ring-emerald-500/40'
                      : 'bg-rose-400 ring-2 ring-rose-500/40'
                    : i === currentIdx
                      ? 'bg-indigo-400 animate-pulse'
                      : 'bg-slate-700'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {!showFinished ? (
        <div className="space-y-4">
          {/* Question Text */}
          <div className="bg-slate-950/50 p-4 rounded-xl border border-indigo-900/40">
            <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider block mb-1">
              คำถามทบทวนความรู้ #{currentIdx + 1}
            </span>
            <p className="text-sm font-semibold text-white leading-relaxed">
              {currentQ.question}
            </p>
          </div>

          {/* Options Grid */}
          <div className="space-y-2">
            {currentQ.options.map((optionText, optIdx) => {
              const isSelected = selectedOpt === optIdx;
              const isCorrectOpt = optIdx === currentQ.correctAnswer;

              let btnClass = 'bg-slate-800/80 hover:bg-slate-700 border-indigo-900/40 text-slate-200';
              if (hasAnsweredCurrent) {
                if (isCorrectOpt) {
                  btnClass = 'bg-emerald-950/70 border-emerald-500/80 text-emerald-200 ring-1 ring-emerald-500';
                } else if (isSelected && !isCorrectOpt) {
                  btnClass = 'bg-rose-950/70 border-rose-500/80 text-rose-200 ring-1 ring-rose-500';
                } else {
                  btnClass = 'bg-slate-900/40 border-slate-800 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={optIdx}
                  id={`qc-opt-${currentIdx}-${optIdx}`}
                  disabled={hasAnsweredCurrent}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs flex items-start gap-3 ${btnClass}`}
                >
                  <span className={`w-5 h-5 rounded-full border flex items-center justify-center font-bold text-[10px] flex-shrink-0 mt-0.5 ${
                    hasAnsweredCurrent && isCorrectOpt
                      ? 'border-emerald-400 text-emerald-400 bg-emerald-950'
                      : hasAnsweredCurrent && isSelected && !isCorrectOpt
                        ? 'border-rose-400 text-rose-400 bg-rose-950'
                        : 'border-slate-500 text-slate-400'
                  }`}>
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span className="flex-1 leading-relaxed">{optionText}</span>
                  {hasAnsweredCurrent && isCorrectOpt && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  )}
                  {hasAnsweredCurrent && isSelected && !isCorrectOpt && (
                    <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Rationale & Educational Feedback */}
          {hasAnsweredCurrent && (
            <div className="space-y-3 pt-1">
              <div
                className={`p-4 rounded-xl text-xs leading-relaxed border ${
                  selectedOpt === currentQ.correctAnswer
                    ? 'bg-emerald-950/40 border-emerald-600/50 text-emerald-100'
                    : 'bg-rose-950/40 border-rose-600/50 text-rose-100'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 mb-1.5">
                  {selectedOpt === currentQ.correctAnswer ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>คำตอบถูกต้อง! ยอดเยี่ยมมาก</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                      <span>คำตอบยังไม่ถูกต้อง ลองสังเกตคำอธิบายนี้:</span>
                    </>
                  )}
                </div>
                <p className="text-xs leading-relaxed opacity-90">
                  {currentQ.rationale}
                </p>

                {currentQ.keyTakeaway && (
                  <div className="mt-2.5 pt-2 border-t border-white/10 flex items-start gap-1.5 text-[11px] font-medium text-emerald-300">
                    <Sparkles className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                    <span><strong>จุดสำคัญก่อนสอบ:</strong> {currentQ.keyTakeaway}</span>
                  </div>
                )}
              </div>

              {/* Next Question / Finish Button */}
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  id={`qc-next-btn-${currentIdx}`}
                  onClick={handleNext}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition"
                >
                  <span>{currentIdx < questions.length - 1 ? 'ข้อถัดไป' : 'ดูผลคะแนน Quick Check'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Result Summary View */
        <div className="bg-slate-950/60 border border-indigo-900/50 rounded-xl p-6 text-center space-y-5">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white shadow-lg mx-auto">
            <Award className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h4 className="text-xl font-bold text-white">
              {isMastered ? 'คุณผ่านการทบทวนความรู้ประจำโมดูลนี้แล้ว!' : 'ทบทวนความรู้เรียบร้อยแล้ว'}
            </h4>
            <p className="text-xs text-indigo-200 max-w-md mx-auto">
              {isMastered
                ? 'คุณมีความเข้าใจในเนื้อหาสำคัญของโมดูลนี้อย่างแม่นยำ พร้อมอย่างยิ่งสำหรับการทำแบบทดสอบประเมินผลสัมฤทธิ์ 40 ข้อ (Final Exam)'
                : 'คุณสามารถลองทำซ้ำอีกครั้งเพื่อสร้างความแม่นยำสูงสุดก่อนเข้าสู่แบบทดสอบประเมินผลสัมฤทธิ์'}
            </p>
          </div>

          {/* Score Badge */}
          <div className="inline-flex items-center gap-4 px-5 py-2.5 rounded-xl bg-slate-900 border border-indigo-800 text-sm">
            <div>
              <span className="text-xs text-slate-400 block">คะแนนของคุณ:</span>
              <strong className="text-emerald-400 font-mono text-lg">
                {correctCount} / {questions.length} ข้อ ({scorePercent}%)
              </strong>
            </div>
            <div className="h-8 w-px bg-indigo-800"></div>
            <div>
              <span className="text-xs text-slate-400 block">สถานะความพร้อม:</span>
              <span className={`font-bold text-xs ${isMastered ? 'text-emerald-400' : 'text-amber-400'}`}>
                {isMastered ? 'พร้อมสอบปลายภาค (Exam Ready)' : 'ควรทบทวนเพิ่มเติม'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              id="qc-retake-btn"
              onClick={handleRestart}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ทำ Quick Check ซ้ำอีกครั้ง</span>
            </button>

            {onNavigateToModule && (
              <button
                id="qc-goto-final-exam-btn"
                onClick={() => onNavigateToModule('quiz')}
                className="w-full sm:w-auto px-5 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md flex items-center justify-center gap-1.5 transition"
              >
                <FileCheck className="w-4 h-4" />
                <span>ไปทำแบบทดสอบประเมินผล 40 ข้อ (Final Exam)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
