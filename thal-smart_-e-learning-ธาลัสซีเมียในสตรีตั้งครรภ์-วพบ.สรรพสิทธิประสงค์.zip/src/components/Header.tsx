import React from 'react';
import { 
  Dna, 
  GraduationCap, 
  BookOpen, 
  FlaskConical, 
  Users, 
  FileCheck, 
  Award, 
  Info,
  Edit3,
  ClipboardList
} from 'lucide-react';
import { StudentProfile } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  student: StudentProfile;
  onOpenProfile: () => void;
  onOpenNeeds: () => void;
  completedCasesCount: number;
  quizCompleted: boolean;
  quizScore: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  student,
  onOpenProfile,
  onOpenNeeds,
  completedCasesCount,
  quizCompleted,
  quizScore,
}) => {
  const navItems = [
    { id: 'gates', label: 'กรอบ 3 ประตู', icon: Dna },
    { id: 'knowledge', label: 'ฐานความรู้', icon: BookOpen },
    { id: 'lab', label: 'Lab Interpretation Engine', icon: FlaskConical },
    { id: 'cases', label: `กรณีศึกษา (${completedCasesCount}/8)`, icon: Users },
    { id: 'quiz', label: `ข้อสอบ 40 ข้อ ${quizCompleted ? `(${quizScore}/40)` : ''}`, icon: FileCheck },
    { id: 'analytics', label: 'สรุปผล & เกียรติบัตร', icon: Award },
    { id: 'roster', label: 'รายชื่อผู้เรียน & คะแนนสอบ', icon: ClipboardList },
  ];

  return (
    <header className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white shadow-lg sticky top-0 z-40 border-b border-blue-800/40">
      {/* College & Program Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-pink-500 to-sky-400 p-0.5 shadow-md shadow-pink-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-pink-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-sky-400 bg-sky-950/70 px-2 py-0.5 rounded border border-sky-800/60">
                  BCNSP E-Learning
                </span>
                <span className="text-xs text-pink-300 font-medium">
                  พยาบาลศาสตร์ชั้นปีที่ 4
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                <span>Thal-Smart:</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-sky-200 to-blue-300 font-semibold">
                  ธาลัสซีเมียในสตรีตั้งครรภ์
                </span>
              </h1>
              <p className="text-[11px] text-slate-300">
                วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ (เลือกคู่ &bull; เลือกครรภ์ &bull; เลือกคลอด)
              </p>

              {/* แถบสีของปิงปองจราจร 6 สี */}
              <div 
                onClick={() => setActiveTab('knowledge')}
                className="mt-1.5 flex flex-wrap items-center gap-1.5 cursor-pointer group"
                title="คลิกเพื่อศึกษา: มาตรการคัดกรองเฝ้าระวัง ป้องกันโรคธาลัสซีเมีย ด้วยปิงปองจราจร ๖ สี"
              >
                <div className="flex items-center gap-1 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700/80 hover:border-pink-500/50 px-2 py-0.5 rounded-full transition shadow-xs">
                  <span className="text-[10px] font-semibold text-slate-400 group-hover:text-pink-300 transition">
                    ปิงปองจราจร ๖ สี:
                  </span>
                  <div className="flex items-center space-x-1">
                    {/* ขาว: ปกติ */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-white text-slate-900 text-[9px] font-bold border border-slate-300 shadow-xs hover:scale-105 transition-transform" 
                      title="สีขาว: ปกติ (๐-๔ คะแนน) เม็ดเลือดแดงและ Hb ปกติ ดูแลสุขภาพ ๓ อ ๓ ลด"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-300 border border-slate-500"></span>
                      <span>ขาว</span>
                    </span>
                    {/* เขียว: สงสัยเป็นโรค */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-emerald-500 text-white text-[9px] font-bold shadow-xs hover:scale-105 transition-transform" 
                      title="สีเขียว: สงสัยเป็นโรค (๕-๑๐ คะแนน) ซีด เม็ดเลือดแดงผิดปกติ แต่ Hb typing ปกติ"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-200"></span>
                      <span>เขียว</span>
                    </span>
                    {/* เหลือง: เสี่ยงเป็นโรค */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-400 text-amber-950 text-[9px] font-bold shadow-xs hover:scale-105 transition-transform" 
                      title="สีเหลือง: เสี่ยงเป็นโรค (๑๑-๑๕ คะแนน) ซีด เม็ดเลือดแดงผิดปกติ และ Hb typing ผิดปกติ"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-100"></span>
                      <span>เหลือง</span>
                    </span>
                    {/* ส้ม: รุนแรงน้อย */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-orange-500 text-white text-[9px] font-bold shadow-xs hover:scale-105 transition-transform" 
                      title="สีส้ม: รุนแรงน้อย (๑๕ คะแนน) เจ็บป่วยบ่อย ให้เลือดเมื่อป่วย Folic Acid ยาขับเหล็ก"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-200"></span>
                      <span>ส้ม</span>
                    </span>
                    {/* แดง: รุนแรงมาก */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[9px] font-bold shadow-xs hover:scale-105 transition-transform" 
                      title="สีแดง: รุนแรงมาก (๑๕ คะแนน) มีอาการ ๓-๖ ด. ตับม้ามโต หน้าเปลี่ยน ให้เลือดประจำ"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-200"></span>
                      <span>แดง</span>
                    </span>
                    {/* ดำ: รุนแรงสูงสุด */}
                    <span 
                      className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-slate-950 text-white text-[9px] font-bold border border-slate-700 shadow-xs hover:scale-105 transition-transform" 
                      title="สีดำ: รุนแรงสูงสุด (๑๕ คะแนน) ทารกบวมน้ำ เสียชีวิตในครรภ์ แม่เสี่ยงครรภ์เป็นพิษ ยุติการตั้งครรภ์"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                      <span>ดำ</span>
                    </span>
                  </div>
                </div>

                {/* แถบสีต่อเนื่อง 6 สี (Micro Color Ribbon) */}
                <div 
                  className="h-1.5 w-24 sm:w-28 rounded-full overflow-hidden flex shadow-xs border border-slate-700/60"
                  title="แถบสัญลักษณ์ปิงปองจราจร ๖ สี: ขาว • เขียว • เหลือง • ส้ม • แดง • ดำ"
                >
                  <div className="h-full flex-1 bg-white" title="ขาว: ปกติ"></div>
                  <div className="h-full flex-1 bg-emerald-500" title="เขียว: สงสัยเป็นโรค"></div>
                  <div className="h-full flex-1 bg-amber-400" title="เหลือง: เสี่ยงเป็นโรค"></div>
                  <div className="h-full flex-1 bg-orange-500" title="ส้ม: รุนแรงน้อย"></div>
                  <div className="h-full flex-1 bg-rose-600" title="แดง: รุนแรงมาก"></div>
                  <div className="h-full flex-1 bg-slate-950" title="ดำ: รุนแรงสูงสุด"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Student Profile & Quick Actions */}
          <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-end">
            <button
              onClick={() => setActiveTab('roster')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 transition"
              title="ดูรายชื่อผู้เข้าเรียนและคะแนนสอบทั้งหมด"
            >
              <ClipboardList className="w-3.5 h-3.5 text-emerald-400" />
              <span>ดูรายชื่อผู้เรียน & คะแนนทั้งหมด</span>
            </button>

            <button
              onClick={onOpenNeeds}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700/80 text-sky-200 border border-slate-700 transition"
              title="ดูการวิเคราะห์ผู้เรียนและความต้องการ"
            >
              <Info className="w-3.5 h-3.5 text-sky-400" />
              <span>การวิเคราะห์ผู้เรียน</span>
            </button>

            <button
              onClick={onOpenProfile}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs bg-gradient-to-r from-pink-500/20 to-blue-500/20 hover:from-pink-500/30 hover:to-blue-500/30 border border-pink-500/30 text-white transition group"
            >
              <div className="w-6 h-6 rounded-full bg-pink-500 text-white flex items-center justify-center font-bold text-[11px]">
                {student.name.slice(0, 1) || 'พ'}
              </div>
              <div className="text-left">
                <div className="font-semibold text-pink-200 group-hover:text-white flex items-center gap-1">
                  {student.name}
                  <Edit3 className="w-3 h-3 text-slate-400 group-hover:text-pink-300" />
                </div>
                <div className="text-[10px] text-slate-400">
                  รหัส {student.studentId}
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-950/70 border-t border-slate-800/60 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 sm:space-x-2 py-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-r from-pink-600 to-sky-600 text-white shadow-md shadow-pink-600/20'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-sky-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
