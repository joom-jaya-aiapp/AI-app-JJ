import React, { useState, useEffect } from 'react';
import { X, User, Building2, Check, UserPlus } from 'lucide-react';
import { StudentProfile } from '../types';
import {
  MAX_STUDENT_NAME_LENGTH,
  MAX_STUDENT_ID_LENGTH,
  MAX_COHORT_LENGTH,
  sanitizeIdToken,
  sanitizeString,
} from '../firebase';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
  onSave: (updated: StudentProfile) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  isOpen,
  onClose,
  student,
  onSave,
}) => {
  const [name, setName] = useState(student.name);
  const [studentId, setStudentId] = useState(student.studentId);
  const [cohort, setCohort] = useState(student.cohort);

  useEffect(() => {
    if (isOpen) {
      setName(student.name);
      setStudentId(student.studentId);
      setCohort(student.cohort);
    }
  }, [isOpen, student]);

  if (!isOpen) return null;

  const handleClearForNewLearner = () => {
    setName('');
    setStudentId('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...student,
      name: sanitizeString(name, MAX_STUDENT_NAME_LENGTH, 'นักศึกษาพยาบาล'),
      studentId: sanitizeIdToken(studentId, MAX_STUDENT_ID_LENGTH, '6611400001'),
      cohort: sanitizeString(cohort, MAX_COHORT_LENGTH, 'นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4'),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-pink-500/20 border border-pink-500/40 flex items-center justify-center text-pink-300">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">ข้อมูลผู้เรียน (Student Profile)</h3>
              <p className="text-[11px] text-slate-300">ระบุชื่อเพื่อแสดงในรายงานผลและเกียรติบัตร</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="flex items-center justify-between bg-pink-50/70 border border-pink-200 rounded-xl px-3 py-2">
            <span className="text-[11px] text-slate-600">
              ต้องการให้ผู้เรียนคนถัดไปเข้าทำข้อสอบ?
            </span>
            <button
              type="button"
              onClick={handleClearForNewLearner}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-[11px] font-bold transition"
            >
              <UserPlus className="w-3 h-3" />
              <span>กรอกชื่อผู้เรียนคนใหม่</span>
            </button>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              ชื่อ - สกุล (ภาษาไทย)
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="เช่น นศ.พย. นภาพร สดใส"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
              required
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              รหัสนักศึกษา (Student ID)
            </label>
            <input
              type="text"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              placeholder="เช่น 6611400012"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
              required
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              ระดับชั้นปี / รุ่นการศึกษา
            </label>
            <input
              type="text"
              value={cohort}
              onChange={(e) => setCohort(e.target.value)}
              placeholder="เช่น นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4 (รุ่น 73)"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
              required
            />
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-500 text-[11px] space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-700">
              <Building2 className="w-3.5 h-3.5 text-pink-600" />
              <span>วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์</span>
            </div>
            <div>หลักสูตรพยาบาลศาสตรบัณฑิต (ฉบับปรับปรุง)</div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-gradient-to-r from-pink-600 to-sky-600 hover:from-pink-500 hover:to-sky-500 text-white rounded-lg font-bold shadow transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>บันทึกข้อมูล</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
