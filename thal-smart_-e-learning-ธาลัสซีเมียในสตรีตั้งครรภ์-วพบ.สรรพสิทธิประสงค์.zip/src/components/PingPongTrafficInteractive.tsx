import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Heart, 
  Activity, 
  Sparkles, 
  HelpCircle, 
  RotateCcw, 
  ArrowRight,
  Info,
  Apple,
  Dumbbell,
  Smile,
  Ban,
  Wine,
  Cigarette,
  UserCheck
} from 'lucide-react';

interface AssessmentItem {
  id: number;
  category: 'history' | 'physical';
  label: string;
  medicalNote?: string;
}

const ASSESSMENT_ITEMS: AssessmentItem[] = [
  // ซักประวัติ 4 ข้อ
  { id: 1, category: 'history', label: '๑. มีอาการซีดบ่อย ๆ หาย ๆ', medicalNote: 'Episodic pallor' },
  { id: 2, category: 'history', label: '๒. ได้รับเลือดเพราะซีด', medicalNote: 'History of blood transfusion' },
  { id: 3, category: 'history', label: '๓. มีอาการตัวเหลือง ดีซ่าน เป็นๆ หายๆ', medicalNote: 'Intermittent jaundice' },
  { id: 4, category: 'history', label: '๔. พี่น้องหรือญาติเป็นโรคซีด', medicalNote: 'Family history of anemia / thalassemia' },
  // ตรวจร่างกาย 11 ข้อ
  { id: 5, category: 'physical', label: '๕. ซีด (ดูที่เปลือกตาด้านใน)', medicalNote: 'Pale conjunctiva' },
  { id: 6, category: 'physical', label: '๖. หน้าผากแบน นูนสูง', medicalNote: 'Frontal bossing (Thalassemia facies)' },
  { id: 7, category: 'physical', label: '๗. ตาห่าง', medicalNote: 'Hypertelorism' },
  { id: 8, category: 'physical', label: '๘. ดั้งจมูกแฟบ', medicalNote: 'Depressed nasal bridge' },
  { id: 9, category: 'physical', label: '๙. โหนกแก้มสูง', medicalNote: 'Prominent malar / zygomatic bones' },
  { id: 10, category: 'physical', label: '๑๐. ฟันหน้ายื่น', medicalNote: 'Maxillary protrusion / buck teeth' },
  { id: 11, category: 'physical', label: '๑๑. ตาขาวมีสีเหลือง', medicalNote: 'Icteric sclera' },
  { id: 12, category: 'physical', label: '๑๒. ตัวเตี้ย แคระแกร็น หรือขาดสารอาหาร', medicalNote: 'Growth retardation / Failure to thrive' },
  { id: 13, category: 'physical', label: '๑๓. น้ำหนักน้อยหรือขาดสารอาหาร', medicalNote: 'Underweight / Malnutrition' },
  { id: 14, category: 'physical', label: '๑๔. ท้องโต (ตับหรือม้ามโต)', medicalNote: 'Hepatosplenomegaly' },
  { id: 15, category: 'physical', label: '๑๕. ผิวหนังสีเทา ดำคล้ำ', medicalNote: 'Hemochromatosis / Iron pigmentation' },
];

export type PingPongColorKey = 'white' | 'green' | 'yellow' | 'orange' | 'red' | 'black';

interface PingPongDetails {
  key: PingPongColorKey;
  name: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  dotColor: string;
  title: string;
  scoreRange: string;
  classification: string;
  clinicalSymptoms: string;
  labFindings: string;
  management: string[];
  threeOThreeLod: boolean;
}

export const PING_PONG_COLORS: Record<PingPongColorKey, PingPongDetails> = {
  white: {
    key: 'white',
    name: 'สีขาว',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-300',
    badgeText: 'ปิงปองสีขาว: ปกติ',
    borderColor: 'border-slate-300',
    dotColor: 'bg-slate-200 border-2 border-slate-400',
    title: 'ปกติ (Normal)',
    scoreRange: 'คะแนน ๐ - ๔',
    classification: 'ไม่เป็นโรคฯ',
    clinicalSymptoms: 'ไม่มีอาการซีด ไม่มีภาวะตัวเหลืองตาเหลือง สภาพร่างกายสมบูรณ์แข็งแรงดี',
    labFindings: 'แนะนำให้ไปตรวจเลือดพบว่า ไม่ซีด เม็ดเลือดแดงปกติ (Hb ปกติ, RBC ปกติ, Hb typing ปกติ)',
    management: [
      'ดูแลสุขภาพด้วยหลัก "3 อ 3 ลด" อย่างสม่ำเสมอ',
      'ตรวจสุขภาพประจำปีและตรวจคัดกรองก่อนวางแผนมีบุตร',
    ],
    threeOThreeLod: true,
  },
  green: {
    key: 'green',
    name: 'สีเขียว',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    badgeText: 'ปิงปองสีเขียว: สงสัยเป็นโรค',
    borderColor: 'border-emerald-400',
    dotColor: 'bg-emerald-500 border-2 border-emerald-600',
    title: 'สงสัยเป็นโรค (Suspected Disease)',
    scoreRange: 'คะแนน ๕ - ๑๐',
    classification: 'สงสัย/เสี่ยงเป็นโรคฯ',
    clinicalSymptoms: 'มีอาการซีดเล็กน้อยเป็นๆ หายๆ อาจมีประวัติคนในครอบครัวซีด แต่ยังไม่พบลักษณะโครงหน้าธาลัสซีเมียชัดเจน',
    labFindings: 'ให้ส่งตรวจเลือด: พบซีด เม็ดเลือดแดงผิดปกติ (MCV < 80 หรือ MCH < 27), แต่ผล Hb typing: ปกติ (อาจเป็นพาหะ α-thal 1 หรือภาวะขาดธาตุเหล็ก)',
    management: [
      'ดูแลสุขภาพด้วยหลัก "3 อ 3 ลด"',
      'ส่งตรวจยืนยันเพิ่มเติม: Serum Ferritin เพื่อแยกภาวะขาดธาตุเหล็ก หรือตรวจ PCR for α-thalassemia 1',
      'ติดตามผลเลือดสม่ำเสมอ',
    ],
    threeOThreeLod: true,
  },
  yellow: {
    key: 'yellow',
    name: 'สีเหลือง',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
    badgeText: 'ปิงปองสีเหลือง: เสี่ยงเป็นโรค',
    borderColor: 'border-amber-400',
    dotColor: 'bg-amber-400 border-2 border-amber-500',
    title: 'เสี่ยงเป็นโรค (At Risk of Disease)',
    scoreRange: 'คะแนน ๑๑ - ๑๕',
    classification: 'เสี่ยงเป็นโรคฯ สูง',
    clinicalSymptoms: 'มีอาการซีดชัดเจน มีตาเหลืองประปราย หรือเริ่มมีตับม้ามโตหรือลักษณะใบหน้าผิดปกติเล็กน้อย',
    labFindings: 'ให้ส่งตรวจเลือด: พบซีด เม็ดเลือดแดงผิดปกติ, Hb typing: ผิดปกติ (พบแถบ Hb ผิดปกติ เช่น Hb E, Hb A2 สูง หรือ Hb H)',
    management: [
      'ดูแลสุขภาพด้วยหลัก "3 อ 3 ลด"',
      'ส่งพบแพทย์ผู้เชี่ยวชาญ/อายุรแพทย์โรคเลือดเพื่อวินิจฉัยชนิดโรคแน่นอน',
      'ให้คำปรึกษาทางพันธุศาสตร์และการวางแผนครอบครัว',
    ],
    threeOThreeLod: true,
  },
  orange: {
    key: 'orange',
    name: 'สีส้ม',
    badgeBg: 'bg-orange-100 text-orange-900 border-orange-300',
    badgeText: 'ปิงปองสีส้ม: รุนแรงน้อย',
    borderColor: 'border-orange-400',
    dotColor: 'bg-orange-500 border-2 border-orange-600',
    title: 'รุนแรงน้อย (Mild Severity / Thalassemia Intermedia)',
    scoreRange: 'คะแนน ๑๕',
    classification: 'กลุ่มอาการรุนแรงน้อย',
    clinicalSymptoms: 'กลุ่มนี้ปกติอาการไม่รุนแรงมาก ซีดเหลืองเล็กน้อย แต่เจ็บป่วยบ่อย มีดีซ่าน ซึ่งต้องให้เลือดทุกครั้งที่เจ็บป่วยหรือติดเชื้อ',
    labFindings: 'ส่งตรวจเลือดพบสิ่งผิดปกติ, Hb typing: ผิดปกติ (เช่น Hb H disease, AE Bart\'s, หรือ β-thal/Hb E ชนิดไม่รุนแรง)',
    management: [
      'ให้ Folic Acid เสริมสร้างเม็ดเลือดแดง',
      'การให้เลือดเฉพาะเมื่อมีภาวะเจ็บป่วย/ติดเชื้อ (Intermittent transfusion)',
      'ยาขับเหล็ก (Iron chelator) เมื่อมีข้อบ่งชี้จากภาวะธาตุเหล็กสะสมเกิน',
      'หลีกเลี่ยงการให้ยาธาตุเหล็กโดยเด็ดขาด',
    ],
    threeOThreeLod: false,
  },
  red: {
    key: 'red',
    name: 'สีแดง',
    badgeBg: 'bg-rose-100 text-rose-900 border-rose-300',
    badgeText: 'ปิงปองสีแดง: รุนแรงมาก',
    borderColor: 'border-rose-400',
    dotColor: 'bg-rose-600 border-2 border-rose-700',
    title: 'รุนแรงมาก (Severe / Thalassemia Major)',
    scoreRange: 'คะแนน ๑๕',
    classification: 'กลุ่มอาการรุนแรงมาก (Homozygous β-thal, β-thal/Hb E severe)',
    clinicalSymptoms: 'แรกเกิดยังไม่มีอาการ แต่อายุได้ ๓-๖ เดือน เด็กทารกจะตาเหลือง อ่อนเพลีย ตัวเตี้ยแคระแกร็น ตับและม้ามโต ใบหน้าเปลี่ยนแปลง หน้าผากตั้งชั้น โหนกแก้มสูง ดั้งจมูกแบน ฟันยื่น ยิ่งอายุมากยิ่งเห็นชัด ต้องให้เลือดประจำ ถ้าไม่ได้รักษาต่อเนื่อง เสียชีวิตได้ อายุประมาณ ๑๘-๒๐ ปี จะเสียชีวิต',
    labFindings: 'ส่งตรวจเลือดพบความผิดปกติชัดเจน ซีดรุนแรง (Hb < 6-7 g/dL), Hb typing: ผิดปกติรุนแรง (Hb EF, Hb E > 80% หรือ Hb A2F)',
    management: [
      'ให้ Folic Acid สม่ำเสมอ',
      'การให้เลือดเป็นประจำ (Regular / High-transfusion regimen รักษา Hb ≥ 9-10 g/dL)',
      'การให้ยาขับเหล็ก (Iron chelation therapy) อย่างเคร่งครัดเพื่อป้องกันหัวใจและตับวาย',
      'ติดตามภาวะแทรกซ้อนของต่อมไร้ท่อและหัวใจ',
    ],
    threeOThreeLod: false,
  },
  black: {
    key: 'black',
    name: 'สีดำ',
    badgeBg: 'bg-slate-900 text-white border-slate-700',
    badgeText: 'ปิงปองสีดำ: รุนแรงสูงสุด',
    borderColor: 'border-slate-800',
    dotColor: 'bg-slate-950 border-2 border-slate-700',
    title: 'รุนแรงสูงสุด (Most Severe / Hb Bart\'s Hydrops Fetalis)',
    scoreRange: 'คะแนน ๑๕',
    classification: 'กลุ่มอาการรุนแรงสูงสุด (Lethal)',
    clinicalSymptoms: 'ทารกบวมน้ำ คลอดลำบาก ตับม้ามโต ส่วนใหญ่เด็กเสียชีวิตในครรภ์มารดา หรือหลังคลอดไม่กี่ชั่วโมง ตัวแม่มีโอกาสเกิดภาวะครรภ์เป็นพิษ (Toxemia / Maternal Mirror Syndrome) บวม ความดันโลหิตสูง ปวดศีรษะ ตามัว ชัก และอาจเสียชีวิตได้',
    labFindings: 'Ultrasound: ทารกบวมน้ำ รกหนาผิดปกติ (Placentomegaly), Hb typing จากเลือดสายสะดือ/น้ำคร่ำ: พบ Hb Bart\'s 80-100% ปราศจาก Hb A',
    management: [
      'การยุติการตั้งครรภ์เพื่อการรักษา (Termination of Pregnancy: TOP) เพื่อความปลอดภัยสูงสุดของมารดา',
      'เฝ้าระวังและรักษาภาวะแทรกซ้อนครรภ์เป็นพิษและตกเลือดหลังคลอดในมารดาอย่างใกล้ชิด',
      'ให้คำปรึกษาทางพันธุศาสตร์แก่คู่เสี่ยงเพื่อวางแผนการตั้งครรภ์ครั้งถัดไป',
    ],
    threeOThreeLod: false,
  },
};

export const PingPongTrafficInteractive: React.FC = () => {
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [bloodFinding, setBloodFinding] = useState<'normal' | 'abnormal'>('normal');
  const [hbTypingFinding, setHbTypingFinding] = useState<'normal' | 'abnormal'>('normal');
  const [severitySubtype, setSeveritySubtype] = useState<'mild' | 'severe' | 'lethal'>('mild');
  const [activeTab, setActiveTab] = useState<'simulator' | 'allColors' | 'health3o3lod'>('simulator');

  const score = selectedItems.length;

  const toggleItem = (id: number) => {
    setSelectedItems((prev) => 
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    setSelectedItems(ASSESSMENT_ITEMS.map((i) => i.id));
    setBloodFinding('abnormal');
    setHbTypingFinding('abnormal');
  };

  const handleClear = () => {
    setSelectedItems([]);
    setBloodFinding('normal');
    setHbTypingFinding('normal');
    setSeveritySubtype('mild');
  };

  // Preset scenarios
  const applyPreset = (preset: 'white' | 'green' | 'yellow' | 'orange' | 'red' | 'black') => {
    if (preset === 'white') {
      setSelectedItems([1]); // score 1
      setBloodFinding('normal');
      setHbTypingFinding('normal');
    } else if (preset === 'green') {
      setSelectedItems([1, 4, 5, 7, 8, 13]); // score 6
      setBloodFinding('abnormal');
      setHbTypingFinding('normal');
    } else if (preset === 'yellow') {
      setSelectedItems([1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 13, 14]); // score 12
      setBloodFinding('abnormal');
      setHbTypingFinding('abnormal');
    } else if (preset === 'orange') {
      setSelectedItems(ASSESSMENT_ITEMS.map((i) => i.id)); // 15
      setBloodFinding('abnormal');
      setHbTypingFinding('abnormal');
      setSeveritySubtype('mild');
    } else if (preset === 'red') {
      setSelectedItems(ASSESSMENT_ITEMS.map((i) => i.id)); // 15
      setBloodFinding('abnormal');
      setHbTypingFinding('abnormal');
      setSeveritySubtype('severe');
    } else if (preset === 'black') {
      setSelectedItems(ASSESSMENT_ITEMS.map((i) => i.id)); // 15
      setBloodFinding('abnormal');
      setHbTypingFinding('abnormal');
      setSeveritySubtype('lethal');
    }
  };

  // Calculate current pingpong color
  const currentPingPong: PingPongDetails = useMemo(() => {
    if (score <= 4) {
      return PING_PONG_COLORS.white;
    }
    if (score >= 5 && score <= 10) {
      return PING_PONG_COLORS.green;
    }
    if (score >= 11 && score < 15) {
      return PING_PONG_COLORS.yellow;
    }
    // Score === 15
    if (severitySubtype === 'mild') {
      return PING_PONG_COLORS.orange;
    }
    if (severitySubtype === 'severe') {
      return PING_PONG_COLORS.red;
    }
    return PING_PONG_COLORS.black;
  }, [score, severitySubtype]);

  return (
    <div className="space-y-6">
      {/* Top Banner Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-1.5 bg-slate-100 rounded-xl border border-slate-200 text-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3.5 py-2 rounded-lg font-bold transition flex items-center gap-1.5 ${
              activeTab === 'simulator'
                ? 'bg-white text-pink-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-pink-600" />
            <span>เครื่องมือจำลองคัดกรองปิงปอง ๖ สี</span>
          </button>
          <button
            onClick={() => setActiveTab('allColors')}
            className={`px-3.5 py-2 rounded-lg font-bold transition flex items-center gap-1.5 ${
              activeTab === 'allColors'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Info className="w-3.5 h-3.5 text-indigo-600" />
            <span>ตารางมาตรฐานปิงปองจราจร ๖ สี ทั้งหมด</span>
          </button>
          <button
            onClick={() => setActiveTab('health3o3lod')}
            className={`px-3.5 py-2 rounded-lg font-bold transition flex items-center gap-1.5 ${
              activeTab === 'health3o3lod'
                ? 'bg-white text-emerald-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Apple className="w-3.5 h-3.5 text-emerald-600" />
            <span>คู่มือการดูแลสุขภาพ "3 อ 3 ลด"</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-1 text-[11px] text-slate-500 pr-2">
          <span>กลุ่มเป้าหมาย: หญิงตั้งครรภ์ &amp; เด็กแรกคลอด วัยรุ่น (0-15 ปี)</span>
        </div>
      </div>

      {/* TAB 1: INTERACTIVE SIMULATOR */}
      {activeTab === 'simulator' && (
        <div className="space-y-6">
          {/* Preset Buttons */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-pink-600" />
              <span className="font-bold text-slate-800">จำลองเคสตัวอย่างด่วน (Quick Presets):</span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => applyPreset('white')}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-slate-200 border border-slate-400"></span>
                <span>ขาว (ปกติ)</span>
              </button>
              <button
                onClick={() => applyPreset('green')}
                className="px-2.5 py-1 rounded-lg border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span>เขียว (สงสัย)</span>
              </button>
              <button
                onClick={() => applyPreset('yellow')}
                className="px-2.5 py-1 rounded-lg border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span>เหลือง (เสี่ยง)</span>
              </button>
              <button
                onClick={() => applyPreset('orange')}
                className="px-2.5 py-1 rounded-lg border border-orange-300 bg-orange-50 hover:bg-orange-100 text-orange-900 font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
                <span>ส้ม (รุนแรงน้อย)</span>
              </button>
              <button
                onClick={() => applyPreset('red')}
                className="px-2.5 py-1 rounded-lg border border-rose-300 bg-rose-50 hover:bg-rose-100 text-rose-900 font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                <span>แดง (รุนแรงมาก)</span>
              </button>
              <button
                onClick={() => applyPreset('black')}
                className="px-2.5 py-1 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-white font-semibold flex items-center gap-1.5 transition"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                <span>ดำ (รุนแรงสูงสุด)</span>
              </button>
              <button
                onClick={handleClear}
                className="px-2 py-1 text-slate-500 hover:text-slate-800 underline ml-1"
              >
                ล้างข้อมูล
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Checklist Section (Left, 7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-pink-600" />
                      <span>แบบคัดกรองการซักประวัติและตรวจร่างกาย (๑๕ ข้อ)</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      คลิกเลือกอาการที่ตรวจพบ (๑ ข้อ = ๑ คะแนน)
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-pink-100 text-pink-800 font-bold text-xs">
                      คะแนนรวม: {score} / 15
                    </span>
                    <button
                      onClick={handleSelectAll}
                      className="text-[11px] text-pink-600 hover:underline font-semibold"
                    >
                      เลือกทั้ง 15 ข้อ
                    </button>
                  </div>
                </div>

                {/* Part 1: History (4 items) */}
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    ส่วนที่ ๑: การซักประวัติ (๔ ข้อ)
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ASSESSMENT_ITEMS.filter((i) => i.category === 'history').map((item) => {
                      const isChecked = selectedItems.includes(item.id);
                      return (
                        <div
                          key={item.id}
                          onClick={() => toggleItem(item.id)}
                          className={`p-2.5 rounded-xl border cursor-pointer transition flex items-start gap-2.5 ${
                            isChecked
                              ? 'bg-pink-50/80 border-pink-300 ring-1 ring-pink-400'
                              : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}} // handled by parent div
                            className="mt-0.5 rounded text-pink-600 focus:ring-pink-500"
                          />
                          <div className="min-w-0 flex-1 text-xs">
                            <span className="font-medium text-slate-800 block leading-tight">
                              {item.label}
                            </span>
                            {item.medicalNote && (
                              <span className="text-[10px] text-slate-400 block mt-0.5">
                                {item.medicalNote}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Part 2: Physical Exam (11 items) */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    ส่วนที่ ๒: ลักษณะผู้ป่วยจากการตรวจร่างกาย (๑๑ ข้อ)
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ASSESSMENT_ITEMS.filter((i) => i.category === 'physical').map((item) => {
                      const isChecked = selectedItems.includes(item.id);
                      return (
                        <div
                          key={item.id}
                          onClick={() => toggleItem(item.id)}
                          className={`p-2.5 rounded-xl border cursor-pointer transition flex items-start gap-2.5 ${
                            isChecked
                              ? 'bg-pink-50/80 border-pink-300 ring-1 ring-pink-400'
                              : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="mt-0.5 rounded text-pink-600 focus:ring-pink-500"
                          />
                          <div className="min-w-0 flex-1 text-xs">
                            <span className="font-medium text-slate-800 block leading-tight">
                              {item.label}
                            </span>
                            {item.medicalNote && (
                              <span className="text-[10px] text-slate-400 block mt-0.5">
                                {item.medicalNote}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Sub-severity selector if score == 15 */}
                {score === 15 && (
                  <div className="p-3.5 bg-gradient-to-r from-amber-50 via-orange-50 to-rose-50 border border-orange-200 rounded-xl space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                      <AlertTriangle className="w-4 h-4 text-orange-600" />
                      <span>คะแนนเต็ม ๑๕ คะแนน: โปรดระบุกลุ่มอาการทางคลินิก (Clinical Phenotype)</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      <button
                        onClick={() => setSeveritySubtype('mild')}
                        className={`p-2 rounded-lg border text-left font-medium transition ${
                          severitySubtype === 'mild'
                            ? 'bg-orange-500 text-white border-orange-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-orange-50'
                        }`}
                      >
                        <div className="font-bold">ส้ม: รุนแรงน้อย</div>
                        <div className="text-[10px] opacity-90 mt-0.5">เจ็บป่วยบ่อย ให้เลือดเมื่อป่วย</div>
                      </button>
                      <button
                        onClick={() => setSeveritySubtype('severe')}
                        className={`p-2 rounded-lg border text-left font-medium transition ${
                          severitySubtype === 'severe'
                            ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-rose-50'
                        }`}
                      >
                        <div className="font-bold">แดง: รุนแรงมาก</div>
                        <div className="text-[10px] opacity-90 mt-0.5">มีอาการ 3-6 ด. ให้เลือดประจำ</div>
                      </button>
                      <button
                        onClick={() => setSeveritySubtype('lethal')}
                        className={`p-2 rounded-lg border text-left font-medium transition ${
                          severitySubtype === 'lethal'
                            ? 'bg-slate-900 text-white border-slate-950 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <div className="font-bold">ดำ: รุนแรงสูงสุด</div>
                        <div className="text-[10px] opacity-90 mt-0.5">ทารกบวมน้ำ แม่ครรภ์เป็นพิษ</div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Classification & Management Result (Right, 5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className={`bg-white rounded-2xl border-2 p-5 shadow-md space-y-4 ${currentPingPong.borderColor}`}>
                {/* Result Header Badge */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className={`w-5 h-5 rounded-full ${currentPingPong.dotColor} shadow-sm inline-block`}></span>
                    <div>
                      <span className="text-[11px] text-slate-500 font-semibold block">ระดับปิงปองจราจร</span>
                      <h3 className="font-bold text-slate-900 text-base">{currentPingPong.name}: {currentPingPong.title}</h3>
                    </div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${currentPingPong.badgeBg}`}>
                    {currentPingPong.scoreRange}
                  </span>
                </div>

                {/* Diagnostic Category */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs space-y-1">
                  <div className="font-bold text-slate-800">การแปลผลตามเกณฑ์:</div>
                  <div className="text-slate-600 font-medium">{currentPingPong.classification}</div>
                </div>

                {/* Clinical Symptoms */}
                <div className="space-y-1 text-xs">
                  <span className="font-bold text-slate-800 block">ลักษณะอาการแสดง (Clinical Manifestations):</span>
                  <p className="text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                    {currentPingPong.clinicalSymptoms}
                  </p>
                </div>

                {/* Laboratory Findings */}
                <div className="space-y-1 text-xs">
                  <span className="font-bold text-slate-800 block">ผลการตรวจเลือด &amp; Hb typing ในโรงพยาบาล:</span>
                  <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200 text-sky-950 font-medium leading-relaxed">
                    {currentPingPong.labFindings}
                  </div>
                </div>

                {/* Management / Treatment */}
                <div className="space-y-2 pt-2 border-t border-slate-200">
                  <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-pink-600" />
                    <span>แนวทางการดูแลรักษาและการพยาบาล (Nursing Care &amp; Rx):</span>
                  </span>
                  <div className="space-y-1.5">
                    {currentPingPong.management.map((m, idx) => (
                      <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-pink-50/60 border border-pink-100 text-xs text-slate-800">
                        <CheckCircle2 className="w-3.5 h-3.5 text-pink-600 flex-shrink-0 mt-0.5" />
                        <span className="font-medium leading-relaxed">{m}</span>
                      </div>
                    ))}
                  </div>

                  {currentPingPong.threeOThreeLod && (
                    <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Apple className="w-4 h-4 text-emerald-600" />
                        <span className="font-bold">ต้องดูแลสุขภาพด้วยมาตรการ "3 อ 3 ลด"</span>
                      </div>
                      <button
                        onClick={() => setActiveTab('health3o3lod')}
                        className="text-emerald-700 underline font-semibold hover:text-emerald-900"
                      >
                        ดูรายละเอียด 3 อ 3 ลด
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ALL 6 COLORS COMPARISON BOARD */}
      {activeTab === 'allColors' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Activity className="w-5 h-5 text-pink-600" />
              <span>ผังมาตรฐานการคัดกรองเฝ้าระวัง ควบคุม ป้องกันโรคธาลัสซีเมีย ด้วยปิงปองจราจร ๖ สี</span>
            </h3>
            <p className="text-xs text-slate-600 max-w-4xl leading-relaxed">
              การคัดกรองด้วยการซักประวัติ ๔ ข้อ ร่วมกับการตรวจร่างกายอาการแสดง ๑๑ ข้อ รวม ๑๕ ข้อ ในกลุ่มหญิงตั้งครรภ์ เด็กแรกคลอด และวัยรุ่น (อายุ ๐-๑๕ ปี) ร่วมกับการตรวจเลือดในโรงพยาบาลด้านพันธุกรรม Hb typing แบ่งออกเป็น ๖ ระดับปิงปองจราจร
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.values(PING_PONG_COLORS).map((item) => (
              <div
                key={item.key}
                className={`bg-white rounded-2xl border-2 p-4 shadow-xs space-y-3 flex flex-col justify-between ${item.borderColor}`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-4 h-4 rounded-full ${item.dotColor} inline-block`}></span>
                      <span className="font-bold text-slate-900 text-sm">{item.name}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold border ${item.badgeBg}`}>
                      {item.scoreRange}
                    </span>
                  </div>

                  <div>
                    <h5 className="font-bold text-slate-800 text-xs">{item.title}</h5>
                    <span className="text-[11px] text-pink-700 font-semibold block">{item.classification}</span>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-[11px] space-y-1">
                    <span className="font-bold text-slate-700 block">อาการแสดง:</span>
                    <p className="text-slate-600 leading-relaxed">{item.clinicalSymptoms}</p>
                  </div>

                  <div className="p-2.5 bg-sky-50/60 rounded-lg border border-sky-100 text-[11px] space-y-1">
                    <span className="font-bold text-sky-900 block">การตรวจเลือด/Hb typing:</span>
                    <p className="text-sky-800 leading-relaxed">{item.labFindings}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 mt-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                    การดูแลรักษา:
                  </span>
                  <ul className="space-y-1 text-[11px] text-slate-700">
                    {item.management.map((m, mIdx) => (
                      <li key={mIdx} className="flex items-start gap-1.5">
                        <span className="text-pink-600 font-bold">•</span>
                        <span>{m}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: 3 อ 3 ลด HEALTH GUIDELINE */}
      {activeTab === 'health3o3lod' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 p-6 rounded-2xl border border-emerald-200 space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
              <Apple className="w-3.5 h-3.5 text-emerald-600" />
              <span>แนวทางส่งเสริมสุขภาพระดับปฐมภูมิ</span>
            </div>
            <h3 className="font-bold text-slate-900 text-lg">
              มาตรการการดูแลสุขภาพด้วย "3 อ 3 ลด" สำหรับผู้ป่วยและกลุ่มเสี่ยงธาลัสซีเมีย
            </h3>
            <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">
              เป็นหัวใจสำคัญในการดูแลกลุ่มปิงปองสีขาว (ปกติ), สีเขียว (สงสัย), และสีเหลือง (เสี่ยง) รวมถึงผู้มีพาหะธาลัสซีเมียแฝง เพื่อคงความสมบูรณ์ของร่างกาย ชะลอภาวะเม็ดเลือดแตก และมีคุณภาพชีวิตที่ดี
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 3 อ */}
            <div className="bg-white rounded-2xl border border-emerald-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-emerald-100 pb-3">
                <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm">
                  3 อ
                </div>
                <h4 className="font-bold text-slate-900 text-sm">การปฏิบัติเพื่อสร้างเสริมสุขภาพ (3 อ)</h4>
              </div>

              <div className="space-y-3.5">
                <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-100 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-emerald-900 text-xs">
                    <Apple className="w-4 h-4 text-emerald-600" />
                    <span>อ.๑ อาหาร (Nutrition)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    กินครบมื้อ ครบหมู่อาหาร โดยเน้นไปที่ผัก และผลไม้อ่อนรสหวาน เลี่ยงปรุงหวาน มัน เค็ม
                  </p>
                  <div className="text-[11px] text-emerald-800 bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <strong>ข้อควรระวังสำหรับผู้ป่วยธาลัสซีเมีย:</strong> หลีกเลี่ยงอาหารที่มีธาตุเหล็กสูงมากเกินไป เช่น เลือด ตับ เครื่องในสัตว์ และส่งเสริมอาหารที่ช่วยลดการดูดซึมเหล็ก เช่น นม ชา น้ำเต้าหู้
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-teal-50/60 border border-teal-100 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-teal-900 text-xs">
                    <Dumbbell className="w-4 h-4 text-teal-600" />
                    <span>อ.๒ ออกกำลังกาย (Exercise)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    เลือกกิจกรรมเคลื่อนไหวร่างกายตามความสามารถและกำลัง ไม่หนักหรือหักโหมจนเกินไป ๒๐ - ๓๐ นาที สัปดาห์ละ ๒ - ๕ วัน
                  </p>
                  <div className="text-[11px] text-teal-800 bg-white/80 p-2 rounded-lg border border-teal-200">
                    <strong>ข้อควรระวัง:</strong> ผู้ป่วยที่มีม้ามโตควรหลีกเลี่ยงกีฬาที่มีการปะทะบริเวณหน้าท้อง (เช่น ฟุตบอล มวย) เพื่อป้องกันม้ามแตก (Splenic rupture)
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-sky-50/60 border border-sky-100 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-sky-900 text-xs">
                    <Smile className="w-4 h-4 text-sky-600" />
                    <span>อ.๓ อารมณ์ (Emotion &amp; Mental Health)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    ควรทำจิตใจให้สดชื่น สดใส ยอมรับการเปลี่ยนแปลง ฝึกตนให้มีสติ เพิ่มการคิดในแง่บวก เข้าใจธรรมชาติของโรคและคลายความวิตกกังวล
                  </p>
                </div>
              </div>
            </div>

            {/* 3 ลด */}
            <div className="bg-white rounded-2xl border border-rose-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-rose-100 pb-3">
                <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-sm">
                  3 ลด
                </div>
                <h4 className="font-bold text-slate-900 text-sm">การหลีกเลี่ยงพฤติกรรมเสี่ยง (3 ลด)</h4>
              </div>

              <div className="space-y-3.5">
                <div className="p-3.5 rounded-xl bg-rose-50/60 border border-rose-100 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-rose-900 text-xs">
                    <Ban className="w-4 h-4 text-rose-600" />
                    <span>ลด ๑: ลดความอ้วน (Reduce Obesity)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    ควบคุมน้ำหนักตัวให้อยู่ในเกณฑ์มาตรฐาน เพื่อลดภาระการทำงานของหัวใจและระบบไหลเวียนโลหิต ซึ่งในผู้ป่วยธาลัสซีเมียหัวใจต้องทำงานหนักกว่าปกติอยู่แล้ว
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-100 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-amber-900 text-xs">
                    <Wine className="w-4 h-4 text-amber-600" />
                    <span>ลด ๒: ลดสุรา เครื่องดื่มแอลกอฮอล์ (Reduce Alcohol)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    งดหรือลดเครื่องดื่มแอลกอฮอล์ทุกชนิด เพื่อปกป้องตับ เพราะผู้ป่วยธาลัสซีเมียมักมีธาตุเหล็กสะสมในเซลล์ตับอยู่แล้ว แอลกอฮอล์จะเร่งให้เกิดตับแข็ง (Liver cirrhosis) และตับวายเร็วขึ้น
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                    <Cigarette className="w-4 h-4 text-slate-700" />
                    <span>ลด ๓: ลดบุหรี่ บุหรี่ไฟฟ้า (Reduce Smoking &amp; Vape)</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    ละเว้นการสูบบุหรี่และบุหรี่ไฟฟ้า ควันบุหรี่ทำให้ระดับออกซิเจนในเลือดลดลง และทำให้เม็ดเลือดแดงจับก๊าซคาร์บอนมอนอกไซด์แทนออกซิเจน ส่งผลให้เนื้อเยื่อขาดออกซิเจนรุนแรงขึ้น
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
