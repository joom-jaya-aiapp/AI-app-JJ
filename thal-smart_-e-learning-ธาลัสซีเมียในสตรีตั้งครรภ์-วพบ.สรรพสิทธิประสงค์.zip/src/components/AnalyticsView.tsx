import React, { useState } from 'react';
import { 
  Award, 
  BarChart3, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  User, 
  Calendar, 
  ArrowRight, 
  BookOpen, 
  Layers,
  GraduationCap,
  Download,
  FileText,
  Printer
} from 'lucide-react';
import { QuizResult, StudentProfile, QuickCheckResult } from '../types';
import { ReportDownloadModal } from './ReportDownloadModal';

interface AnalyticsViewProps {
  student: StudentProfile;
  quizResult: QuizResult | null;
  completedCasesCount: number;
  totalCasesScore: number;
  quickCheckResults?: Record<string, QuickCheckResult>;
  onOpenCertificate: () => void;
  onGoToQuiz: () => void;
  onGoToCases: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  student,
  quizResult,
  completedCasesCount,
  totalCasesScore,
  quickCheckResults = {},
  onOpenCertificate,
  onGoToQuiz,
  onGoToCases,
}) => {
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const isQuizPassed = quizResult && quizResult.completed && quizResult.passed;
  const isEligibleForCertificate = isQuizPassed && completedCasesCount >= 4; // Passing quiz + at least 4 cases completed

  // Automated smart clinical recommendations based on actual category performance
  const generateRecommendations = () => {
    if (!quizResult) {
      return {
        strengths: ['ยังไม่มีข้อมูลผลการทดสอบ กรุณาทำแบบทดสอบ 40 ข้อเพื่อประเมินสมรรถนะ'],
        weaknesses: ['ต้องทำแบบทดสอบเพื่อระบุจุดพัฒนา'],
        actionPlan: 'เข้าทำแบบทดสอบ 40 ข้อและฝึกทำกรณีศึกษาเพื่อเปิดระบบวิเคราะห์รายบุคคล',
      };
    }

    const catScores = quizResult.categoryScores;
    const strengths: string[] = [];
    const weaknesses: string[] = [];

    Object.entries(catScores).forEach(([cat, score]) => {
      const pct = Math.round((score.correct / score.total) * 100);
      if (pct >= 80) {
        strengths.push(`${cat} (ความแม่นยำ ${pct}%)`);
      } else if (pct < 70) {
        weaknesses.push(`${cat} (ความแม่นยำ ${pct}%)`);
      }
    });

    if (strengths.length === 0) {
      strengths.push('มีความพยายามในการทำแบบทดสอบครบทุกข้อ');
    }
    if (weaknesses.length === 0) {
      weaknesses.push('มีความรอบรู้ระดับดีเยี่ยมในทุกมิติ');
    }

    let actionPlan = '';
    if (quizResult.percentage >= 85) {
      actionPlan = 'มีความพร้อมระดับสูงมากสำหรับการขึ้นฝึกปฏิบัติงานในห้องคลอดและคลินิก ANC สรรพสิทธิประสงค์ พร้อมเป็นผู้นำในการแปลผล Lab และให้คำปรึกษาแก่สตรีตั้งครรภ์';
    } else if (quizResult.percentage >= 70) {
      actionPlan = 'ผ่านเกณฑ์มาตรฐาน แนะนำให้ทบทวนอัลกอริทึมการคัดกรองคู่เสี่ยง Hb Bart’s และข้อควรระวังเรื่องการงดยาธาตุเหล็กในผู้ป่วยธาลัสซีเมียเพื่อเพิ่มความแม่นยำในการดูแลทางคลินิก';
    } else {
      actionPlan = 'ยังไม่ผ่านเกณฑ์ร้อยละ 70 แนะนำให้ศึกษาโมดูล "ฐานความรู้" โดยเฉพาะเรื่องเกณฑ์ตัด Cut-off MCV, DCIP และการคำนวณโอกาสเสี่ยงทางพันธุศาสตร์ จากนั้นทดลองทำแบบทดสอบใหม่อีกครั้ง';
    }

    return { strengths, weaknesses, actionPlan };
  };

  const recs = generateRecommendations();

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold mb-2">
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Personalized Learning Analytics</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              ระบบสรุปผลการเรียนรู้รายบุคคลและการให้คำแนะนำอัตโนมัติ
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              วิเคราะห์สมรรถนะการตัดสินใจทางคลินิกรายบุคคลของนักศึกษาพยาบาลศาสตร์ วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ พร้อมระบบออกใบประกาศนียบัตรดิจิทัลเมื่อผ่านเกณฑ์การประเมิน
            </p>
          </div>

          {/* Action Trigger Buttons (Download Report PDF & Certificate) */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-download-report-pdf-banner"
              onClick={() => setIsReportModalOpen(true)}
              className="px-4 py-2.5 bg-gradient-to-r from-pink-600 via-rose-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-pink-600/20 flex items-center gap-2 transition transform hover:scale-102 active:scale-98"
            >
              <Download className="w-4 h-4 text-white" />
              <span>ดาวน์โหลดรายงาน &amp; เกียรติบัตร (PDF)</span>
            </button>

            {isEligibleForCertificate ? (
              <button
                id="btn-open-certificate-banner"
                onClick={onOpenCertificate}
                className="px-4 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-yellow-500/30 flex items-center gap-2 transition"
              >
                <Award className="w-4 h-4 text-slate-950" />
                <span>เปิดดูเกียรติบัตร (Certificate)</span>
              </button>
            ) : (
              <div className="bg-slate-950/70 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-400 text-right">
                <span className="text-[10px] block">สถานะใบประกาศนียบัตร:</span>
                <span className="text-amber-400 font-semibold text-[11px]">
                  {quizResult?.completed
                    ? quizResult.passed
                      ? `ทำกรณีศึกษาเพิ่มอีก ${Math.max(0, 4 - completedCasesCount)} เคส`
                      : 'คะแนนสอบต้องถึง 70%'
                    : 'ต้องสอบผ่านข้อสอบ 40 ข้อ'}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Student Profile Card & Key KPI Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Student Info Card */}
        <div className="md:col-span-1 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-500 to-sky-500 text-white font-bold flex items-center justify-center text-lg shadow-md">
              {student.name.slice(0, 1) || 'พ'}
            </div>
            <div>
              <div className="font-bold text-slate-900 text-sm">{student.name}</div>
              <div className="text-xs text-slate-500">รหัส {student.studentId}</div>
            </div>
          </div>
          <div className="text-[11px] text-slate-600 space-y-1 pt-2 border-t border-slate-100">
            <div><strong>สถาบัน:</strong> {student.college}</div>
            <div><strong>รุ่นการศึกษา:</strong> {student.cohort}</div>
            <div><strong>วันที่ประเมิน:</strong> {quizResult?.dateCompleted || 'อยู่ระหว่างการเรียนรู้'}</div>
          </div>
        </div>

        {/* KPI 1: Quiz Score */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm text-center flex flex-col justify-center">
          <span className="text-xs font-semibold text-slate-500 uppercase">
            ผลสอบรวม 40 ข้อ
          </span>
          <div className="text-3xl font-extrabold text-slate-900 mt-1">
            {quizResult ? `${quizResult.score} / 40` : '-'}
          </div>
          <span className="text-xs text-slate-500 mt-1">
            {quizResult ? (
              <span className={`font-bold ${quizResult.passed ? 'text-emerald-600' : 'text-rose-600'}`}>
                {quizResult.percentage}% ({quizResult.passed ? 'ผ่านเกณฑ์' : 'ไม่ผ่านเกณฑ์'})
              </span>
            ) : (
              <button onClick={onGoToQuiz} className="text-pink-600 font-semibold underline">
                เริ่มทำข้อสอบ
              </button>
            )}
          </span>
        </div>

        {/* KPI 2: Cases Completed */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm text-center flex flex-col justify-center">
          <span className="text-xs font-semibold text-slate-500 uppercase">
            กรณีศึกษาเสมือนจริง
          </span>
          <div className="text-3xl font-extrabold text-slate-900 mt-1">
            {completedCasesCount} / 8
          </div>
          <span className="text-xs text-slate-500 mt-1">
            คะแนนสะสม: <strong className="text-pink-600">{totalCasesScore}</strong> คะแนน
          </span>
        </div>

        {/* KPI 3: Final Certification Status */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm text-center flex flex-col justify-center">
          <span className="text-xs font-semibold text-slate-500 uppercase">
            สถานะเกียรติบัตร (Certificate)
          </span>
          <div className="mt-2 flex justify-center">
            {isEligibleForCertificate ? (
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
            )}
          </div>
          <span className="text-xs font-bold mt-1">
            {isEligibleForCertificate ? (
              <span className="text-emerald-600">พร้อมรับเกียรติบัตร</span>
            ) : (
              <span className="text-amber-600">ยังไม่ครบเกณฑ์</span>
            )}
          </span>
        </div>
      </div>

      {/* Official PDF Report & Transcript Quick Action Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-5 text-white shadow-md border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-pink-500/20 text-pink-400 border border-pink-500/30 flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-0">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex flex-wrap items-center gap-2">
              <span>เอกสารรายงานผลสัมฤทธิ์และเกียรติบัตรอิเล็กทรอนิกส์ (Official Transcript &amp; Certificate)</span>
              <span className="text-[10px] bg-pink-500/30 text-pink-200 border border-pink-500/40 px-2 py-0.5 rounded-full font-semibold">
                PDF Document
              </span>
            </h4>
            <p className="text-xs text-slate-300 mt-0.5 max-w-3xl leading-relaxed">
              ดาวน์โหลดเอกสารประเมินผลการเรียนรู้ทางการพยาบาล ครอบคลุมคะแนนแบบทดสอบ 40 ข้อ, สมรรถนะกรณีศึกษา 8 เคส, แผนพัฒนาการตัดสินใจทางคลินิก และใบประกาศนียบัตร สำหรับบันทึกเก็บเป็นหลักฐานการศึกษา
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-shrink-0">
          <button
            id="btn-download-pdf-transcript-card"
            onClick={() => setIsReportModalOpen(true)}
            className="w-full md:w-auto px-4 py-2.5 bg-gradient-to-r from-pink-600 via-rose-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-pink-600/25 flex items-center justify-center gap-2 transition transform hover:scale-102 active:scale-98"
          >
            <Download className="w-4 h-4" />
            <span>ดาวน์โหลดเอกสาร PDF (Download PDF)</span>
          </button>
        </div>
      </div>

      {/* Quick Check Preparation Status Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">
              ความพร้อมก่อนสอบปลายภาค: การทำแบบทดสอบสั้นประจำโมดูล (Quick Check Modules)
            </h3>
          </div>
          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            ผ่านแล้ว {Object.values(quickCheckResults).filter((q) => q.passed).length} โมดูล
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
          {[
            { id: 'gate1_match', label: 'ประตู 1: เลือกคู่ (Pair Selection)' },
            { id: 'gate2_pregnancy', label: 'ประตู 2: เลือกครรภ์ (Pregnancy Screening)' },
            { id: 'gate3_birth', label: 'ประตู 3: เลือกคลอด (Birth Planning)' },
          ].map((item) => {
            const qc = quickCheckResults[item.id];
            return (
              <div 
                key={item.id}
                className={`p-3 rounded-xl border flex items-center justify-between ${
                  qc && qc.passed 
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' 
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                <div className="min-w-0 pr-2">
                  <div className="font-bold truncate">{item.label}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {qc ? `คะแนน: ${qc.score}/${qc.total} ข้อ` : 'ยังไม่ได้ทบทวน'}
                  </div>
                </div>
                <div>
                  {qc && qc.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <span className="text-[10px] text-slate-400 font-semibold px-1.5 py-0.5 rounded bg-slate-200/80">
                      รอทำ
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Category Competency Breakdown */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
          <Layers className="w-4 h-4 text-pink-600" />
          <h3 className="font-bold text-slate-900 text-sm">
            การกระจายความเชี่ยวชาญตามหมวดเนื้อหา (Competency Breakdown)
          </h3>
        </div>

        {quizResult ? (
          <div className="space-y-3.5">
            {Object.entries(quizResult.categoryScores).map(([cat, val], idx) => {
              const pct = Math.round((val.correct / val.total) * 100);
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold text-slate-700">
                    <span>{cat}</span>
                    <span className={pct >= 70 ? 'text-emerald-600' : 'text-rose-600'}>
                      {val.correct} / {val.total} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        pct >= 80 ? 'bg-emerald-500' : pct >= 70 ? 'bg-sky-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6 text-slate-400 text-xs">
            ยังไม่มีข้อมูลคะแนนรายหมวด กรุณาทำแบบทดสอบ 40 ข้อเพื่อดูสมรรถนะ
          </div>
        )}
      </div>

      {/* Automated Diagnostic Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Strengths */}
        <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-emerald-950 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>จุดเด่นที่คุณทำได้ดีเยี่ยม (Strengths)</span>
          </div>
          <ul className="space-y-1 text-xs text-slate-700">
            {recs.strengths.map((s, i) => (
              <li key={i} className="flex items-start gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0"></span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Areas for Review */}
        <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-amber-950 text-xs">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <span>จุดที่ควรศึกษาทบทวนเพิ่มเติม (Focus Areas)</span>
          </div>
          <ul className="space-y-1 text-xs text-slate-700">
            {recs.weaknesses.map((w, i) => (
              <li key={i} className="flex items-start gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 flex-shrink-0"></span>
                <span>{w}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Clinical Action Plan */}
        <div className="p-5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sky-950 text-xs">
            <Sparkles className="w-4 h-4 text-sky-600" />
            <span>คำแนะนำทางคลินิกเสมือนจริง (Action Plan)</span>
          </div>
          <p className="text-xs text-slate-700 leading-relaxed">
            {recs.actionPlan}
          </p>
        </div>
      </div>

      {/* Download Performance Report & Certificate Modal */}
      <ReportDownloadModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        student={student}
        quizResult={quizResult}
        completedCasesCount={completedCasesCount}
        totalCasesScore={totalCasesScore}
      />
    </div>
  );
};
