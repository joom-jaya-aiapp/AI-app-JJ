import React, { useState } from 'react';
import { 
  FlaskConical, 
  RotateCcw, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ArrowRight,
  Calculator,
  Layers,
  HelpCircle,
  FileSpreadsheet,
  BookOpen,
  Pin,
  PinOff,
  Sidebar
} from 'lucide-react';
import { LabResult, PingPongColorTag } from '../types';
import { interpretIndividualLab, evaluateCoupleRisk } from '../utils/labInterpreter';
import { LabReferenceGuide } from './LabReferenceGuide';

const PingPongTagBadge: React.FC<{
  tag?: PingPongColorTag;
  size?: 'sm' | 'md';
  showLabel?: boolean;
}> = ({ tag, size = 'md', showLabel = true }) => {
  if (!tag) return null;
  const isSm = size === 'sm';
  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border shadow-2xs transition-transform ${tag.badgeBg} ${tag.borderColor}`}
      title={`${tag.label}: ${tag.description}`}
    >
      <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${tag.dotColor}`} />
      <span className={isSm ? 'text-[11px]' : 'text-xs'}>
        {showLabel ? tag.badgeText : tag.colorName}
      </span>
    </div>
  );
};

export const LabEngineView: React.FC = () => {
  // Wife default lab state
  const [wifeLab, setWifeLab] = useState<LabResult>({
    mcv: 72.4,
    mch: 24.2,
    dcip: 'Positive',
    ofTest: 'Positive',
    hbTyping: 'EA',
    hbePercent: 28.5,
    hba2Percent: 2.5,
    hbfPercent: 0.5,
    pcrAlpha1: 'Not tested',
  });

  // Husband default lab state
  const [husbandLab, setHusbandLab] = useState<LabResult>({
    mcv: 71.5,
    mch: 23.8,
    dcip: 'Negative',
    ofTest: 'Positive',
    hbTyping: 'A2A',
    hbePercent: 0,
    hba2Percent: 5.4,
    hbfPercent: 0.5,
    pcrAlpha1: 'Not tested',
  });

  // Quick Reference Guide state (slide-out drawer or persistent sidebar)
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(() => {
    // Open by default on wide screens so users notice it immediately
    return typeof window !== 'undefined' ? window.innerWidth >= 1280 : false;
  });
  const [isGuidePinned, setIsGuidePinned] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem('thal_lab_guide_pinned');
    return saved !== null ? saved === 'true' : window.innerWidth >= 1280;
  });

  const handleTogglePin = () => {
    setIsGuidePinned((prev) => {
      const next = !prev;
      localStorage.setItem('thal_lab_guide_pinned', String(next));
      return next;
    });
  };

  const handleApplyPresetLab = (target: 'wife' | 'husband', values: Partial<LabResult>) => {
    if (target === 'wife') {
      setWifeLab((prev) => ({ ...prev, ...values }));
    } else {
      setHusbandLab((prev) => ({ ...prev, ...values }));
    }
  };

  // Quick preset loader
  const loadPreset = (presetName: string) => {
    switch (presetName) {
      case 'case_slide52': // Slide 52: ภรรยา EA (29.1%) + สามี A2A (MCV 73.8)
        setWifeLab({
          mcv: 85,
          mch: 28,
          dcip: 'Positive',
          ofTest: 'Not tested',
          hbTyping: 'EA',
          hbePercent: 29.1,
          hba2Percent: 2.5,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 73.8,
          mch: 25.1,
          dcip: 'Negative',
          ofTest: 'Not tested',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.6,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        break;

      case 'case_slide50': // Slide 50: ภรรยา EE + สามี Alpha thal trait
        setWifeLab({
          mcv: 59.8,
          mch: 20.0,
          dcip: 'Positive',
          ofTest: 'Not tested',
          hbTyping: 'EE',
          hbePercent: 86.3,
          hba2Percent: 0,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 70.1,
          mch: 24.0,
          dcip: 'Negative',
          ofTest: 'Not tested',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.1,
          hbfPercent: 0.5,
          pcrAlpha1: 'Positive',
        });
        break;

      case 'risk_barts': // เสี่ยง Hb Bart's: ทั้งคู่ α-thal 1
        setWifeLab({
          mcv: 68.0,
          mch: 22.0,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.3,
          hbfPercent: 0.5,
          pcrAlpha1: 'Positive',
        });
        setHusbandLab({
          mcv: 69.5,
          mch: 22.8,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.2,
          hbfPercent: 0.5,
          pcrAlpha1: 'Positive',
        });
        break;

      case 'risk_beta_e': // เสี่ยง β-thal / Hb E (ยอดฮิตอีสาน)
        setWifeLab({
          mcv: 66.0,
          mch: 21.5,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 5.6,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 78.0,
          mch: 25.5,
          dcip: 'Positive',
          ofTest: 'Positive',
          hbTyping: 'EA',
          hbePercent: 28.0,
          hba2Percent: 2.5,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        break;

      case 'case_slide45': // Slide 45: Family Study สามี A2F (β0/β0) + ภรรยา EA (β/βE)
        setWifeLab({
          mcv: 82.0,
          mch: 27.5,
          dcip: 'Positive',
          ofTest: 'Positive',
          hbTyping: 'EA',
          hbePercent: 28.0,
          hba2Percent: 2.5,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 64.0,
          mch: 19.5,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2F',
          hbePercent: 0,
          hba2Percent: 3.0,
          hbfPercent: 22.0,
          pcrAlpha1: 'Not tested',
        });
        break;

      case 'risk_homo_beta': // เสี่ยง Homozygous Beta-thal
        setWifeLab({
          mcv: 67.0,
          mch: 21.0,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 5.5,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 65.0,
          mch: 20.8,
          dcip: 'Negative',
          ofTest: 'Positive',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 5.8,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        break;

      case 'normal_couple': // ปกติทั้งคู่
        setWifeLab({
          mcv: 88.0,
          mch: 29.5,
          dcip: 'Negative',
          ofTest: 'Negative',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.8,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        setHusbandLab({
          mcv: 86.0,
          mch: 29.0,
          dcip: 'Negative',
          ofTest: 'Negative',
          hbTyping: 'A2A',
          hbePercent: 0,
          hba2Percent: 2.7,
          hbfPercent: 0.5,
          pcrAlpha1: 'Not tested',
        });
        break;
      default:
        break;
    }
  };

  const wifeInterp = interpretIndividualLab(wifeLab, 'ภรรยา');
  const husbandInterp = interpretIndividualLab(husbandLab, 'สามี');
  const coupleRisk = evaluateCoupleRisk(wifeLab, husbandLab);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold mb-2">
              <FlaskConical className="w-3.5 h-3.5" />
              <span>Diagnostic Algorithm Simulator</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              หัวใจของบทเรียน: Lab Interpretation Engine
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              ระบบจำลองการแปลผลการตรวจทางห้องปฏิบัติการธาลัสซีเมียเสมือนจริง อิงตามแนวทางกระทรวงสาธารณสุขไทยและเอกสารวิชาการ เพื่อฝึกทักษะการตัดสินใจทางคลินิก การวิเคราะห์คู่เสี่ยง 3 โรค และการสร้างตารางพันธุศาสตร์ (Punnett Square) อัตโนมัติ
            </p>

            {/* Quick Reference Guide Trigger Buttons */}
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <button
                id="btn-toggle-lab-guide-banner"
                onClick={() => setIsGuideOpen(!isGuideOpen)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition shadow-sm border ${
                  isGuideOpen
                    ? 'bg-pink-500 hover:bg-pink-600 text-white border-pink-400'
                    : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-pink-300" />
                <span>{isGuideOpen ? 'ซ่อนคู่มืออ้างอิง (Hide Guide)' : 'เปิดคู่มือค่าอ้างอิงเลือด & Hb Typing'}</span>
              </button>
              {isGuideOpen && (
                <button
                  id="btn-toggle-pin-banner"
                  onClick={handleTogglePin}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition border ${
                    isGuidePinned
                      ? 'bg-indigo-600/80 hover:bg-indigo-600 text-white border-indigo-400'
                      : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                >
                  {isGuidePinned ? <PinOff className="w-3.5 h-3.5" /> : <Pin className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">{isGuidePinned ? 'ถอนหมุดแถบข้าง' : 'ปักหมุดแถบข้าง (Side-by-Side)'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Presets */}
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 w-full md:w-auto">
            <span className="text-[11px] font-semibold text-sky-400 block mb-2">
              เลือกเคสตัวอย่างจากบทเรียน (Clinical Presets):
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-xs">
              <button
                onClick={() => loadPreset('risk_beta_e')}
                className="px-2.5 py-1.5 bg-pink-950/80 hover:bg-pink-900 text-pink-200 rounded border border-pink-700/60 transition text-left"
              >
                เสี่ยง β-thal/Hb E
              </button>
              <button
                onClick={() => loadPreset('risk_barts')}
                className="px-2.5 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-200 rounded border border-rose-700/60 transition text-left"
              >
                เสี่ยง Hb Bart’s
              </button>
              <button
                onClick={() => loadPreset('risk_homo_beta')}
                className="px-2.5 py-1.5 bg-purple-950/80 hover:bg-purple-900 text-purple-200 rounded border border-purple-700/60 transition text-left"
              >
                เสี่ยง Homo β-thal
              </button>
              <button
                onClick={() => loadPreset('case_slide45')}
                className="px-2.5 py-1.5 bg-pink-900/80 hover:bg-pink-800 text-pink-200 rounded border border-pink-700/60 transition text-left flex items-center gap-1"
                title="สไลด์ 45: สามี A2F (β0/β0) + ภรรยา EA (β/βE) -> ลูกเป็นโรค 50%, พาหะ 50%"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400"></span>
                <span>สไลด์ 45 (สามี A2F + ภรรยา EA)</span>
              </button>
              <button
                onClick={() => loadPreset('case_slide50')}
                className="px-2.5 py-1.5 bg-blue-950/80 hover:bg-blue-900 text-blue-200 rounded border border-blue-700/60 transition text-left"
              >
                สไลด์ 50 (EE + α-thal)
              </button>
              <button
                onClick={() => loadPreset('case_slide52')}
                className="px-2.5 py-1.5 bg-sky-950/80 hover:bg-sky-900 text-sky-200 rounded border border-sky-700/60 transition text-left"
              >
                สไลด์ 52 (EA + A2A)
              </button>
              <button
                onClick={() => loadPreset('normal_couple')}
                className="px-2.5 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-200 rounded border border-emerald-700/60 transition text-left"
              >
                คู่สมรสตรวจปกติ
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Toolbar above Workspace */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white px-4 py-3 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 text-xs">
          <span className="font-bold text-slate-800 flex items-center gap-1.5">
            <FlaskConical className="w-4 h-4 text-pink-600" />
            แผงจำลองการกรอกผลแล็บ (คู่สมรส ภรรยา &amp; สามี)
          </span>
          <span className="hidden md:inline text-slate-300">|</span>
          <span className="hidden md:inline text-slate-500 text-[11px]">
            กรอกค่า MCV, MCH, DCIP, Hb Typing เพื่อประเมินความเสี่ยงและสร้างตาราง Punnett Square อัตโนมัติ
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-quick-guide-toolbar"
            onClick={() => setIsGuideOpen(!isGuideOpen)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              isGuideOpen
                ? 'bg-pink-100 text-pink-700 border border-pink-300'
                : 'bg-slate-100 hover:bg-pink-50 text-slate-700 hover:text-pink-700 border border-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-pink-600" />
            <span>{isGuideOpen ? 'คู่มือเปิดอยู่' : 'เปิดคู่มืออ้างอิงเลือด'}</span>
            <span className="text-[10px] bg-pink-200 text-pink-800 px-1 rounded font-mono">
              MCV/Hb
            </span>
          </button>
        </div>
      </div>

      {/* Main Workspace Layout (Supports Side-by-Side Pinned Sidebar or Slide-out Drawer) */}
      <div className={`flex flex-col ${isGuidePinned && isGuideOpen ? 'xl:flex-row' : ''} items-start gap-6`}>
        <div className="flex-1 min-w-0 w-full space-y-6">
          {/* Dual Lab Input Panel: Wife & Husband */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Wife Lab Input */}
        <div className="bg-white rounded-2xl border-2 border-pink-200 shadow-sm overflow-hidden">
          <div className="bg-pink-50 p-4 border-b border-pink-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-pink-600 text-white font-bold flex items-center justify-center text-xs">
                ญ
              </span>
              <h3 className="font-bold text-pink-950 text-sm">
                ผลการตรวจทางห้องปฏิบัติการ: ภรรยา (สตรีตั้งครรภ์)
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-pink-700 bg-pink-100 px-2 py-0.5 rounded">
              Wife / Mother
            </span>
          </div>

          <div className="p-5 space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  MCV (fL) <span className="text-slate-400 font-normal">(&lt; 80 ผิดปกติ)</span>
                </label>
                <input
                  type="number"
                  value={wifeLab.mcv}
                  onChange={(e) => setWifeLab({ ...wifeLab, mcv: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  placeholder="เช่น 72.4"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  MCH (pg) <span className="text-slate-400 font-normal">(&lt; 27 ผิดปกติ)</span>
                </label>
                <input
                  type="number"
                  value={wifeLab.mch}
                  onChange={(e) => setWifeLab({ ...wifeLab, mch: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  placeholder="เช่น 24.2"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">DCIP Screen</label>
                <select
                  value={wifeLab.dcip}
                  onChange={(e) => setWifeLab({ ...wifeLab, dcip: e.target.value as any })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="Positive">Positive (+)</option>
                  <option value="Negative">Negative (-)</option>
                  <option value="Not tested">ไม่ได้ตรวจ</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Hb Typing</label>
                <select
                  value={wifeLab.hbTyping}
                  onChange={(e) => setWifeLab({ ...wifeLab, hbTyping: e.target.value })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="A2A">A2A (ปกติ หรือ β-trait หรือ α-trait)</option>
                  <option value="EA">EA (Hb E trait)</option>
                  <option value="EE">EE (Homozygous Hb E)</option>
                  <option value="EF">EF (β0-thal / Hb E)</option>
                  <option value="EFA">EFA (β+-thal / Hb E)</option>
                  <option value="A2AH">A2AH (Hb H disease)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">% Hb A2</label>
                <input
                  type="number"
                  step="0.1"
                  value={wifeLab.hba2Percent}
                  onChange={(e) => setWifeLab({ ...wifeLab, hba2Percent: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  placeholder="&gt;3.5% = β-trait"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">% Hb E</label>
                <input
                  type="number"
                  step="0.1"
                  value={wifeLab.hbePercent}
                  onChange={(e) => setWifeLab({ ...wifeLab, hbePercent: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  placeholder="25-35% = EA"
                />
              </div>

              <div className="col-span-2 sm:col-span-3">
                <label className="font-semibold text-slate-700 block mb-1">
                  PCR for α-thalassemia 1 (SEA & THAI deletion)
                </label>
                <select
                  value={wifeLab.pcrAlpha1}
                  onChange={(e) => setWifeLab({ ...wifeLab, pcrAlpha1: e.target.value as any })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="Not tested">ยังไม่ได้ส่งตรวจ (Not tested)</option>
                  <option value="Positive">Positive (+) ตรวจพบ α-thal 1 deletion</option>
                  <option value="Negative">Negative (-) ไม่พบ α-thal 1 deletion</option>
                </select>
              </div>
            </div>

            {/* Wife Interpretation Result Card */}
            <div className="p-3.5 rounded-xl bg-pink-50/70 border border-pink-200 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-1.5">
                <div className="text-[11px] font-bold text-pink-900 uppercase">
                  การแปลผลของสตรีตั้งครรภ์:
                </div>
                {wifeInterp.pingPongTag && (
                  <PingPongTagBadge tag={wifeInterp.pingPongTag} size="sm" />
                )}
              </div>
              <div className="font-bold text-slate-900 text-sm">{wifeInterp.conditionName}</div>
              <div className="text-slate-600 text-xs">{wifeInterp.details}</div>
              
              {wifeInterp.pingPongTag && (
                <div className={`text-[11px] p-2 rounded-lg border flex items-start gap-2 ${wifeInterp.pingPongTag.badgeBg} ${wifeInterp.pingPongTag.borderColor}`}>
                  <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 mt-0.5 ${wifeInterp.pingPongTag.dotColor}`} />
                  <div>
                    <span className="font-bold">แนวคิดปิงปองจราจร 6 สี ({wifeInterp.pingPongTag.colorName}):</span>{' '}
                    <span>{wifeInterp.pingPongTag.description}</span>
                  </div>
                </div>
              )}

              <div className="text-[11px] text-pink-800 bg-white/90 p-2 rounded-lg border border-pink-200 font-medium">
                <strong>คำแนะนำ:</strong> {wifeInterp.recommendation}
              </div>
            </div>
          </div>
        </div>

        {/* Husband Lab Input */}
        <div className="bg-white rounded-2xl border-2 border-sky-200 shadow-sm overflow-hidden">
          <div className="bg-sky-50 p-4 border-b border-sky-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-sky-600 text-white font-bold flex items-center justify-center text-xs">
                ช
              </span>
              <h3 className="font-bold text-sky-950 text-sm">
                ผลการตรวจทางห้องปฏิบัติการ: สามี (คู่สมรส)
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-sky-700 bg-sky-100 px-2 py-0.5 rounded">
              Husband / Father
            </span>
          </div>

          <div className="p-5 space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  MCV (fL) <span className="text-slate-400 font-normal">(&lt; 80 ผิดปกติ)</span>
                </label>
                <input
                  type="number"
                  value={husbandLab.mcv}
                  onChange={(e) => setHusbandLab({ ...husbandLab, mcv: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="เช่น 71.5"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  MCH (pg) <span className="text-slate-400 font-normal">(&lt; 27 ผิดปกติ)</span>
                </label>
                <input
                  type="number"
                  value={husbandLab.mch}
                  onChange={(e) => setHusbandLab({ ...husbandLab, mch: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="เช่น 23.8"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">DCIP Screen</label>
                <select
                  value={husbandLab.dcip}
                  onChange={(e) => setHusbandLab({ ...husbandLab, dcip: e.target.value as any })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="Positive">Positive (+)</option>
                  <option value="Negative">Negative (-)</option>
                  <option value="Not tested">ไม่ได้ตรวจ</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Hb Typing</label>
                <select
                  value={husbandLab.hbTyping}
                  onChange={(e) => setHusbandLab({ ...husbandLab, hbTyping: e.target.value })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="A2A">A2A (ปกติ หรือ β-trait หรือ α-trait)</option>
                  <option value="EA">EA (Hb E trait)</option>
                  <option value="EE">EE (Homozygous Hb E)</option>
                  <option value="EF">EF (β0-thal / Hb E)</option>
                  <option value="EFA">EFA (β+-thal / Hb E)</option>
                  <option value="A2AH">A2AH (Hb H disease)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">% Hb A2</label>
                <input
                  type="number"
                  step="0.1"
                  value={husbandLab.hba2Percent}
                  onChange={(e) => setHusbandLab({ ...husbandLab, hba2Percent: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="&gt;3.5% = β-trait"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">% Hb E</label>
                <input
                  type="number"
                  step="0.1"
                  value={husbandLab.hbePercent}
                  onChange={(e) => setHusbandLab({ ...husbandLab, hbePercent: e.target.value === '' ? '' : Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="25-35% = EA"
                />
              </div>

              <div className="col-span-2 sm:col-span-3">
                <label className="font-semibold text-slate-700 block mb-1">
                  PCR for α-thalassemia 1 (SEA & THAI deletion)
                </label>
                <select
                  value={husbandLab.pcrAlpha1}
                  onChange={(e) => setHusbandLab({ ...husbandLab, pcrAlpha1: e.target.value as any })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="Not tested">ยังไม่ได้ส่งตรวจ (Not tested)</option>
                  <option value="Positive">Positive (+) ตรวจพบ α-thal 1 deletion</option>
                  <option value="Negative">Negative (-) ไม่พบ α-thal 1 deletion</option>
                </select>
              </div>
            </div>

            {/* Husband Interpretation Result Card */}
            <div className="p-3.5 rounded-xl bg-sky-50/70 border border-sky-200 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-1.5">
                <div className="text-[11px] font-bold text-sky-900 uppercase">
                  การแปลผลของสามี:
                </div>
                {husbandInterp.pingPongTag && (
                  <PingPongTagBadge tag={husbandInterp.pingPongTag} size="sm" />
                )}
              </div>
              <div className="font-bold text-slate-900 text-sm">{husbandInterp.conditionName}</div>
              <div className="text-slate-600 text-xs">{husbandInterp.details}</div>

              {husbandInterp.pingPongTag && (
                <div className={`text-[11px] p-2 rounded-lg border flex items-start gap-2 ${husbandInterp.pingPongTag.badgeBg} ${husbandInterp.pingPongTag.borderColor}`}>
                  <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 mt-0.5 ${husbandInterp.pingPongTag.dotColor}`} />
                  <div>
                    <span className="font-bold">แนวคิดปิงปองจราจร 6 สี ({husbandInterp.pingPongTag.colorName}):</span>{' '}
                    <span>{husbandInterp.pingPongTag.description}</span>
                  </div>
                </div>
              )}

              <div className="text-[11px] text-sky-800 bg-white/90 p-2 rounded-lg border border-sky-200 font-medium">
                <strong>คำแนะนำ:</strong> {husbandInterp.recommendation}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Couple Risk Assessment & Punnett Square Output */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 to-indigo-600 text-white flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                Comprehensive Couple Assessment
              </span>
              <h3 className="text-xl font-bold text-slate-900">
                การประเมินความเสี่ยงคู่สมรสและการถ่ายทอดพันธุศาสตร์
              </h3>
            </div>
          </div>

          <span
            className={`px-3 py-1 rounded-full text-xs font-bold ${
              coupleRisk.riskLevel.includes('High')
                ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse'
                : coupleRisk.riskLevel.includes('Low')
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
            }`}
          >
            {coupleRisk.riskLevel}
          </span>
        </div>

        {/* 6-Color Ping Pong Linkage Visualizer (Mother + Father -> Offspring Chance) */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-pink-50 via-slate-50 to-sky-50 border-2 border-indigo-100 shadow-2xs">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-indigo-100">
            <div className="flex items-center gap-2">
              <span className="text-base">🏓</span>
              <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                การเชื่อมโยงการแปลผลตามแนวคิดปิงปองจราจร 6 สี (Triple Color Tagging)
              </h4>
            </div>
            <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-100/70 px-2 py-0.5 rounded border border-indigo-200">
              Mother &bull; Father &bull; Offspring Risk
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            {/* Mother ping pong */}
            <div className="p-3 bg-white rounded-xl border border-pink-200 shadow-2xs flex flex-col items-center">
              <div className="text-[10px] font-bold text-pink-700 uppercase mb-1">
                มารดา (สตรีตั้งครรภ์)
              </div>
              <PingPongTagBadge tag={wifeInterp.pingPongTag} size="sm" />
              <div className="text-[11px] font-bold text-slate-800 mt-1.5 truncate max-w-full">
                {wifeInterp.conditionName}
              </div>
            </div>

            {/* Father ping pong */}
            <div className="p-3 bg-white rounded-xl border border-sky-200 shadow-2xs flex flex-col items-center">
              <div className="text-[10px] font-bold text-sky-700 uppercase mb-1">
                สามี (คู่สมรส)
              </div>
              <PingPongTagBadge tag={husbandInterp.pingPongTag} size="sm" />
              <div className="text-[11px] font-bold text-slate-800 mt-1.5 truncate max-w-full">
                {husbandInterp.conditionName}
              </div>
            </div>

            {/* Offspring Highest Risk ping pong */}
            <div className="p-3 bg-white rounded-xl border border-purple-200 shadow-2xs flex flex-col items-center">
              <div className="text-[10px] font-bold text-purple-700 uppercase mb-1">
                โอกาสทารกในครรภ์สูงสุด
              </div>
              {coupleRisk.diseaseChance > 0 ? (
                <>
                  <PingPongTagBadge tag={coupleRisk.diseasePingPong} size="sm" />
                  <div className="text-[11px] font-bold text-rose-700 mt-1.5">
                    เสี่ยงโรค {coupleRisk.diseaseChance}% ({coupleRisk.diseasePingPong?.title || 'รุนแรง'})
                  </div>
                </>
              ) : coupleRisk.carrierChance > 0 ? (
                <>
                  <PingPongTagBadge tag={coupleRisk.carrierPingPong} size="sm" />
                  <div className="text-[11px] font-bold text-amber-700 mt-1.5">
                    เสี่ยงพาหะ {coupleRisk.carrierChance}% ({coupleRisk.carrierPingPong?.title || 'พาหะ'})
                  </div>
                </>
              ) : (
                <>
                  <PingPongTagBadge tag={coupleRisk.normalPingPong} size="sm" />
                  <div className="text-[11px] font-bold text-emerald-700 mt-1.5">
                    ปกติ 100% ({coupleRisk.normalPingPong?.title || 'ปกติ'})
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Target Disease & Probability Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-semibold text-slate-500">ผลการวิเคราะห์โรคเป้าหมาย:</span>
            <div className="text-base font-bold text-slate-900 mt-0.5">{coupleRisk.targetDisease}</div>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">{coupleRisk.explanation}</p>
          </div>

          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-center flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-rose-700 uppercase">โอกาสเป็นโรค (Disease)</span>
              <div className="text-2xl sm:text-3xl font-extrabold text-rose-600 mt-1">
                {coupleRisk.diseaseChance}%
              </div>
              <span className="text-[11px] text-rose-800 font-medium">ในแต่ละการตั้งครรภ์</span>
            </div>
            <div className="mt-3 pt-2 border-t border-rose-200/60 flex flex-col items-center">
              {coupleRisk.diseaseChance > 0 && coupleRisk.diseasePingPong ? (
                <div className={`px-2 py-0.5 rounded-full border text-[10px] font-bold flex items-center gap-1.5 shadow-2xs ${coupleRisk.diseasePingPong.badgeBg} ${coupleRisk.diseasePingPong.borderColor}`}>
                  <span className={`w-2 h-2 rounded-full ${coupleRisk.diseasePingPong.dotColor}`} />
                  <span>{coupleRisk.diseasePingPong.badgeText}</span>
                </div>
              ) : (
                <div className="px-2 py-0.5 rounded-full border border-slate-200 bg-white/80 text-[10px] text-slate-500 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                  <span>0% ไม่มีโอกาสเป็นโรครุนแรง</span>
                </div>
              )}
            </div>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-center flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-amber-700 uppercase">โอกาสเป็นพาหะ (Carrier)</span>
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-600 mt-1">
                {coupleRisk.carrierChance}%
              </div>
              <span className="text-[11px] text-amber-800 font-medium">ถ่ายทอดยีนสู่รุ่นต่อไป</span>
            </div>
            <div className="mt-3 pt-2 border-t border-amber-200/60 flex flex-col items-center">
              {coupleRisk.carrierChance > 0 && coupleRisk.carrierPingPong ? (
                <div className={`px-2 py-0.5 rounded-full border text-[10px] font-bold flex items-center gap-1.5 shadow-2xs ${coupleRisk.carrierPingPong.badgeBg} ${coupleRisk.carrierPingPong.borderColor}`}>
                  <span className={`w-2 h-2 rounded-full ${coupleRisk.carrierPingPong.dotColor}`} />
                  <span>{coupleRisk.carrierPingPong.badgeText}</span>
                </div>
              ) : (
                <div className="px-2 py-0.5 rounded-full border border-slate-200 bg-white/80 text-[10px] text-slate-500 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                  <span>0% ไม่มียีนพาหะ</span>
                </div>
              )}
            </div>
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-emerald-700 uppercase">โอกาสปกติ (Normal)</span>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 mt-1">
                {coupleRisk.normalChance}%
              </div>
              <span className="text-[11px] text-emerald-800 font-medium">ไม่มียีนผิดปกติ</span>
            </div>
            <div className="mt-3 pt-2 border-t border-emerald-200/60 flex flex-col items-center">
              {coupleRisk.normalChance > 0 && coupleRisk.normalPingPong ? (
                <div className={`px-2 py-0.5 rounded-full border text-[10px] font-bold flex items-center gap-1.5 shadow-2xs ${coupleRisk.normalPingPong.badgeBg} ${coupleRisk.normalPingPong.borderColor}`}>
                  <span className={`w-2 h-2 rounded-full ${coupleRisk.normalPingPong.dotColor}`} />
                  <span>{coupleRisk.normalPingPong.badgeText}</span>
                </div>
              ) : (
                <div className="px-2 py-0.5 rounded-full border border-slate-200 bg-white/80 text-[10px] text-slate-500 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                  <span>0% (รับยีนผิดปกติ 100%)</span>
                </div>
              )}
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl flex flex-col justify-center text-center">
            <span className="text-[11px] font-bold text-blue-700 uppercase">กฎพันธุศาสตร์</span>
            <div className="text-xs font-semibold text-blue-900 mt-1">
              Autosomal Recessive
            </div>
            <span className="text-[10px] text-slate-500 mt-1">อัตราส่วน 1:2:1 (กรณีพาหะทั้งคู่)</span>
          </div>
        </div>

        {/* Punnett Square Visualization */}
        <div className="border border-slate-200 rounded-xl p-5 bg-gradient-to-b from-white to-slate-50">
          <div className="flex items-center gap-2 font-bold text-slate-900 text-sm mb-4">
            <Layers className="w-4 h-4 text-pink-600" />
            <span>ตารางพุนเน็ตต์จำลองการรวมตัวของเซลล์สืบพันธุ์และการติดแท็กสีปิงปอง (Punnett Square)</span>
          </div>

          <div className="max-w-lg mx-auto bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-xs">
            <div className="grid grid-cols-3 gap-2 text-center font-bold">
              <div className="p-2 bg-slate-100 rounded text-slate-500 flex items-center justify-center text-[11px]">
                เซลล์สืบพันธุ์
              </div>
              <div className="p-2 bg-sky-100 text-sky-900 rounded">
                สามี ({coupleRisk.punnettSquare.fatherGametes[0]})
              </div>
              <div className="p-2 bg-sky-100 text-sky-900 rounded">
                สามี ({coupleRisk.punnettSquare.fatherGametes[1]})
              </div>

              <div className="p-2 bg-pink-100 text-pink-900 rounded flex items-center justify-center">
                ภรรยา ({coupleRisk.punnettSquare.motherGametes[0]})
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between items-center text-center hover:bg-slate-100/80 transition-colors">
                <div className="font-mono text-sm text-indigo-900 font-bold">
                  {coupleRisk.punnettSquare.combinations[0]}
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5 font-medium leading-tight">
                  {coupleRisk.punnettSquare.phenotypes[0]}
                </div>
                {coupleRisk.punnettSquare.phenotypePingPongs?.[0] && (
                  <span className={`mt-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${coupleRisk.punnettSquare.phenotypePingPongs[0].badgeBg} ${coupleRisk.punnettSquare.phenotypePingPongs[0].borderColor}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${coupleRisk.punnettSquare.phenotypePingPongs[0].dotColor}`} />
                    {coupleRisk.punnettSquare.phenotypePingPongs[0].badgeText}
                  </span>
                )}
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between items-center text-center hover:bg-slate-100/80 transition-colors">
                <div className="font-mono text-sm text-indigo-900 font-bold">
                  {coupleRisk.punnettSquare.combinations[1]}
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5 font-medium leading-tight">
                  {coupleRisk.punnettSquare.phenotypes[1]}
                </div>
                {coupleRisk.punnettSquare.phenotypePingPongs?.[1] && (
                  <span className={`mt-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${coupleRisk.punnettSquare.phenotypePingPongs[1].badgeBg} ${coupleRisk.punnettSquare.phenotypePingPongs[1].borderColor}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${coupleRisk.punnettSquare.phenotypePingPongs[1].dotColor}`} />
                    {coupleRisk.punnettSquare.phenotypePingPongs[1].badgeText}
                  </span>
                )}
              </div>

              <div className="p-2 bg-pink-100 text-pink-900 rounded flex items-center justify-center">
                ภรรยา ({coupleRisk.punnettSquare.motherGametes[1]})
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between items-center text-center hover:bg-slate-100/80 transition-colors">
                <div className="font-mono text-sm text-indigo-900 font-bold">
                  {coupleRisk.punnettSquare.combinations[2]}
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5 font-medium leading-tight">
                  {coupleRisk.punnettSquare.phenotypes[2]}
                </div>
                {coupleRisk.punnettSquare.phenotypePingPongs?.[2] && (
                  <span className={`mt-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${coupleRisk.punnettSquare.phenotypePingPongs[2].badgeBg} ${coupleRisk.punnettSquare.phenotypePingPongs[2].borderColor}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${coupleRisk.punnettSquare.phenotypePingPongs[2].dotColor}`} />
                    {coupleRisk.punnettSquare.phenotypePingPongs[2].badgeText}
                  </span>
                )}
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between items-center text-center hover:bg-slate-100/80 transition-colors">
                <div className="font-mono text-sm text-indigo-900 font-bold">
                  {coupleRisk.punnettSquare.combinations[3]}
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5 font-medium leading-tight">
                  {coupleRisk.punnettSquare.phenotypes[3]}
                </div>
                {coupleRisk.punnettSquare.phenotypePingPongs?.[3] && (
                  <span className={`mt-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${coupleRisk.punnettSquare.phenotypePingPongs[3].badgeBg} ${coupleRisk.punnettSquare.phenotypePingPongs[3].borderColor}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${coupleRisk.punnettSquare.phenotypePingPongs[3].dotColor}`} />
                    {coupleRisk.punnettSquare.phenotypePingPongs[3].badgeText}
                  </span>
                )}
              </div>
            </div>

            {/* Quick 6-Color Ping Pong Legend Bar */}
            <div className="mt-4 pt-3 border-t border-slate-200 text-[11px] text-slate-600">
              <div className="font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <span>🏓 รหัสสีปิงปองจราจร 6 สี ในการแปลผลความเสี่ยง:</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[10px]">
                <div className="flex items-center gap-1.5 p-1 rounded bg-slate-100 text-slate-700">
                  <span className="w-2 h-2 rounded-full bg-slate-300 border border-slate-400" />
                  <span><strong>สีขาว:</strong> ปกติ/ไม่เป็นโรค</span>
                </div>
                <div className="flex items-center gap-1.5 p-1 rounded bg-emerald-50 text-emerald-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span><strong>สีเขียว:</strong> สงสัย/เม็ดเลือดเล็ก</span>
                </div>
                <div className="flex items-center gap-1.5 p-1 rounded bg-amber-50 text-amber-800">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span><strong>สีเหลือง:</strong> เสี่ยง/พาหะยีนแฝง</span>
                </div>
                <div className="flex items-center gap-1.5 p-1 rounded bg-orange-50 text-orange-800">
                  <span className="w-2 h-2 rounded-full bg-orange-500" />
                  <span><strong>สีส้ม:</strong> รุนแรงน้อย (Hb H, EE)</span>
                </div>
                <div className="flex items-center gap-1.5 p-1 rounded bg-rose-50 text-rose-800">
                  <span className="w-2 h-2 rounded-full bg-rose-600" />
                  <span><strong>สีแดง:</strong> รุนแรงมาก (Major/E-thal)</span>
                </div>
                <div className="flex items-center gap-1.5 p-1 rounded bg-slate-900 text-white">
                  <span className="w-2 h-2 rounded-full bg-slate-400" />
                  <span><strong>สีดำ:</strong> รุนแรงสูงสุด (Hydrops)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recommended Clinical Steps */}
        <div className="bg-sky-50/70 border border-sky-200 rounded-xl p-4 text-xs">
          <div className="font-bold text-sky-950 mb-2 flex items-center gap-1.5 text-sm">
            <CheckCircle2 className="w-4 h-4 text-sky-600" />
            <span>แนวทางการจัดการทางการพยาบาลและขั้นตอนตรวจต่อไป (Next Steps)</span>
          </div>
          <ul className="space-y-1.5 text-slate-700">
            {coupleRisk.recommendedNextSteps.map((step, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-sky-200 text-sky-800 font-bold flex items-center justify-center text-[10px] mt-0.5 flex-shrink-0">
                  {idx + 1}
                </span>
                <span className="leading-relaxed">{step}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      {/* End of Left Column: Inputs & Risk Assessment */}
      </div>

      {/* Pinned Persistent Sidebar (Side-by-Side Mode on Desktop) */}
      {isGuidePinned && isGuideOpen && (
        <LabReferenceGuide
          isOpen={isGuideOpen}
          onClose={() => setIsGuideOpen(false)}
          isPinned={isGuidePinned}
          onTogglePin={handleTogglePin}
          onApplyPresetLab={handleApplyPresetLab}
        />
      )}
    </div>

    {/* Slide-out Drawer / Overlay Mode (When Not Pinned) */}
    {!isGuidePinned && isGuideOpen && (
      <>
        <div
          id="lab-guide-backdrop"
          onClick={() => setIsGuideOpen(false)}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 transition-opacity"
          aria-hidden="true"
        />
        <LabReferenceGuide
          isOpen={isGuideOpen}
          onClose={() => setIsGuideOpen(false)}
          isPinned={isGuidePinned}
          onTogglePin={handleTogglePin}
          onApplyPresetLab={handleApplyPresetLab}
        />
      </>
    )}

    {/* Floating Quick Reference Button (Visible when Guide is Closed) */}
    {!isGuideOpen && (
      <button
        id="floating-open-lab-guide"
        onClick={() => setIsGuideOpen(true)}
        className="fixed bottom-6 right-6 z-30 shadow-xl bg-gradient-to-r from-pink-600 via-rose-600 to-indigo-600 hover:from-pink-700 hover:to-indigo-700 text-white px-4 py-3 rounded-full flex items-center gap-2.5 text-xs font-bold transition transform hover:scale-105 active:scale-95 border border-white/20 animate-bounce sm:animate-none"
        title="เปิดคู่มือค่าอ้างอิงโลหิตวิทยา (Quick Reference Guide)"
      >
        <BookOpen className="w-4 h-4" />
        <span>คู่มือค่าอ้างอิงเลือด</span>
        <span className="bg-white/20 px-1.5 py-0.5 rounded text-[10px] font-mono">
          MCV &bull; MCH &bull; Hb
        </span>
      </button>
    )}
    </div>
  );
};
