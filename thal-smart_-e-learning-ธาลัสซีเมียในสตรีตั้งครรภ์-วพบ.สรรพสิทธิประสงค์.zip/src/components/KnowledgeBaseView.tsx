import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Bookmark, 
  ChevronRight, 
  MapPin, 
  Dna, 
  HeartHandshake, 
  Baby, 
  ShieldCheck, 
  HelpCircle,
  ExternalLink,
  Layers,
  Sparkles,
  Activity
} from 'lucide-react';
import { KNOWLEDGE_SECTIONS, KnowledgeSection } from '../data/knowledgeBase';
import { QuickCheckSection } from './QuickCheckSection';
import { PingPongTrafficInteractive } from './PingPongTrafficInteractive';
import { QUICK_CHECKS_DATA } from '../data/quickChecks';
import { QuickCheckResult } from '../types';

interface KnowledgeBaseViewProps {
  onNavigateToModule?: (moduleId: string) => void;
  onCompleteQuickCheck?: (result: QuickCheckResult) => void;
}

export const KnowledgeBaseView: React.FC<KnowledgeBaseViewProps> = ({
  onNavigateToModule,
  onCompleteQuickCheck,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [activeSectionId, setActiveSectionId] = useState<string>('epidemiology');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'MapPin': return <MapPin className="w-4 h-4 text-pink-500" />;
      case 'Dna': return <Dna className="w-4 h-4 text-sky-500" />;
      case 'HeartHandshake': return <HeartHandshake className="w-4 h-4 text-pink-600" />;
      case 'Baby': return <Baby className="w-4 h-4 text-blue-500" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4 text-indigo-600" />;
      case 'Activity': return <Activity className="w-4 h-4 text-emerald-600" />;
      default: return <BookOpen className="w-4 h-4 text-slate-500" />;
    }
  };

  const filteredSections = KNOWLEDGE_SECTIONS.filter((sec) => {
    const matchesFilter = 
      selectedFilter === 'all' || 
      (selectedFilter === 'foundation' && sec.gate === 'foundation') ||
      sec.gate === selectedFilter;

    const matchesSearch = 
      sec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.keyPoints.some((p) => p.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesFilter && matchesSearch;
  });

  const currentSection = KNOWLEDGE_SECTIONS.find((s) => s.id === activeSectionId) || KNOWLEDGE_SECTIONS[0];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 text-xs font-semibold mb-2">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Evidence-Based Clinical Knowledge Base</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              เนื้อหาอ้างอิงและคู่มือการเรียนรู้ที่ฝังในระบบ
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              รวบรวมองค์ความรู้จากมาตรฐานการคัดกรองเฝ้าระวัง ควบคุม ป้องกันโรคเลือดจางธาลัสซีเมียด้วยปิงปองจราจรชีวิต 6 สี มูลนิธิโรคโลหิตจางธาลัสซีเมียแห่งประเทศไทย และแนวทางการคัดกรองของกระทรวงสาธารณสุข สำหรับนักศึกษาพยาบาล วพบ.สรรพสิทธิประสงค์
            </p>
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="ค้นหา เช่น Hb Bart's, MCV, CVS, PPH, อีสาน, Folic acid..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:bg-white transition"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none text-xs">
          {[
            { id: 'all', label: 'ทั้งหมด' },
            { id: 'foundation', label: 'พื้นฐาน & ระบาดวิทยา' },
            { id: 'gate1_match', label: 'ประตู 1: เลือกคู่' },
            { id: 'gate2_pregnancy', label: 'ประตู 2: เลือกครรภ์' },
            { id: 'gate3_birth', label: 'ประตู 3: เลือกคลอด' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                selectedFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2-Column Layout: Topic List and Content Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Topic Sidebar */}
        <div className="lg:col-span-4 space-y-2">
          {filteredSections.map((sec) => {
            const isActive = sec.id === activeSectionId;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSectionId(sec.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-pink-50 to-sky-50 border-pink-300 shadow-sm ring-1 ring-pink-400'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-white shadow-xs border border-slate-200 mt-0.5">
                    {getIcon(sec.iconName)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className={`text-xs font-bold truncate ${isActive ? 'text-pink-900' : 'text-slate-800'}`}>
                      {sec.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {sec.subtitle}
                    </p>
                  </div>
                  <ChevronRight className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-pink-600' : 'text-slate-300'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Article Viewer */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
          <div className="border-b border-slate-200 pb-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-pink-100 text-pink-800">
                {currentSection.gate === 'foundation' ? 'เนื้อหาพื้นฐาน' : currentSection.gate === 'gate1_match' ? 'ประตู 1: เลือกคู่' : currentSection.gate === 'gate2_pregnancy' ? 'ประตู 2: เลือกครรภ์' : 'ประตู 3: เลือกคลอด'}
              </span>
            </div>
            <h3 className="text-xl font-bold text-slate-900">{currentSection.title}</h3>
            <p className="text-xs text-slate-500 mt-1">{currentSection.subtitle}</p>
          </div>

          {/* Core Summary Card */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
            <span className="font-bold text-slate-900 block mb-1">สรุปสาระสำคัญ (Executive Summary):</span>
            <p>{currentSection.summary}</p>
          </div>

          {/* Interactive Ping-Pong Traffic Lights Simulator & Visual Table */}
          {currentSection.id === 'pingpong_traffic_lights' && (
            <div className="pt-2">
              <PingPongTrafficInteractive />
            </div>
          )}

          {/* HTML / Custom Visual Content */}
          <div 
            className="text-xs text-slate-700 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: currentSection.contentHtml }} 
          />

          {/* Table Data if exists */}
          {currentSection.tableData && (
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-800 uppercase font-bold">
                  <tr>
                    {currentSection.tableData.headers.map((h, i) => (
                      <th key={i} className="p-2.5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {currentSection.tableData.rows.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50">
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="p-2.5 font-medium text-slate-700">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Key Checklist Points */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-pink-600" />
              <span>ประเด็นหลักที่ต้องจดจำสำหรับการสอบและการปฏิบัติงาน (Key Learning Points)</span>
            </h4>
            <div className="space-y-1.5">
              {currentSection.keyPoints.map((pt, idx) => (
                <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-slate-50 text-xs text-slate-700">
                  <span className="w-4 h-4 rounded-full bg-pink-100 text-pink-700 font-bold flex items-center justify-center flex-shrink-0 text-[10px] mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{pt}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Clinical Relevance Box */}
          <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-950">
            <span className="font-bold flex items-center gap-1 mb-1 text-blue-900">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              ความสำคัญต่อการตัดสินใจทางคลินิกของนักศึกษาพยาบาล:
            </span>
            <p className="text-[11px] text-blue-800 leading-relaxed">
              {currentSection.clinicalRelevance}
            </p>
          </div>

          {/* Quick Check Section to Reinforce Knowledge Before Final Exam */}
          <div className="pt-3">
            <QuickCheckSection
              moduleId={
                currentSection.id in QUICK_CHECKS_DATA
                  ? currentSection.id
                  : currentSection.gate && currentSection.gate !== 'foundation'
                  ? currentSection.gate
                  : 'epidemiology'
              }
              onNavigateToModule={onNavigateToModule}
              onComplete={onCompleteQuickCheck}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
