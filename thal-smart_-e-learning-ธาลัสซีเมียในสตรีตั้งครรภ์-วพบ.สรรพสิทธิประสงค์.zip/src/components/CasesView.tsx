import React, { useState } from 'react';
import { 
  Users, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  HelpCircle, 
  ChevronRight, 
  ClipboardList, 
  Heart, 
  Sparkles,
  RotateCcw,
  Check,
  Award
} from 'lucide-react';
import { CLINICAL_CASES } from '../data/cases';
import { CaseStudy, GateType, QuickCheckResult } from '../types';
import { QuickCheckSection } from './QuickCheckSection';

interface CasesViewProps {
  completedCases: Record<string, { completed: boolean; score: number }>;
  onCompleteStage: (caseId: string, stageIdx: number, isCorrect: boolean, points: number) => void;
  onResetCase: (caseId: string) => void;
  onNavigateToModule?: (moduleId: string) => void;
  onCompleteQuickCheck?: (result: QuickCheckResult) => void;
}

export const CasesView: React.FC<CasesViewProps> = ({
  completedCases,
  onCompleteStage,
  onResetCase,
  onNavigateToModule,
  onCompleteQuickCheck,
}) => {
  const [selectedCaseId, setSelectedCaseId] = useState<string>('case-1');
  const [activeGateFilter, setActiveGateFilter] = useState<string>('all');
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, Record<number, string>>>({});

  const activeCase = CLINICAL_CASES.find((c) => c.id === selectedCaseId) || CLINICAL_CASES[0];

  const handleSelectOption = (stageIdx: number, optionId: string, isCorrect: boolean, points: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [activeCase.id]: {
        ...(prev[activeCase.id] || {}),
        [stageIdx]: optionId,
      },
    }));
    onCompleteStage(activeCase.id, stageIdx, isCorrect, points);
  };

  const filteredCases = CLINICAL_CASES.filter((c) => {
    if (activeGateFilter === 'all') return true;
    return c.gate === activeGateFilter;
  });

  const completedCount = Object.values(completedCases).filter((c) => c.completed).length;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold mb-2">
              <Users className="w-3.5 h-3.5" />
              <span>Virtual Patient Simulation</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              คลังกรณีศึกษา 8 เคสเสมือนจริง (Interactive Clinical Decision Cases)
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              ฝึกทักษะการตัดสินใจทางคลินิกแบบโต้ตอบผ่านกรณีศึกษาผู้ป่วยจริง 8 สถานการณ์ ครอบคลุมการแปลผลเลือด การคัดกรองคู่สมรส การเลือกหัตถการ PND การแจ้งข่าวร้าย และการพยาบาลระยะคลอด
            </p>
          </div>

          <div className="bg-slate-950/60 px-4 py-3 rounded-xl border border-slate-800 text-center min-w-[150px]">
            <span className="text-[11px] font-semibold text-slate-400 block">ความก้าวหน้าของคุณ</span>
            <div className="text-2xl font-bold text-pink-400 mt-0.5">
              {completedCount} / 8 เคส
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-gradient-to-r from-pink-500 to-sky-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${(completedCount / 8) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
        {[
          { id: 'all', label: 'ทั้งหมด (8 เคส)' },
          { id: 'gate1_match', label: 'ประตู 1: เลือกคู่ (Screening & Carrier)' },
          { id: 'gate2_pregnancy', label: 'ประตู 2: เลือกครรภ์ (PND & Counseling)' },
          { id: 'gate3_birth', label: 'ประตู 3: เลือกคลอด (High-risk & Delivery)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveGateFilter(tab.id)}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
              activeGateFilter === tab.id
                ? 'bg-gradient-to-r from-pink-600 to-sky-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 2-Column Grid: Case Navigator + Case Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Case List Sidebar */}
        <div className="lg:col-span-4 space-y-2.5">
          {filteredCases.map((c) => {
            const isSelected = c.id === activeCase.id;
            const isCompleted = completedCases[c.id]?.completed;
            const score = completedCases[c.id]?.score || 0;

            return (
              <button
                key={c.id}
                onClick={() => setSelectedCaseId(c.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all relative overflow-hidden ${
                  isSelected
                    ? 'bg-gradient-to-r from-pink-50 to-sky-50 border-pink-400 shadow-sm ring-2 ring-pink-300/60'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900 text-white">
                    เคสที่ {c.caseNumber}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      c.gate === 'gate1_match'
                        ? 'bg-pink-100 text-pink-700'
                        : c.gate === 'gate2_pregnancy'
                        ? 'bg-sky-100 text-sky-700'
                        : 'bg-indigo-100 text-indigo-700'
                    }`}
                  >
                    {c.gate === 'gate1_match' ? 'เลือกคู่' : c.gate === 'gate2_pregnancy' ? 'เลือกครรภ์' : 'เลือกคลอด'}
                  </span>
                </div>

                <h4 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1">{c.title}</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {c.patientProfile.name} &bull; {c.patientProfile.gravida} &bull; GA {c.patientProfile.ga}
                </p>

                <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-[11px]">
                  {isCompleted ? (
                    <span className="text-emerald-600 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> ผ่านแล้ว ({score} คะแนน)
                    </span>
                  ) : (
                    <span className="text-slate-400">ยังไม่สำเร็จ</span>
                  )}
                  <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-pink-600' : 'text-slate-300'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Case Interactive Workspace */}
        <div className="lg:col-span-8 space-y-5">
          {/* Patient Card Header */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
              <div>
                <span className="text-xs font-semibold text-pink-600">
                  กรณีศึกษาที่ {activeCase.caseNumber} &bull;{' '}
                  {activeCase.gate === 'gate1_match' ? 'ประตู 1: เลือกคู่' : activeCase.gate === 'gate2_pregnancy' ? 'ประตู 2: เลือกครรภ์' : 'ประตู 3: เลือกคลอด'}
                </span>
                <h3 className="text-lg font-bold text-slate-900">{activeCase.title}</h3>
              </div>
              <button
                onClick={() => onResetCase(activeCase.id)}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition self-start sm:self-auto"
                title="เริ่มทำเคสนี้ใหม่"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>รีเซ็ตเคสนี้</span>
              </button>
            </div>

            {/* Patient Demographics & Vitals */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px]">ชื่อผู้ป่วย</span>
                <span className="font-bold text-slate-800">{activeCase.patientProfile.name}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">อายุ / ครรภ์ที่</span>
                <span className="font-bold text-slate-800">
                  {activeCase.patientProfile.age} ปี / {activeCase.patientProfile.gravida}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">อายุครรภ์ (GA)</span>
                <span className="font-bold text-slate-800">{activeCase.patientProfile.ga}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">สัญญาณชีพ (V/S)</span>
                <span className="font-bold text-slate-800">
                  BP {activeCase.patientProfile.vitals.bp}, PR {activeCase.patientProfile.vitals.pr}
                </span>
              </div>
              <div className="col-span-2 sm:col-span-4 mt-1 pt-1 border-t border-slate-200 text-slate-600">
                <strong>ประวัติสำคัญ:</strong> {activeCase.patientProfile.history}
              </div>
            </div>

            {/* Laboratory Slips: Mother & Partner */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {/* Mother Lab Slip */}
              <div className="p-3 bg-pink-50/70 border border-pink-200 rounded-xl space-y-1.5">
                <div className="font-bold text-pink-950 flex items-center justify-between border-b border-pink-200 pb-1">
                  <span>ใบรายงานผลแล็บ: ภรรยา (สตรีตั้งครรภ์)</span>
                  <span className="text-[10px] text-pink-700 bg-pink-100 px-1.5 py-0.5 rounded">
                    Maternal Lab
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[11px] text-slate-700">
                  <div>Hb: <span className="font-bold">{activeCase.maternalLab.cbc.hb}</span></div>
                  <div>Hct: <span className="font-bold">{activeCase.maternalLab.cbc.hct}</span></div>
                  <div>MCV: <span className="font-bold text-pink-700">{activeCase.maternalLab.cbc.mcv}</span></div>
                  <div>MCH: <span className="font-bold text-pink-700">{activeCase.maternalLab.cbc.mch}</span></div>
                  <div>DCIP: <span className="font-bold">{activeCase.maternalLab.screening.dcip}</span></div>
                  <div>OF test: <span className="font-bold">{activeCase.maternalLab.screening.of || '-'}</span></div>
                </div>
                {activeCase.maternalLab.hbTyping && (
                  <div className="text-[11px] bg-white p-1.5 rounded border border-pink-200 font-semibold text-pink-900 mt-1">
                    Hb Typing: {activeCase.maternalLab.hbTyping}
                  </div>
                )}
                {activeCase.maternalLab.pcrAlpha && (
                  <div className="text-[11px] bg-white p-1.5 rounded border border-pink-200 font-semibold text-rose-700">
                    PCR α-thal 1: {activeCase.maternalLab.pcrAlpha}
                  </div>
                )}
              </div>

              {/* Husband Lab Slip */}
              <div className="p-3 bg-sky-50/70 border border-sky-200 rounded-xl space-y-1.5">
                <div className="font-bold text-sky-950 flex items-center justify-between border-b border-sky-200 pb-1">
                  <span>ใบรายงานผลแล็บ: สามี (คู่สมรส)</span>
                  <span className="text-[10px] text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded">
                    Partner Lab
                  </span>
                </div>
                {activeCase.partnerLab ? (
                  <>
                    <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[11px] text-slate-700">
                      <div>Hb: <span className="font-bold">{activeCase.partnerLab.cbc?.hb || '-'}</span></div>
                      <div>Hct: <span className="font-bold">{activeCase.partnerLab.cbc?.hct || '-'}</span></div>
                      <div>MCV: <span className="font-bold text-sky-700">{activeCase.partnerLab.cbc?.mcv || '-'}</span></div>
                      <div>MCH: <span className="font-bold text-sky-700">{activeCase.partnerLab.cbc?.mch || '-'}</span></div>
                      <div>DCIP: <span className="font-bold">{activeCase.partnerLab.screening?.dcip || '-'}</span></div>
                    </div>
                    {activeCase.partnerLab.hbTyping && (
                      <div className="text-[11px] bg-white p-1.5 rounded border border-sky-200 font-semibold text-sky-900 mt-1">
                        Hb Typing: {activeCase.partnerLab.hbTyping}
                      </div>
                    )}
                    {activeCase.partnerLab.pcrAlpha && (
                      <div className="text-[11px] bg-white p-1.5 rounded border border-sky-200 font-semibold text-rose-700">
                        PCR α-thal 1: {activeCase.partnerLab.pcrAlpha}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-slate-400 italic text-[11px] p-4 text-center">
                    ยังไม่มีผลตรวจของคู่สมรสในประวัติ (สามียังไม่ได้มารับการตรวจ)
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Interactive Decision Stages */}
          <div className="space-y-4">
            {activeCase.stages.map((stg, stgIdx) => {
              const selectedOptId = selectedAnswers[activeCase.id]?.[stgIdx];
              const selectedOpt = stg.options.find((o) => o.id === selectedOptId);

              return (
                <div
                  key={stgIdx}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-xs">
                      {stg.stageNumber}
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm">{stg.stageTitle}</h4>
                  </div>

                  <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed">
                    <strong>สถานการณ์:</strong> {stg.scenarioText}
                  </div>

                  <div className="text-xs font-bold text-slate-900 leading-relaxed">
                    คำถาม: {stg.question}
                  </div>

                  {/* Options */}
                  <div className="space-y-2">
                    {stg.options.map((opt) => {
                      const isChosen = selectedOptId === opt.id;
                      const hasChosen = !!selectedOptId;

                      let btnStyle = 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700';
                      if (hasChosen) {
                        if (opt.isCorrect) {
                          btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-950 ring-1 ring-emerald-500 font-medium';
                        } else if (isChosen && !opt.isCorrect) {
                          btnStyle = 'border-rose-400 bg-rose-50 text-rose-950 font-medium';
                        } else {
                          btnStyle = 'border-slate-200 opacity-50 text-slate-400';
                        }
                      }

                      return (
                        <button
                          key={opt.id}
                          disabled={hasChosen}
                          onClick={() => handleSelectOption(stgIdx, opt.id, opt.isCorrect, opt.clinicalPoints)}
                          className={`w-full text-left p-3 rounded-xl border transition-all text-xs flex items-start gap-2.5 ${btnStyle}`}
                        >
                          <span className="w-5 h-5 rounded-full border border-current font-bold flex items-center justify-center flex-shrink-0 text-[10px] mt-0.5">
                            {opt.id.slice(-1).toUpperCase()}
                          </span>
                          <span className="flex-1 leading-relaxed">{opt.text}</span>
                          {hasChosen && opt.isCorrect && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Feedback Box if Answered */}
                  {selectedOpt && (
                    <div
                      className={`p-3.5 rounded-xl text-xs leading-relaxed ${
                        selectedOpt.isCorrect
                          ? 'bg-emerald-50 border border-emerald-200 text-emerald-950'
                          : 'bg-rose-50 border border-rose-200 text-rose-950'
                      }`}
                    >
                      <div className="font-bold flex items-center gap-1.5 mb-1">
                        {selectedOpt.isCorrect ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>การตัดสินใจถูกต้อง! (+{selectedOpt.clinicalPoints} คะแนน)</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-4 h-4 text-rose-600" />
                            <span>การตัดสินใจยังไม่เหมาะสม (0 คะแนน)</span>
                          </>
                        )}
                      </div>
                      <p className="text-[11px] mt-1">{selectedOpt.rationale}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Summary Learning Points if all stages answered */}
          {selectedAnswers[activeCase.id] &&
            Object.keys(selectedAnswers[activeCase.id]).length >= activeCase.stages.length && (
              <div className="bg-gradient-to-r from-pink-50 to-sky-50 border border-pink-200 rounded-2xl p-5 space-y-3 shadow-sm">
                <div className="flex items-center gap-2 text-pink-900 font-bold text-sm">
                  <Award className="w-4 h-4 text-pink-600" />
                  <span>สรุปข้อคิดทางคลินิกสำหรับกรณีศึกษานี้ (Clinical Learning Pearls)</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {activeCase.summaryLearningPoints.map((pt, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-pink-600 flex-shrink-0 mt-0.5" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>

                {/* Quick Check to Reinforce Knowledge Before Final Exam */}
                <div className="pt-3 border-t border-pink-200/80">
                  <QuickCheckSection
                    moduleId={activeCase.gate}
                    onNavigateToModule={onNavigateToModule}
                    onComplete={onCompleteQuickCheck}
                  />
                </div>
              </div>
            )}
        </div>
      </div>
    </div>
  );
};
