import React, { useState } from 'react';
import { 
  BookOpen, 
  X, 
  Pin, 
  PinOff, 
  Search, 
  Check, 
  AlertTriangle, 
  Info, 
  ArrowRight, 
  Dna, 
  TestTube, 
  Droplet, 
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Copy,
  Layers,
  ShieldAlert,
  Users,
  FileText,
  CheckCircle2
} from 'lucide-react';
import { LabResult } from '../types';

interface LabReferenceGuideProps {
  isOpen: boolean;
  onClose: () => void;
  isPinned: boolean;
  onTogglePin: () => void;
  onApplyPresetLab?: (target: 'wife' | 'husband', values: Partial<LabResult>) => void;
}

export const LabReferenceGuide: React.FC<LabReferenceGuideProps> = ({
  isOpen,
  onClose,
  isPinned,
  onTogglePin,
  onApplyPresetLab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<string | null>('hb_matrix');
  const [activeSlideTab, setActiveSlideTab] = useState<string>('all_slides');
  const [openSlideAccordions, setOpenSlideAccordions] = useState<Record<string, boolean>>({
    slide39: true,
    slide40: true,
    slide41: true,
    slide42: true,
    slide43: true,
    slide44: true,
    slide45: true,
  });

  const toggleSlideAccordion = (slideKey: string) => {
    setOpenSlideAccordions((prev) => ({
      ...prev,
      [slideKey]: !prev[slideKey],
    }));
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const categories = [
    { id: 'all', label: 'ทั้งหมด' },
    { id: 'slides39_45', label: '⭐ สไลด์ 39-45 (คู่มือการแปลผล & Family Study)' },
    { id: 'indices', label: 'MCV / MCH (ดัชนีเม็ดเลือด)' },
    { id: 'typing', label: 'Hb Typing & Peak %' },
    { id: 'screen', label: 'OF / DCIP (คัดกรอง)' },
    { id: 'dna', label: 'PCR α-thal 1 (ตรวจยีน)' },
    { id: 'couples', label: '3 โรครุนแรง & คู่เสี่ยง' },
  ];

  if (!isOpen) return null;

  return (
    <aside
      id="lab-reference-guide-panel"
      aria-label="Quick Reference Guide for Lab Values"
      className={`flex flex-col bg-white border-l border-slate-200 transition-all duration-300 ${
        isPinned
          ? 'w-full xl:w-[420px] 2xl:w-[460px] flex-shrink-0 h-[calc(100vh-140px)] sticky top-20 shadow-lg rounded-2xl border'
          : 'fixed inset-y-0 right-0 z-50 w-full sm:w-[450px] md:w-[480px] shadow-2xl'
      }`}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white p-4 flex-shrink-0 border-b border-indigo-800">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-400/30 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                คู่มือค่าอ้างอิงโลหิตวิทยา
                <span className="text-[10px] bg-pink-500/30 text-pink-200 border border-pink-500/40 px-1.5 py-0.5 rounded font-medium">
                  MOPH Guideline
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                Blood Count, Hb Typing & Interpretation Rules
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              id="btn-toggle-pin-guide"
              onClick={onTogglePin}
              title={isPinned ? 'เปลี่ยนเป็นลิ้นชักลอย (Floating Drawer)' : 'ปักหมุดแถบข้างถาวร (Pin to Sidebar)'}
              className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition ${
                isPinned
                  ? 'bg-pink-500 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
              <span className="text-[10px] hidden sm:inline font-medium">
                {isPinned ? 'ถอนหมุด' : 'ปักหมุด'}
              </span>
            </button>

            <button
              id="btn-close-lab-guide"
              onClick={onClose}
              title="ปิดคู่มืออ้างอิง"
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search input */}
        <div className="relative mt-2">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
          <input
            id="search-lab-reference"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาเกณฑ์ เช่น MCV, A2A, EA, EE, 3.5%, DCIP..."
            className="w-full pl-8 pr-7 py-1.5 bg-slate-800/80 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2 text-slate-400 hover:text-white text-xs"
            >
              &times;
            </button>
          )}
        </div>

        {/* Filter categories */}
        <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-2.5 py-0.5 rounded-full whitespace-nowrap font-medium transition ${
                activeCategory === cat.id
                  ? 'bg-pink-500 text-white'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Scrollable Content Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs text-slate-700 bg-slate-50/50">
        
        {/* ========================================================================= */}
        {/* Section: In-Depth Clinical Interpretation Guide (Slides 39 - 45)          */}
        {/* ========================================================================= */}
        {(activeCategory === 'all' || activeCategory === 'slides39_45') && (
          <div className="bg-gradient-to-br from-indigo-50/80 via-white to-pink-50/80 rounded-2xl border-2 border-indigo-200/80 p-4 shadow-sm space-y-4">
            
            {/* Header Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                      คู่มือการแปลผล &amp; Family Study (สไลด์ 39 - 45)
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      ถอดรหัสเกณฑ์ตัดสินใจทางคลินิก 3 คู่เสี่ยงรุนแรง สมดุล Globin Chain &amp; การส่งตรวจยืนยัน
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 self-start sm:self-auto">
                <span className="text-[10px] bg-indigo-100 text-indigo-800 border border-indigo-200 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-indigo-600" />
                  หลักสูตร BCN
                </span>
                <button
                  onClick={() =>
                    handleCopy(
                      `[สรุปคู่มือการแปลผล สไลด์ 39-45]\n- สไลด์ 39: MCV<80, A2A (A2<3.5%) -> ต้องส่ง PCR for α-thal 1\n- สไลด์ 40: คู่เสี่ยง #1 Hb Bart's hydrops fetalis (ไม่มีชีวิตรอด)\n- สไลด์ 41: β-thal trait (A2>3.5%) -> ต้องส่ง PCR mutation (β0 vs β+)\n- สไลด์ 42: คู่เสี่ยง #2 β-thal disease (A2FA: β+ thal Hb F>=10% vs A2F: β0 thal Hb F>=20%)\n- สไลด์ 43: EA with E+A2<25% -> สงสัย α-thal ร่วมด้วย ต้องส่ง PCR\n- สไลด์ 44: คู่เสี่ยง #3 β-thal/Hb E (EFA: β+ vs EF: β0) ระวังผลรายงาน EE/EF (Hb F 5-20%)\n- สไลด์ 45: Family study สามี A2F (β0/β0) + ภรรยา EA (β/βE) -> เสี่ยงเป็นโรค 50%, พาหะ 50%, ปกติ 0%`,
                      'summary_39_45'
                    )
                  }
                  className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 text-[10px] font-semibold flex items-center gap-1 transition"
                  title="คัดลอกสรุปสไลด์ 39-45"
                >
                  {copiedKey === 'summary_39_45' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span className="text-emerald-600">คัดลอกแล้ว</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>คัดลอกสรุป</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick Slide Navigation Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-thin">
              <span className="text-slate-400 text-[10px] font-bold flex-shrink-0">เลือกสไลด์:</span>
              {[
                { id: 'all_slides', label: 'ทั้งหมด (39-45)' },
                { id: 'slide39', label: '39: Normal vs α-thal' },
                { id: 'slide40', label: '40: Bart’s & H (คู่เสี่ยง #1)' },
                { id: 'slide41', label: '41: β-thal trait' },
                { id: 'slide42', label: '42: β-thal disease (คู่เสี่ยง #2)' },
                { id: 'slide43', label: '43: EA (<25%)' },
                { id: 'slide44', label: '44: β-thal/Hb E (คู่เสี่ยง #3)' },
                { id: 'slide45', label: '45: Family Study' },
              ].map((pill) => (
                <button
                  key={pill.id}
                  onClick={() => setActiveSlideTab(pill.id)}
                  className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition text-[11px] ${
                    activeSlideTab === pill.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-indigo-50 hover:text-indigo-700'
                  }`}
                >
                  {pill.label}
                </button>
              ))}
            </div>

            {/* Slide 39: Normal nonclinical vs Normal with/without alpha thal */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide39') && (
              <div className="bg-white rounded-xl border border-indigo-150 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide39')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-800 font-extrabold text-[11px]">
                      สไลด์ 39
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      Normal nonclinical significant vs. Normal with/without alpha thalassemia
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">
                      Globin Chain Balance
                    </span>
                    {openSlideAccordions.slide39 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide39 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* Normal */}
                      <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200/80">
                        <div className="font-bold text-emerald-900 mb-1 flex items-center justify-between">
                          <span>1. คนปกติ (Normal nonclinical significant)</span>
                          <span className="text-[10px] font-mono bg-emerald-100 px-1.5 py-0.2 rounded text-emerald-800">
                            (αα/αα) (β/β)
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>MCV:</strong> 80–100 fL, <strong>MCH:</strong> 27–34 pg</li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-emerald-800">A2A</code> (Hb A2 = 2.5–3.5%)</li>
                          <li>• <strong>Globin chain:</strong> สาย α (141 aa) และสาย β (146 aa) สร้างสมดุลกันเป็น Hb A (α2β2) &gt;95%</li>
                        </ul>
                      </div>

                      {/* With/Without Alpha Thal */}
                      <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200/80">
                        <div className="font-bold text-amber-950 mb-1 flex items-center justify-between">
                          <span>2. ปกติที่มีหรือไม่มีพาหะอัลฟ่า-ธาลัสซีเมีย</span>
                          <span className="text-[10px] font-mono bg-amber-100 px-1.5 py-0.2 rounded text-amber-800">
                            (--/αα) หรือ (-α/αα)
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>MCV:</strong> <span className="font-bold text-amber-900">&lt; 80 fL</span>, <strong>MCH:</strong> &lt; 27 pg (Microcytic)</li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-amber-800">A2A</code> (Hb A2 &lt; 3.5% เหมือนคนปกติ!)</li>
                          <li>• <strong>กลไก:</strong> แม้ขาดสาย α ไป 1 หรือ 2 ยีน สาย β ยังจับกับ α เป็น Hb A ได้ ทำให้ Hb typing ไม่ผิดปกติ</li>
                        </ul>
                      </div>
                    </div>

                    {/* Golden Rule from Slide 39 */}
                    <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2 text-rose-900">
                      <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="font-bold text-rose-950">
                          ⚠️ กฎทองการตัดสินใจทางคลินิก (สไลด์ 39):
                        </span>
                        <p className="text-[11px] text-rose-800">
                          "ในรายที่ <strong>MCV &lt; 80 fL</strong> แต่ผล Hb typing เป็น <strong>A2A (A2 &lt; 3.5%)</strong> จะบอกได้ว่าเป็นพาหะ α-thal 1 หรือไม่ <strong>ต้องส่งตรวจ PCR for α-thal 1 เท่านั้น!</strong>" (เพื่อแยกพาหะ α-thal 1 ออกจาก α-thal 2 หรือภาวะขาดธาตุเหล็ก)
                        </p>
                      </div>
                    </div>

                    {onApplyPresetLab && (
                      <div className="flex justify-end">
                        <button
                          onClick={() =>
                            onApplyPresetLab('wife', {
                              mcv: 71.0,
                              mch: 22.5,
                              dcip: 'Negative',
                              ofTest: 'Positive',
                              hbTyping: 'A2A',
                              hbePercent: 0,
                              hba2Percent: 2.4,
                              hbfPercent: 0.5,
                              pcrAlpha1: 'Positive',
                            })
                          }
                          className="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-md font-semibold text-[11px] flex items-center gap-1 transition"
                        >
                          <ArrowRight className="w-3 h-3 text-sky-600" />
                          <span>โหลดค่าตัวอย่างสไลด์ 39 ลงแบบฟอร์มภรรยา (MCV 71, A2A, α-thal 1)</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Slide 40: Hb H disease & Hb Bart's hydrops fetalis */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide40') && (
              <div className="bg-white rounded-xl border border-rose-200 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide40')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-extrabold text-[11px]">
                      สไลด์ 40
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      Hb H disease &amp; Hb Bart's hydrops fetalis (1. คู่เสี่ยงที่รุนแรง - ไม่มีชีวิตรอด)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded font-bold">
                      คู่เสี่ยงรุนแรง #1
                    </span>
                    {openSlideAccordions.slide40 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide40 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* Hb H disease */}
                      <div className="p-2.5 rounded-lg bg-orange-50/70 border border-orange-200">
                        <div className="font-bold text-orange-950 mb-1 flex items-center justify-between">
                          <span>โรคฮีโมโกลบิน เอช (Hb H disease)</span>
                          <span className="text-[10px] font-mono bg-orange-100 px-1.5 py-0.2 rounded text-orange-800">
                            (--/-α) ขาด 3 ยีน
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>MCV:</strong> &lt; 80 fL, <strong>MCH:</strong> &lt; 27 pg</li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-orange-900">A2AH</code> หรือ <code className="bg-white px-1 rounded font-bold text-orange-900">A2A Bart's H</code></li>
                          <li>• <strong>พยาธิสรีรวิทยา:</strong> สาย β อิสระรวมตัวกันเป็น β4 = <strong>Hb H</strong> และตัวอ่อนมี γ4 = <strong>Hb Bart's</strong> ตกตะกอนทำให้เม็ดเลือดแดงแตกง่าย</li>
                        </ul>
                      </div>

                      {/* Hb Bart's Hydrops Fetalis */}
                      <div className="p-2.5 rounded-lg bg-rose-50/80 border border-rose-300">
                        <div className="font-bold text-rose-950 mb-1 flex items-center justify-between">
                          <span>1. คู่เสี่ยงที่รุนแรง: Hb Bart's hydrops fetalis</span>
                          <span className="text-[10px] font-mono bg-rose-200 px-1.5 py-0.2 rounded text-rose-900 font-bold">
                            (--/--) ขาด 4 ยีน
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>MCV:</strong> <strong>96 ± 8 fL</strong> (เซลล์ตัวอ่อนขนาดใหญ่), <strong>MCH:</strong> 26 ± 2 pg</li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-rose-900">Hb Bart's &gt; 80%</code> (ไม่มี Hb A)</li>
                          <li>• <strong>ผลลัพธ์ทางคลินิก (สไลด์ 40):</strong> <span className="font-bold text-rose-700">"ไม่มีชีวิตรอด (Lethal)"</span> ทารกเสียชีวิตในครรภ์หรือหลังคลอดไม่กี่นาที</li>
                        </ul>
                      </div>
                    </div>

                    {/* Maternal Complications Warning */}
                    <div className="p-2.5 rounded-lg bg-rose-100/60 border border-rose-300 text-rose-950 flex items-start gap-2">
                      <ShieldAlert className="w-4 h-4 text-rose-700 flex-shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="font-bold text-xs">อันตรายต่อมารดาในสไลด์ 40 (Maternal Risks):</span>
                        <p className="text-[11px] text-rose-900">
                          ทารกบวมน้ำ ซีด ตับม้ามโต รกขนาดใหญ่มาก (Placentomegaly) ส่งผลให้มารดาเสี่ยงต่อ <strong>ภาวะครรภ์เป็นพิษรุนแรง (Severe Preeclampsia / Mirror syndrome)</strong>, ความดันโลหิตสูง, คลอดติดขัด และตกเลือดหลังคลอดถึงแก่ชีวิต
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Slide 41: Beta-thalassemia trait */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide41') && (
              <div className="bg-white rounded-xl border border-purple-200 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide41')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-extrabold text-[11px]">
                      สไลด์ 41
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      พาหะเบต้า-ธาลัสซีเมีย (β-thalassemia trait) &amp; ความหมายของ β+ vs β0
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded font-mono font-bold">
                      Hb A2 &gt; 3.5%
                    </span>
                    {openSlideAccordions.slide41 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide41 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* Beta Definition */}
                      <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                        <span className="font-bold text-slate-900 block mb-1">นิยามชนิดของยีน β (สไลด์ 41):</span>
                        <div className="space-y-1.5 text-[11px]">
                          <div className="flex items-start gap-1.5">
                            <span className="px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800 font-bold font-mono">β+</span>
                            <span>= มีการสร้างสาย β-globin ได้ แต่ปริมาณลดลง</span>
                          </div>
                          <div className="flex items-start gap-1.5">
                            <span className="px-1.5 py-0.2 rounded bg-rose-100 text-rose-800 font-bold font-mono">β0</span>
                            <span>= ไม่มีการสร้างสาย β-globin เลย</span>
                          </div>
                        </div>
                      </div>

                      {/* Beta Trait Profile */}
                      <div className="p-2.5 rounded-lg bg-purple-50/70 border border-purple-200">
                        <span className="font-bold text-purple-950 block mb-1">พาหะ β-thalassemia trait:</span>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Genotype:</strong> <code className="bg-white px-1 rounded font-mono text-purple-900 font-bold">(β0/β) หรือ (β+/β)</code></li>
                          <li>• <strong>MCV:</strong> &lt; 80 fL, <strong>MCH:</strong> &lt; 27 pg</li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-purple-900">A2A</code> โดยที่ <strong>Hb A2 &gt; 3.5%</strong> (มักอยู่ระหว่าง 3.6–8.0%)</li>
                        </ul>
                      </div>
                    </div>

                    {/* Why A2 Rises */}
                    <div className="p-2.5 rounded-lg bg-indigo-50/60 border border-indigo-200 text-indigo-950">
                      <span className="font-bold text-xs block mb-0.5">ทำไม Hb A2 จึงสูงขึ้นเกิน 3.5%? (กลไกสไลด์ 41)</span>
                      <p className="text-[11px] text-indigo-900">
                        เมื่อการสร้างสาย β ลดลง สาย α อิสระที่เหลือจะหันไปจับคู่กับสาย δ (ที่ปกติมีน้อย) เกิดเป็นโมเลกุล <strong>Hb A2 (α2δ2) เพิ่มสูงขึ้น</strong> เป็นเครื่องหมายจำเพาะของพาหะเบต้า
                      </p>
                    </div>

                    {/* PCR Rule */}
                    <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                      <span className="text-[11px]">
                        <strong>ข้อจำกัด (สไลด์ 41):</strong> การตรวจ Hb typing ไม่สามารถบอกได้ว่าเป็น β0 หรือ β+ <strong className="text-amber-950">"จะบอกได้ต้องส่งตรวจ PCR (DNA mutation analysis)"</strong>
                      </span>
                    </div>

                    {onApplyPresetLab && (
                      <div className="flex justify-end">
                        <button
                          onClick={() =>
                            onApplyPresetLab('husband', {
                              mcv: 67.0,
                              mch: 21.0,
                              dcip: 'Negative',
                              ofTest: 'Positive',
                              hbTyping: 'A2A',
                              hbePercent: 0,
                              hba2Percent: 5.5,
                              hbfPercent: 0.5,
                              pcrAlpha1: 'Not tested',
                            })
                          }
                          className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 rounded-md font-semibold text-[11px] flex items-center gap-1 transition"
                        >
                          <ArrowRight className="w-3 h-3 text-purple-600" />
                          <span>โหลดค่าพาหะ β-thal trait ลงแบบฟอร์มสามี (MCV 67, A2A, Hb A2 5.5%)</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Slide 42: Homozygous Beta-thalassemia disease (A2FA vs A2F) */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide42') && (
              <div className="bg-white rounded-xl border border-purple-300 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide42')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-purple-200 text-purple-900 font-extrabold text-[11px]">
                      สไลด์ 42
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      โรคเบต้า-ธาลัสซีเมีย (2. คู่เสี่ยงที่รุนแรง - การแยก A2FA vs A2F)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-purple-100 text-purple-800 px-2 py-0.5 rounded font-bold">
                      คู่เสี่ยงรุนแรง #2
                    </span>
                    {openSlideAccordions.slide42 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide42 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <p className="text-slate-600 text-[11px]">
                      <strong>Genotypes:</strong> (β0/β0), (β0/β+), (β+/β+) &bull; <strong>CBC:</strong> MCV &lt; 80 fL, MCH &lt; 27 pg &bull; จัดเป็น <strong>2. คู่เสี่ยงที่รุนแรง</strong>
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* A2FA */}
                      <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-200">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-indigo-950">A2FA = β+ thal disease</span>
                          <span className="text-[10px] font-mono bg-indigo-100 px-1.5 py-0.2 rounded text-indigo-800">
                            (β+/β0 หรือ β+/β+)
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-indigo-900">A2FA</code></li>
                          <li>• <strong>เกณฑ์ Hb F:</strong> <strong>Hb F ≥ 10%</strong></li>
                          <li>• <strong>จุดสังเกต (สไลด์ 42):</strong> ยังมี Hb A ปรากฏอยู่เล็กน้อย เพราะยีน β+ ยังผลิตสาย β ได้บางส่วน</li>
                        </ul>
                      </div>

                      {/* A2F */}
                      <div className="p-2.5 rounded-lg bg-purple-50/80 border border-purple-300">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-purple-950">A2F = β0 thal major</span>
                          <span className="text-[10px] font-mono bg-purple-200 px-1.5 py-0.2 rounded text-purple-900 font-bold">
                            (β0/β0) โฮโมไซกัส
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-purple-950">A2F</code></li>
                          <li>• <strong>เกณฑ์ Hb F:</strong> <strong>Hb F ≥ 20%</strong></li>
                          <li>• <strong>จุดสังเกต (สไลด์ 42):</strong> <strong>"Hb A ถูกขีดฆ่าทิ้ง = ไม่มี Hb A เลย"</strong> ร่างกายสร้างเฉพาะ Hb F (α2γ2) และ Hb A2</li>
                        </ul>
                      </div>
                    </div>

                    {/* Clinical Impact */}
                    <div className="p-2 rounded-lg bg-purple-100/50 border border-purple-200 text-purple-950 text-[11px]">
                      <strong>อาการทางคลินิก:</strong> ทารกจะเริ่มซีดเร็วภายใน 1–2 ปีแรก ตับม้ามโตมาก ใบหน้าเปลี่ยนเป็น Thalassemia facies เจริญเติบโตช้า ต้องได้รับเลือดตลอดชีวิตและเสี่ยงภาวะธาตุเหล็กเกินทำลายหัวใจและตับ
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Slide 43: Hb E trait & EA with alpha thal (E+A2 < 25%) */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide43') && (
              <div className="bg-white rounded-xl border border-amber-200 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide43')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-extrabold text-[11px]">
                      สไลด์ 43
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      พาหะฮีโมโกลบิน อี (Hb E trait) &amp; EA ร่วมกับพาหะอัลฟ่า (E+A2 &lt; 25%)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-mono font-bold">
                      E+A2 &lt; 25% Alert
                    </span>
                    {openSlideAccordions.slide43 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide43 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* Standard Hb E Trait */}
                      <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200">
                        <span className="font-bold text-amber-950 block mb-1">Hb E trait ทั่วไป (ไม่มี α-thal):</span>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Genotype:</strong> <code className="bg-white px-1 rounded font-mono text-amber-900">(βE/β)</code></li>
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-amber-900">EA</code> (E+A2 = 25–35%)</li>
                          <li>• <strong>ข้อจำกัดเครื่องแล็บ (สไลด์ 43):</strong> เครื่อง HPLC/CE แยก Hb E และ Hb A2 ไม่ได้ จึงรายงานผลรวมกันเป็น <strong>E+A2</strong></li>
                        </ul>
                      </div>

                      {/* EA with Alpha Thal */}
                      <div className="p-2.5 rounded-lg bg-rose-50/70 border border-rose-200">
                        <span className="font-bold text-rose-950 block mb-1">EA with suspected α-thalassemia:</span>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>เกณฑ์สำคัญ (สไลด์ 43):</strong> <span className="font-bold text-rose-800">E+A2 &lt; 25%</span> (มักอยู่ที่ 15–24%)</li>
                          <li>• <strong>พยาธิสรีรวิทยา:</strong> "มีการหายไปของสายแอลฟ่าด้วย จึงทำให้สายแอลฟ่าไปจับกับ Hb E ลดลง % รวมจึงลดลงต่ำกว่า 25%"</li>
                          <li>• <strong>คำสั่ง:</strong> ⚠️ <strong>"จะบอกได้ต้องส่ง PCR for α-thal 1"</strong></li>
                        </ul>
                      </div>
                    </div>

                    {onApplyPresetLab && (
                      <div className="flex justify-end">
                        <button
                          onClick={() =>
                            onApplyPresetLab('wife', {
                              mcv: 73.0,
                              mch: 23.0,
                              dcip: 'Positive',
                              ofTest: 'Positive',
                              hbTyping: 'EA',
                              hbePercent: 21.5,
                              hba2Percent: 2.0,
                              hbfPercent: 0.5,
                              pcrAlpha1: 'Positive',
                            })
                          }
                          className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-md font-semibold text-[11px] flex items-center gap-1 transition"
                        >
                          <ArrowRight className="w-3 h-3 text-amber-700" />
                          <span>โหลดค่าตัวอย่างสไลด์ 43 (ภรรยา EA ที่มี E+A2 &lt; 25%)</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Slide 44: Beta-thal/Hb E disease (EFA vs EF & EE/EF warning) */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide44') && (
              <div className="bg-white rounded-xl border border-pink-200 p-3.5 shadow-2xs space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide44')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-pink-100 text-pink-900 font-extrabold text-[11px]">
                      สไลด์ 44
                    </span>
                    <h4 className="font-bold text-slate-800 text-xs">
                      โรคเบต้า-ธาลัสซีเมีย / ฮีโมโกลบิน อี (3. คู่เสี่ยงที่รุนแรง - EFA vs EF &amp; ข้อควรระวัง EE/EF)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-pink-100 text-pink-800 px-2 py-0.5 rounded font-bold">
                      คู่เสี่ยงรุนแรง #3
                    </span>
                    {openSlideAccordions.slide44 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide44 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    <p className="text-slate-600 text-[11px]">
                      โรคยอดฮิตในประเทศไทย (โดยเฉพาะภาคอีสาน) จัดเป็น <strong>3. คู่เสี่ยงที่รุนแรง</strong> อาการมีตั้งแต่ซีดปานกลางจนถึงรุนแรงมาก
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {/* EFA */}
                      <div className="p-2.5 rounded-lg bg-pink-50/70 border border-pink-200">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-pink-950">EFA &gt;&gt;&gt; β+ thal / Hb E</span>
                          <span className="text-[10px] font-mono bg-pink-100 px-1.5 py-0.2 rounded text-pink-800">
                            (β+/βE)
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-pink-900">EFA</code></li>
                          <li>• <strong>เกณฑ์ Hb F:</strong> <strong>Hb F ≥ 10%</strong></li>
                          <li>• มี Hb A เล็กน้อย อาการมักรุนแรงปานกลาง</li>
                        </ul>
                      </div>

                      {/* EF */}
                      <div className="p-2.5 rounded-lg bg-rose-50/80 border border-rose-300">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-rose-950">EF &gt;&gt;&gt; β0 thal / Hb E</span>
                          <span className="text-[10px] font-mono bg-rose-200 px-1.5 py-0.2 rounded text-rose-900 font-bold">
                            (β0/βE) รุนแรงมาก
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Hb typing:</strong> <code className="bg-white px-1 rounded font-bold text-rose-950">EF</code></li>
                          <li>• <strong>เกณฑ์ Hb F:</strong> <strong>Hb F ≥ 20%</strong></li>
                          <li>• ไม่มี Hb A อาการซีดรุนแรงเทียบเท่า homozygous beta-thal</li>
                        </ul>
                      </div>
                    </div>

                    {/* Critical Warning Box from Slide 44 */}
                    <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-950 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div className="space-y-1 text-[11px]">
                        <span className="font-bold block">
                          ⚠️ ข้อควรระวังผลแล็บลวงในสไลด์ 44 (Warning: EE vs EF Report):
                        </span>
                        <p className="text-amber-900">
                          "ถ้าเจอ <strong>5 &lt; Hb F &lt; 20%</strong> อาจจะเป็นแบบ EF ได้ โดยห้องแล็บอาจรายงานเป็น <strong>EE/EF</strong> จึงต้องแยก Homozygous Hb E (EE: Hb E &gt;80%, Hb F &lt;5%) ออกจากโรค β0-thal/Hb E (EF) โดยการตรวจ <strong>Family study</strong> หรือ <strong>DNA mutation</strong> เสมอ!"
                        </p>
                      </div>
                    </div>

                    {onApplyPresetLab && (
                      <div className="flex justify-end">
                        <button
                          onClick={() =>
                            onApplyPresetLab('wife', {
                              mcv: 60.0,
                              mch: 19.0,
                              dcip: 'Positive',
                              ofTest: 'Positive',
                              hbTyping: 'EF',
                              hbePercent: 65.0,
                              hba2Percent: 0,
                              hbfPercent: 25.0,
                              pcrAlpha1: 'Not tested',
                            })
                          }
                          className="px-2.5 py-1 bg-pink-50 hover:bg-pink-100 text-pink-800 border border-pink-200 rounded-md font-semibold text-[11px] flex items-center gap-1 transition"
                        >
                          <ArrowRight className="w-3 h-3 text-pink-600" />
                          <span>โหลดค่าตัวอย่างโรค β0-thal/Hb E ลงแบบฟอร์มภรรยา (MCV 60, EF, Hb F 25%)</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Slide 45: Family study example and genetic transmission */}
            {(activeSlideTab === 'all_slides' || activeSlideTab === 'slide45') && (
              <div className="bg-white rounded-xl border-2 border-indigo-300 p-3.5 shadow-sm space-y-3">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleSlideAccordion('slide45')}
                >
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-600 text-white font-extrabold text-[11px]">
                      สไลด์ 45
                    </span>
                    <h4 className="font-bold text-slate-900 text-xs">
                      การศึกษาครอบครัว (Family study) ตัวอย่างการแปลผลและการวิเคราะห์ทางพันธุศาสตร์
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-bold">
                      กรณีศึกษาตัวอย่าง
                    </span>
                    {openSlideAccordions.slide45 ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {openSlideAccordions.slide45 && (
                  <div className="space-y-3 pt-1 border-t border-slate-100 text-[11.5px] leading-relaxed">
                    {/* Couple Information in Slide 45 */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div className="p-2.5 rounded-lg bg-purple-50/80 border border-purple-200">
                        <div className="flex items-center justify-between font-bold text-purple-950 mb-1">
                          <span>สามี (Husband):</span>
                          <span className="text-[10px] font-mono bg-purple-200 px-1.5 py-0.2 rounded text-purple-900">
                            Hb Typing: A2F
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Genotype:</strong> <code className="font-mono bg-white px-1 rounded text-purple-950 font-bold">αα/αα, β0/β0</code></li>
                          <li>• <strong>การแปลผล:</strong> เป็นโรค Homozygous β0-thalassemia major</li>
                          <li>• <strong>เซลล์สืบพันธุ์ที่ส่งต่อ:</strong> ส่งต่อยีน <strong>β0</strong> ให้แก่ลูกได้เพียงชนิดเดียว (100%)</li>
                        </ul>
                      </div>

                      <div className="p-2.5 rounded-lg bg-amber-50/80 border border-amber-200">
                        <div className="flex items-center justify-between font-bold text-amber-950 mb-1">
                          <span>ภรรยา (Wife):</span>
                          <span className="text-[10px] font-mono bg-amber-200 px-1.5 py-0.2 rounded text-amber-900">
                            Hb Typing: EA
                          </span>
                        </div>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          <li>• <strong>Genotype:</strong> <code className="font-mono bg-white px-1 rounded text-amber-950 font-bold">αα/αα, β/βE</code></li>
                          <li>• <strong>การแปลผล:</strong> เป็นพาหะ Hb E trait</li>
                          <li>• <strong>เซลล์สืบพันธุ์ที่ส่งต่อ:</strong> ส่งต่อยีนปกติ <strong>β</strong> (50%) หรือยีน <strong>βE</strong> (50%)</li>
                        </ul>
                      </div>
                    </div>

                    {/* Punnett Square 4 Quadrants as shown in Slide 45 */}
                    <div className="p-3 rounded-xl bg-slate-900 text-white space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-indigo-300 flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-indigo-400" />
                          ตาราง Punnett Square ถอดรหัสยีนสไลด์ 45 (พ่อ β0/β0 + แม่ β/βE)
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">4 Combinations</span>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-center text-[11px] border-collapse">
                          <thead>
                            <tr className="border-b border-slate-700 text-slate-400">
                              <th className="p-1.5 text-left text-slate-500 font-normal">พ่อ \ แม่</th>
                              <th className="p-1.5 bg-indigo-950/60 text-indigo-200 font-bold">เซลล์สืบพันธุ์แม่: β (ปกติ)</th>
                              <th className="p-1.5 bg-amber-950/60 text-amber-200 font-bold">เซลล์สืบพันธุ์แม่: βE</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-slate-800">
                              <td className="p-1.5 font-bold text-purple-300 text-left bg-purple-950/40">พ่อ: β0</td>
                              <td className="p-2 bg-slate-800/80 border border-slate-700/60">
                                <span className="font-mono font-bold text-sky-300">β0/β</span>
                                <div className="text-[10px] text-sky-200">พาหะ β-thal trait (25%)</div>
                              </td>
                              <td className="p-2 bg-slate-800/80 border border-slate-700/60">
                                <span className="font-mono font-bold text-rose-300">β0/βE</span>
                                <div className="text-[10px] text-rose-200 font-bold">โรค β-thal/Hb E (25%)</div>
                              </td>
                            </tr>
                            <tr>
                              <td className="p-1.5 font-bold text-purple-300 text-left bg-purple-950/40">พ่อ: β0</td>
                              <td className="p-2 bg-slate-800/80 border border-slate-700/60">
                                <span className="font-mono font-bold text-sky-300">β0/β</span>
                                <div className="text-[10px] text-sky-200">พาหะ β-thal trait (25%)</div>
                              </td>
                              <td className="p-2 bg-slate-800/80 border border-slate-700/60">
                                <span className="font-mono font-bold text-rose-300">β0/βE</span>
                                <div className="text-[10px] text-rose-200 font-bold">โรค β-thal/Hb E (25%)</div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      {/* Summary Metrics */}
                      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center text-[11px]">
                        <div className="p-1.5 rounded bg-rose-950/60 border border-rose-800/60">
                          <span className="text-slate-400 text-[10px] block">โอกาสลูกเป็นโรค (β0/βE)</span>
                          <span className="text-sm font-black text-rose-400">50%</span>
                        </div>
                        <div className="p-1.5 rounded bg-sky-950/60 border border-sky-800/60">
                          <span className="text-slate-400 text-[10px] block">โอกาสลูกเป็นพาหะ (β0/β)</span>
                          <span className="text-sm font-black text-sky-400">50%</span>
                        </div>
                        <div className="p-1.5 rounded bg-slate-800 border border-slate-700">
                          <span className="text-slate-400 text-[10px] block">โอกาสลูกปกติ (β/β)</span>
                          <span className="text-sm font-black text-slate-300">0% (ไม่มีโอกาส)</span>
                        </div>
                      </div>
                    </div>

                    {/* Interactive Button for Slide 45 */}
                    <div className="p-2.5 rounded-lg bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                        <span className="text-[11px] text-indigo-900 font-medium">
                          ทดสอบการคำนวณและสร้างตารางพันธุศาสตร์ของคู่นี้ในระบบเสมือนจริง:
                        </span>
                      </div>
                      {onApplyPresetLab && (
                        <button
                          onClick={() => {
                            onApplyPresetLab('husband', {
                              mcv: 64.0,
                              mch: 19.5,
                              dcip: 'Negative',
                              ofTest: 'Positive',
                              hbTyping: 'A2F',
                              hbePercent: 0,
                              hba2Percent: 3.0,
                              hbfPercent: 22.0,
                              pcrAlpha1: 'Not tested',
                            });
                            onApplyPresetLab('wife', {
                              mcv: 82.0,
                              mch: 27.5,
                              dcip: 'Positive',
                              ofTest: 'Positive',
                              hbTyping: 'EA',
                              hbePercent: 28.0,
                              hba2Percent: 2.5,
                              hbfPercent: 0.5,
                              pcrAlpha1: 'Not tested',
                            });
                          }}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-xs shadow-xs flex items-center gap-1.5 transition active:scale-95 whitespace-nowrap"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                          <span>โหลดเคสสไลด์ 45 เข้า Lab Engine ทันที</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* Section: Red Cell Indices (MCV & MCH) */}
        {(activeCategory === 'all' || activeCategory === 'indices') && (
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <Droplet className="w-4 h-4 text-rose-500" />
                <span>เกณฑ์ดัชนีเม็ดเลือดแดง (CBC Red Cell Indices)</span>
              </div>
              <span className="text-[10px] bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded-full font-semibold">
                จุดตัดคัดกรอง
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-rose-50/60 border border-rose-100">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-rose-950">MCV (Mean Corpuscular Volume)</span>
                  <span className="text-[11px] font-mono font-bold text-rose-700">&lt; 80 fL</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-snug">
                  • ค่าปกติ: <strong>≥ 80 fL</strong> (ปกติ 80–98 fL)<br />
                  • <strong>MCV &lt; 80 fL</strong>: เม็ดเลือดแดงขนาดเล็ก (Microcytic) สงสัยพาหะ α-thal 1, β-thal trait หรือโลหิตจางขาดธาตุเหล็ก (IDA)
                </p>
                <div className="mt-2 flex gap-1">
                  {onApplyPresetLab && (
                    <>
                      <button
                        onClick={() => onApplyPresetLab('wife', { mcv: 72.0, mch: 24.0 })}
                        className="text-[10px] px-2 py-0.5 bg-rose-200/70 hover:bg-rose-300 text-rose-900 rounded font-medium transition"
                      >
                        ลองใส่ภรรยา (72 fL)
                      </button>
                      <button
                        onClick={() => onApplyPresetLab('husband', { mcv: 71.5, mch: 23.5 })}
                        className="text-[10px] px-2 py-0.5 bg-rose-200/70 hover:bg-rose-300 text-rose-900 rounded font-medium transition"
                      >
                        ลองใส่สามี (71.5 fL)
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-100">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-amber-950">MCH (Mean Corpuscular Hb)</span>
                  <span className="text-[11px] font-mono font-bold text-amber-700">&lt; 27 pg</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-snug">
                  • ค่าปกติ: <strong>≥ 27 pg</strong> (ปกติ 27–32 pg)<br />
                  • <strong>MCH &lt; 27 pg</strong>: ติดสีจาง (Hypochromic) มีความไวสูงในการคัดกรองพาหะธาลัสซีเมียคู่ขนานกับ MCV
                </p>
                <div className="mt-2 flex gap-1">
                  {onApplyPresetLab && (
                    <button
                      onClick={() => onApplyPresetLab('wife', { mcv: 86.0, mch: 29.5 })}
                      className="text-[10px] px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded font-medium transition"
                    >
                      ค่าปกติทั้งคู่ (MCV 86, MCH 29.5)
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Note about EA and MCV */}
            <div className="p-2 bg-slate-100 rounded-lg text-[11px] text-slate-700 border border-slate-200 flex items-start gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>
                <strong>ข้อพึงระวังคลินิก:</strong> พาหะฮีโมโกลบิน อี (EA) อาจมี MCV ปกติหรือก้ำกึ่ง (75–85 fL) จึง<strong>ห้ามใช้ MCV คัดกรองยีน E เดี่ยวๆ</strong> ต้องตรวจคัดกรองด้วย DCIP เสมอ!
              </span>
            </div>
          </div>
        )}

        {/* Section: Screening Tests (OF Test & DCIP Test) */}
        {(activeCategory === 'all' || activeCategory === 'screen') && (
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <TestTube className="w-4 h-4 text-purple-600" />
                <span>การตรวจคัดกรองเบื้องต้น (OF Test & DCIP Test)</span>
              </div>
              <span className="text-[10px] bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded-full font-semibold">
                Screening Protocol
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-purple-50/50 border border-purple-100">
                <div className="font-bold text-purple-950 mb-1 flex items-center justify-between">
                  <span>OF Test (Osmotic Fragility)</span>
                  <span className="text-[10px] bg-purple-200/80 text-purple-900 px-1.5 py-0.2 rounded font-mono">
                    0.36% Saline
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-snug">
                  • <strong>Positive (+)</strong>: สารละลายขุ่น (เม็ดเลือดแดงทนการแตกตัว) บ่งชี้พาหะ α-thal 1, β-thal trait หรือขาดธาตุเหล็ก<br />
                  • <strong>Negative (-)</strong>: สารละลายใสสีแดง (เม็ดเลือดแดงแตกหมด ปกติ)
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-pink-50/50 border border-pink-100">
                <div className="font-bold text-pink-950 mb-1 flex items-center justify-between">
                  <span>DCIP Test (ตรวจ Hb E & Hb H)</span>
                  <span className="text-[10px] bg-pink-200/80 text-pink-900 px-1.5 py-0.2 rounded font-mono">
                    Precipitation
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-snug">
                  • <strong>Positive (+)</strong>: เกิดตะกอนสีฟ้า แปลผลว่า <strong>มี Hb E</strong> (EA, EE, β-thal/Hb E) หรือมี Hb H<br />
                  • <strong>Negative (-)</strong>: สารละลายใสสีฟ้า ไม่มีตะกอน (ไม่มี Hb E)
                </p>
              </div>
            </div>

            <div className="text-[11px] text-purple-900 bg-purple-50 p-2 rounded-lg border border-purple-200">
              💡 <strong>สูตรคัดกรองไทย (MOPH Combo):</strong> ตรวจร่วมกัน <strong>OF Test + DCIP Test</strong> หรือ <strong>MCV/MCH + DCIP</strong> ให้ความไว &gt;98% ในการตรวจพบพาหะของ 3 โรคธาลัสซีเมียชนิดรุนแรง
            </div>
          </div>
        )}

        {/* Section: Hb Typing & Quantitative Interpretation Table (The Core Matrix) */}
        {(activeCategory === 'all' || activeCategory === 'typing') && (
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <Dna className="w-4 h-4 text-indigo-600" />
                <span>ตารางแปลผลการตรวจแยกชนิดฮีโมโกลบิน (Hb Typing Reference Matrix)</span>
              </div>
              <button
                onClick={() => setExpandedSection(expandedSection === 'hb_matrix' ? null : 'hb_matrix')}
                className="text-slate-400 hover:text-slate-600"
              >
                {expandedSection === 'hb_matrix' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              ค่ามาตรฐานจากการตรวจด้วยวิธี HPLC / Capillary Electrophoresis / Microcolumn
            </p>

            {/* Matrix Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-[11px]">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <th className="p-2">Hb Pattern</th>
                    <th className="p-2">เกณฑ์เปอร์เซ็นต์ (% Hb)</th>
                    <th className="p-2">MCV (fL)</th>
                    <th className="p-2">การแปลผล (Diagnosis)</th>
                    <th className="p-2 text-right">โหลด</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {/* Normal */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-mono font-bold text-emerald-700">A2A</td>
                    <td className="p-2">
                      Hb A2: <strong>2.0 – 3.5%</strong><br />
                      Hb A: &gt; 95%
                    </td>
                    <td className="p-2 text-emerald-800 font-semibold">&ge; 80 fL</td>
                    <td className="p-2">
                      <span className="font-semibold text-emerald-950">ปกติ (Normal)</span>
                      <p className="text-[10px] text-slate-500">ไม่เป็นพาหะชนิดรุนแรง</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'A2A', hba2Percent: 2.7, hbePercent: 0, mcv: 85, mch: 29 })}
                          title="โหลดค่าปกตินี้"
                          className="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px]"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* Beta-thal trait */}
                  <tr className="hover:bg-amber-50/50 bg-amber-50/20">
                    <td className="p-2 font-mono font-bold text-amber-700">A2A</td>
                    <td className="p-2">
                      <span className="text-amber-800 font-bold">Hb A2 &gt; 3.5%</span> (3.6 – 8.0%)<br />
                      Hb F: 1.0 – 3.0%
                    </td>
                    <td className="p-2 text-rose-700 font-semibold">&lt; 80 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-amber-950">พาหะเบต้า (β-thal trait)</span>
                      <p className="text-[10px] text-amber-800">เสี่ยงคู่ Homo β และ β/Hb E</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'A2A', hba2Percent: 5.2, hbePercent: 0, mcv: 68, mch: 21.5 })}
                          title="โหลดค่าพาหะเบต้า"
                          className="px-1.5 py-0.5 rounded bg-amber-200 hover:bg-amber-300 text-amber-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* Suspected Alpha-thal 1 */}
                  <tr className="hover:bg-rose-50/50 bg-rose-50/20">
                    <td className="p-2 font-mono font-bold text-rose-700">A2A</td>
                    <td className="p-2">
                      Hb A2: <strong>&lt; 3.5%</strong> (ปกติ)<br />
                      DCIP: ลบ (-)
                    </td>
                    <td className="p-2 text-rose-700 font-bold">&lt; 80 fL (60–75)</td>
                    <td className="p-2">
                      <span className="font-bold text-rose-950">สงสัยพาหะอัลฟ่า 1 (α-thal 1)</span>
                      <p className="text-[10px] text-rose-700 font-semibold">⚠️ ต้องตรวจ PCR α-thal 1</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('husband', { hbTyping: 'A2A', hba2Percent: 2.4, hbePercent: 0, mcv: 70, mch: 22.5, pcrAlpha1: 'Positive' })}
                          title="โหลดค่าสงสัยพาหะอัลฟ่า 1"
                          className="px-1.5 py-0.5 rounded bg-rose-200 hover:bg-rose-300 text-rose-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* EA Trait */}
                  <tr className="hover:bg-pink-50/50">
                    <td className="p-2 font-mono font-bold text-pink-700">EA</td>
                    <td className="p-2">
                      Hb E: <strong>25 – 35%</strong> (DCIP +)<br />
                      Hb A: 65 – 75%
                    </td>
                    <td className="p-2 text-slate-700">75 – 85 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-pink-950">พาหะฮีโมโกลบิน อี (Hb E trait)</span>
                      <p className="text-[10px] text-slate-500">พบบ่อยสุดในภาคอีสาน (~30%)</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'EA', hbePercent: 29.5, hba2Percent: 2.5, mcv: 82, mch: 27, dcip: 'Positive' })}
                          title="โหลดค่าพาหะ Hb E"
                          className="px-1.5 py-0.5 rounded bg-pink-200 hover:bg-pink-300 text-pink-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* EA with Alpha thal */}
                  <tr className="hover:bg-pink-50/50">
                    <td className="p-2 font-mono font-bold text-pink-800">EA (&lt;25%)</td>
                    <td className="p-2">
                      <span className="text-pink-900 font-bold">Hb E &lt; 25%</span> (15–24%)<br />
                      DCIP: บวก (+)
                    </td>
                    <td className="p-2 text-rose-700 font-bold">&lt; 80 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-pink-950">Hb E trait ร่วมกับ α-thal</span>
                      <p className="text-[10px] text-slate-500">สายอัลฟ่าสร้างน้อย ทำให้ E ต่ำ</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'EA', hbePercent: 22.0, hba2Percent: 2.0, mcv: 74, mch: 23, dcip: 'Positive', pcrAlpha1: 'Positive' })}
                          title="โหลดค่า EA ร่วมกับอัลฟ่า"
                          className="px-1.5 py-0.5 rounded bg-pink-200 hover:bg-pink-300 text-pink-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* EE (Homozygous Hb E) */}
                  <tr className="hover:bg-purple-50/50 bg-purple-50/10">
                    <td className="p-2 font-mono font-bold text-purple-700">EE</td>
                    <td className="p-2">
                      Hb E: <strong>&gt; 80%</strong> (80–90%)<br />
                      Hb A: <strong>0%</strong> (ไม่มี), F &lt; 5%
                    </td>
                    <td className="p-2 text-rose-700 font-bold">&lt; 70 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-purple-950">Homozygous Hb E</span>
                      <p className="text-[10px] text-purple-800">คู่กับ β-trait เสี่ยง β/Hb E 25%</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'EE', hbePercent: 86.5, hba2Percent: 0, mcv: 62, mch: 20.5, dcip: 'Positive' })}
                          title="โหลดค่า EE"
                          className="px-1.5 py-0.5 rounded bg-purple-200 hover:bg-purple-300 text-purple-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* EF (Beta0/Hb E) */}
                  <tr className="hover:bg-red-50/50 bg-red-50/20">
                    <td className="p-2 font-mono font-bold text-red-700">EF</td>
                    <td className="p-2">
                      Hb E: 40–80%<br />
                      <span className="text-red-700 font-bold">Hb F: 10–40%</span>, Hb A: 0%
                    </td>
                    <td className="p-2 text-rose-800 font-bold">&lt; 65 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-red-950">โรค β0-thal / Hb E</span>
                      <p className="text-[10px] text-red-700 font-semibold">1 ใน 3 โรครุนแรง (Disease)</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'EF', hbePercent: 65, hbfPercent: 25, hba2Percent: 0, mcv: 60, mch: 19.5, dcip: 'Positive' })}
                          title="โหลดค่าโรค β0/E"
                          className="px-1.5 py-0.5 rounded bg-red-200 hover:bg-red-300 text-red-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* EFA (Beta+/Hb E) */}
                  <tr className="hover:bg-orange-50/50 bg-orange-50/10">
                    <td className="p-2 font-mono font-bold text-orange-700">EFA</td>
                    <td className="p-2">
                      Hb E เด่น, Hb F สูง<br />
                      มี Hb A เล็กน้อย (5–20%)
                    </td>
                    <td className="p-2 text-rose-800 font-semibold">&lt; 70 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-orange-950">โรค β+-thal / Hb E</span>
                      <p className="text-[10px] text-slate-500">สร้างสายเบต้าได้บางส่วน</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'EFA', hbePercent: 60, hbfPercent: 18, hbaPercent: 15, mcv: 64, mch: 21, dcip: 'Positive' })}
                          title="โหลดค่าโรค β+/E"
                          className="px-1.5 py-0.5 rounded bg-orange-200 hover:bg-orange-300 text-orange-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>

                  {/* Hb H Disease */}
                  <tr className="hover:bg-blue-50/50">
                    <td className="p-2 font-mono font-bold text-blue-700">A2AH</td>
                    <td className="p-2">
                      พบแถบ <strong>Hb H (β4)</strong> หรือ Hb Bart’s (&gamma;4)
                    </td>
                    <td className="p-2 text-rose-800 font-bold">&lt; 65 fL</td>
                    <td className="p-2">
                      <span className="font-bold text-blue-950">โรคฮีโมโกลบิน เอช (Hb H)</span>
                      <p className="text-[10px] text-slate-500">ขาดจีนอัลฟ่า 3 ยีน (--/-α)</p>
                    </td>
                    <td className="p-2 text-right">
                      {onApplyPresetLab && (
                        <button
                          onClick={() => onApplyPresetLab('wife', { hbTyping: 'A2AH', hba2Percent: 1.5, hbePercent: 0, mcv: 58, mch: 18, dcip: 'Positive' })}
                          title="โหลดค่า Hb H disease"
                          className="px-1.5 py-0.5 rounded bg-blue-200 hover:bg-blue-300 text-blue-900 text-[10px] font-medium"
                        >
                          ใส่
                        </button>
                      )}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Section: Molecular / PCR for alpha-thal 1 */}
        {(activeCategory === 'all' || activeCategory === 'dna') && (
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <Dna className="w-4 h-4 text-emerald-600" />
                <span>การตรวจระดับยีน: PCR for α-thalassemia 1</span>
              </div>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full font-semibold">
                Definitive Test
              </span>
            </div>

            <p className="text-[11px] text-slate-600 leading-relaxed">
              การตรวจหว่านล้อมยีนอัลฟ่า-โกลบินที่ขาดหายไป 2 ยีนบนโครโมโซมคู่ที่ 16 ด้วยเทคนิค Gap-PCR:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200">
                <span className="font-bold text-emerald-950 block mb-1">
                  1. Southeast Asian (SEA) deletion
                </span>
                <p className="text-[11px] text-slate-600">
                  • ขาดหายไป 19.3 kb<br />
                  • <strong>พบบ่อยที่สุดในคนไทย (&gt;80% ของ α-thal 1 ทั้งหมด)</strong>
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200">
                <span className="font-bold text-emerald-950 block mb-1">
                  2. THAI deletion
                </span>
                <p className="text-[11px] text-slate-600">
                  • ขาดหายไป 33.4 kb<br />
                  • พบประปรายในประชากรไทย
                </p>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] space-y-1">
              <span className="font-bold text-slate-800">เกณฑ์การส่งตรวจ PCR α-thal 1 ตามกระทรวงสาธารณสุข:</span>
              <ul className="list-disc list-inside text-slate-600 space-y-0.5 pl-1">
                <li>สตรีตั้งครรภ์หรือสามีที่มี <strong>MCV &lt; 80 fL หรือ MCH &lt; 27 pg</strong> (หรือ OF test ผลบวก)</li>
                <li>และผล Hb Typing เป็น <strong>A2A โดยมีค่า Hb A2 &le; 3.5%</strong> (แยก α-thal 1 ออกจาก α-thal 2 / IDA)</li>
                <li>หรือผล Hb Typing เป็น <strong>EA โดยมี Hb E &lt; 25%</strong></li>
              </ul>
            </div>
          </div>
        )}

        {/* Section: 3 Severe Target Diseases & Couple Risk Rules */}
        {(activeCategory === 'all' || activeCategory === 'couples') && (
          <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>3 โรคธาลัสซีเมียชนิดรุนแรงตามนโยบายควบคุม (Severe Target Diseases)</span>
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              {/* Disease 1 */}
              <div className="p-3 rounded-lg bg-rose-50/70 border border-rose-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-rose-950">
                  <span>1. โรคฮีโมโกลบินบาร์ท ฮัยดรอปส์ ฟิทัลลิส (Hb Bart’s Hydrops Fetalis)</span>
                  <span className="text-[10px] bg-rose-200 text-rose-900 px-1.5 py-0.5 rounded">
                    เสี่ยง 25%
                  </span>
                </div>
                <div className="text-[11px] text-rose-900 font-semibold">
                  คู่เสี่ยง: บิดาพาหะ α-thal 1 (--/αα) &times; มารดาพาหะ α-thal 1 (--/αα)
                </div>
                <p className="text-[11px] text-slate-600">
                  ผลกระทบ: ขาดจีนอัลฟ่าทั้ง 4 ยีน (--/--) ทารกบวมน้ำ ซีดรุนแรง เสียชีวิตในครรภ์หรือหลังคลอดไม่กี่นาที มารดามีความเสี่ยงต่อภาวะครรภ์เป็นพิษรุนแรง (Preeclampsia / Mirror Syndrome)
                </p>
              </div>

              {/* Disease 2 */}
              <div className="p-3 rounded-lg bg-amber-50/70 border border-amber-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-amber-950">
                  <span>2. โรคเบต้า-ธาลัสซีเมีย ชนิดโฮโมไซกัส (Homozygous β-thalassemia)</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">
                    เสี่ยง 25%
                  </span>
                </div>
                <div className="text-[11px] text-amber-900 font-semibold">
                  คู่เสี่ยง: บิดาพาหะ β-thal trait (&beta;0/&beta;) &times; มารดาพาหะ β-thal trait (&beta;0/&beta;)
                </div>
                <p className="text-[11px] text-slate-600">
                  ผลกระทบ: จีโนไทป์ &beta;0/&beta;0 ทารกแรกเกิดปกติ แต่เริ่มซีดรุนแรงเมื่ออายุ 3–6 เดือน ม้ามโต ตับโต ใบหน้าเปลี่ยนรูป ต้องได้รับเลือดและยาขับเหล็กตลอดชีวิต
                </p>
              </div>

              {/* Disease 3 */}
              <div className="p-3 rounded-lg bg-indigo-50/70 border border-indigo-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-indigo-950">
                  <span>3. โรคเบต้า-ธาลัสซีเมีย / ฮีโมโกลบิน อี (&beta;-thalassemia / Hb E)</span>
                  <span className="text-[10px] bg-indigo-200 text-indigo-900 px-1.5 py-0.5 rounded">
                    เสี่ยง 25%
                  </span>
                </div>
                <div className="text-[11px] text-indigo-900 font-semibold">
                  คู่เสี่ยง: ฝ่ายหนึ่งพาหะ &beta;-thal trait &times; อีกฝ่ายเป็นพาหะ Hb E (EA) หรือ Homozygous Hb E (EE)
                </div>
                <p className="text-[11px] text-slate-600">
                  ผลกระทบ: จีโนไทป์ &beta;0/&beta;E หรือ &beta;+/&beta;E ความรุนแรงหลากหลายตั้งแต่ซีดปานกลางจนถึงซีดมาก พบบ่อยที่สุดในประเทศไทยโดยเฉพาะภาคตะวันออกเฉียงเหนือ
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section: Nurse Decision Rule Checklist */}
        <div className="p-3 rounded-xl bg-gradient-to-r from-blue-900 to-indigo-950 text-white text-xs space-y-2">
          <div className="font-bold text-sky-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Checklist ตัดสินใจทางคลินิกสำหรับพยาบาล ANC</span>
          </div>
          <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-200 leading-relaxed pl-0.5">
            <li>หากฝ่ายหญิง MCV &lt; 80 หรือ OF/DCIP บวก &rarr; <strong>ต้องตามสามีมาเจาะเลือดทันที (อย่ารอฝากครรภ์ครั้งถัดไป)</strong></li>
            <li>หากผลคัดกรองเบื้องต้นผิดปกติทั้งคู่ &rarr; <strong>ห้ามสรุปว่าปลอดภัยเด็ดขาด ต้องส่ง Hb Typing และ/หรือ PCR α-thal 1 เสมอ</strong></li>
            <li>ฝ่ายหญิงเป็น EA และสามีมี MCV &lt; 80 (A2 ปกติ) &rarr; <strong>ต้องส่ง PCR α-thal 1 ทั้งคู่</strong> เพราะฝ่ายหญิงอาจมี α-thal 1 แอบแฝง</li>
            <li>วินิจฉัยก่อนคลอด (PND) ควรทำก่อน <strong>GA &le; 16–20 สัปดาห์</strong> เพื่อวางแผนยุติการตั้งครรภ์หรือดูแลอย่างปลอดภัยตามความต้องการของบิดามารดา</li>
          </ol>
        </div>

      </div>

      {/* Footer / Quick Status */}
      <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 flex-shrink-0">
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
          พร้อมใช้งานประกอบการแปลผล
        </span>
        <button
          onClick={() => {
            const guideText = `เกณฑ์อ้างอิงธาลัสซีเมีย:
• MCV < 80 fL หรือ MCH < 27 pg = ผิดปกติ
• A2A (Hb A2 > 3.5%) = พาหะ β-thalassemia
• A2A (Hb A2 <= 3.5%, MCV < 80) = สงสัยพาหะ α-thal 1 (ส่ง PCR)
• EA (Hb E 25-35%) = พาหะ Hb E
• EE (Hb E > 80%, A 0%) = Homozygous Hb E
• EF (E เด่น, F 10-40%, A 0%) = โรค β0-thal/Hb E`;
            handleCopy(guideText, 'full_summary');
          }}
          className="text-pink-600 hover:text-pink-700 font-medium flex items-center gap-1 transition"
        >
          {copiedKey === 'full_summary' ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-emerald-600">คัดลอกแล้ว</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>คัดลอกเกณฑ์สรุปย่อ</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
};
