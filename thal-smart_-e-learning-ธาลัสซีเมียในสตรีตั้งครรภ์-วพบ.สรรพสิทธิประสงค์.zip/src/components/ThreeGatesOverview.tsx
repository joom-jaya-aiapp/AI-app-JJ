import React, { useState } from 'react';
import { 
  HeartHandshake, 
  Baby, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Stethoscope, 
  HelpCircle,
  Activity,
  FileSpreadsheet
} from 'lucide-react';
import { GateType, StudentProfile, QuizResult, QuickCheckResult } from '../types';
import { LearningRoadmap } from './LearningRoadmap';
import { QuickCheckSection } from './QuickCheckSection';

interface ThreeGatesOverviewProps {
  onNavigateToModule: (moduleId: string) => void;
  student?: StudentProfile;
  completedCases?: Record<string, { completed: boolean; score: number }>;
  quizResult?: QuizResult | null;
  quickCheckResults?: Record<string, QuickCheckResult>;
  onCompleteQuickCheck?: (result: QuickCheckResult) => void;
}

export const ThreeGatesOverview: React.FC<ThreeGatesOverviewProps> = ({ 
  onNavigateToModule,
  student,
  completedCases,
  quizResult,
  quickCheckResults,
  onCompleteQuickCheck,
}) => {
  const [selectedGate, setSelectedGate] = useState<GateType>('gate1_match');

  const gates = [
    {
      id: 'gate1_match' as GateType,
      gateNumber: 1,
      name: 'เลือกคู่',
      tagline: 'การตรวจคัดกรองพาหะและการวางแผนก่อนตั้งครรภ์',
      englishTitle: 'Gate 1: Carrier Screening & Mate Selection',
      color: 'pink',
      gradient: 'from-pink-500 to-rose-600',
      lightBg: 'bg-pink-50',
      borderColor: 'border-pink-300',
      badgeBg: 'bg-pink-100 text-pink-700',
      icon: HeartHandshake,
      stage: 'ก่อนแต่งงาน / ก่อนตั้งครรภ์ / ฝากครรภ์ครั้งแรก (First ANC)',
      mission: 'ค้นหาและประเมิน "คู่เสี่ยงสูง" ต่อโรคธาลัสซีเมียชนิดรุนแรง 3 โรค โดยตรวจคู่สมรสควบคู่เสมอ',
      coreActions: [
        'ตรวจคัดกรองด้วย MCV (< 80 fL) หรือ MCH (< 27 pg)',
        'ตรวจคัดกรอง Unstable Hb ด้วย DCIP test หรือ Hb E screen',
        'หากผลคัดกรองเป็นบวก ส่งตรวจยืนยันด้วย Hb Typing (HPLC/CE)',
        'ตรวจ PCR for α-thalassemia 1 ในรายที่ MCV < 80 fL แต่ Hb typing A2A ปกติ',
        'คำนวณความเสี่ยงด้วยตารางพันธุศาสตร์ (Punnett Square)',
      ],
      severePairs: [
        { name: 'Hb Bart’s hydrops', risk: 'α-thal 1 trait + α-thal 1 trait (ลูกเสี่ยง 25%)' },
        { name: 'Homozygous β-thal', risk: 'β-thal trait + β-thal trait (ลูกเสี่ยง 25%)' },
        { name: 'β-thal / Hb E', risk: 'β-thal trait + Hb E trait/EE (ลูกเสี่ยง 25-50%)' },
      ],
    },
    {
      id: 'gate2_pregnancy' as GateType,
      gateNumber: 2,
      name: 'เลือกครรภ์',
      tagline: 'การตรวจวินิจฉัยก่อนคลอดและการตัดสินใจของครอบครัว',
      englishTitle: 'Gate 2: Prenatal Diagnosis & Pregnancy Choices',
      color: 'sky',
      gradient: 'from-sky-500 to-blue-600',
      lightBg: 'bg-sky-50',
      borderColor: 'border-sky-300',
      badgeBg: 'bg-sky-100 text-sky-700',
      icon: Baby,
      stage: 'ไตรมาสที่ 1 และ 2 ของการตั้งครรภ์ (GA 9 - 22 สัปดาห์)',
      mission: 'วินิจฉัยทารกในครรภ์ของคู่เสี่ยงสูง และให้คำปรึกษาทางพันธุศาสตร์อย่างไม่ชี้นำและเห็นอกเห็นใจ',
      coreActions: [
        'เลือกหัตถการ PND เหมาะสมกับอายุครรภ์: CVS (9-12 wks), Amniocentesis (16-18 wks), Cordocentesis (18-22 wks)',
        'อัลตราซาวด์ติดตามอาการบวมน้ำและรกหนา (Serial US > 20 wks ในคู่เสี่ยง Bart’s)',
        'แจ้งผลพร้อมกันทั้งสามีและภรรยาในห้องที่เป็นส่วนตัว',
        'ให้เวลาคู่สมรสอยู่ตามลำพังเพื่อประคับประคองจิตใจ',
        'คลายความรู้สึกผิด: "ไม่ใช่ความผิดของฝ่ายใด แต่เป็นความผันแปรทางธรรมชาติ"',
        'ให้ทางเลือก: ยุติการตั้งครรภ์อย่างปลอดภัย หรือ ตั้งครรภ์ต่อภายใต้การดูแล',
      ],
      severePairs: [
        { name: 'CVS (9-12 สัปดาห์)', risk: 'DNA analysis, เสี่ยงแท้ง 3-5%' },
        { name: 'Amniocentesis (16-18 สัปดาห์)', risk: 'DNA analysis, ปลอดภัยสูง แท้งเพียง 0.3-0.5%' },
        { name: 'Cordocentesis (18-22 สัปดาห์)', risk: 'Hb typing (HPLC), ทราบผลเร็ว เสี่ยงแท้ง 2-3%' },
      ],
    },
    {
      id: 'gate3_birth' as GateType,
      gateNumber: 3,
      name: 'เลือกคลอด',
      tagline: 'การพยาบาลสูติกรรมและการจัดการภาวะแทรกซ้อน',
      englishTitle: 'Gate 3: Intrapartum & Postpartum Nursing Care',
      color: 'indigo',
      gradient: 'from-indigo-600 to-blue-900',
      lightBg: 'bg-indigo-50',
      borderColor: 'border-indigo-300',
      badgeBg: 'bg-indigo-100 text-indigo-700',
      icon: ShieldCheck,
      stage: 'ระยะตั้งครรภ์ ไตรมาส 3 &bull; ระยะเจ็บครรภ์คลอด &bull; ระยะหลังคลอด',
      mission: 'ดูแลมารดาโรคธาลัสซีเมียและทารก ป้องกันภาวะหัวใจล้มเหลวและการตกเลือดหลังคลอด (PPH)',
      coreActions: [
        'ควบคุมระดับ Hb ให้อยู่ที่ไม่ต่ำกว่า 7-8 g/dL (ให้ PRC เมื่อมีข้อบ่งชี้)',
        'ให้ Folic acid 5 mg/day ช่วยสร้างเม็ดเลือดแดง',
        'หลีกเลี่ยงการให้ยาธาตุเหล็กและอาหารเครื่องในสัตว์ (ระวัง Iron Overload)',
        'หยุดยาขับธาตุเหล็ก Desferrioxamine ในไตรมาสแรก (พิจารณา T2-3 ถ้า Ferritin > 1,000 mcg/L)',
        'ระยะคลอด: จัดท่านอนศีรษะสูงหรือตะแคงซ้ายศีรษะสูง ลดการใช้ออกซิเจนและภาระหัวใจ',
        'ระยะหลังคลอด: ป้องกันและเฝ้าระวัง PPH อย่างเข้มงวด (ความทนต่อการเสียเลือดต่ำมาก)',
        'ส่งเสริมการเลี้ยงลูกด้วยนมแม่ (ไม่ติดต่อทางน้ำนม) และวางแผนคุมกำเนิด',
      ],
      severePairs: [
        { name: 'เป้าหมายระดับ Hb', risk: 'ไม่ต่ำกว่า 7 - 8 g/dL ตลอดการตั้งครรภ์' },
        { name: 'ท่านอนในห้องคลอด', risk: 'Semi-Fowler หรือ Left-lateral with head up' },
        { name: 'ความเสี่ยงชีวิตอันดับ 1', risk: 'การตกเลือดหลังคลอด (PPH) และภาวะหัวใจล้มเหลว' },
      ],
    },
  ];

  const currentGateData = gates.find((g) => g.id === selectedGate)!;

  return (
    <div className="space-y-6">
      {/* Visual Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold mb-3">
            <span>The 3 Clinical Decision Gates Model</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
            กรอบแนวคิด 3 ประตูการตัดสินใจทางคลินิก
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            หัวใจสำคัญในการป้องกันและควบคุมโรคโลหิตจางธาลัสซีเมียในสตรีตั้งครรภ์สำหรับนักศึกษาพยาบาลศาสตร์ วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ เชื่อมโยงกระบวนการตัดสินใจอย่างเป็นระบบตั้งแต่ระยะก่อนตั้งครรภ์จนถึงหลังคลอด
          </p>
        </div>
        <div className="absolute right-0 top-0 w-96 h-full opacity-10 bg-gradient-to-l from-pink-400 to-transparent pointer-events-none"></div>
      </div>

      {/* Learning Roadmap Progress Visualizer */}
      <LearningRoadmap
        student={student}
        completedCases={completedCases}
        quizResult={quizResult}
        quickCheckResults={quickCheckResults}
        selectedGate={selectedGate}
        onSelectGate={(gate) => setSelectedGate(gate)}
        onNavigateToModule={onNavigateToModule}
      />

      {/* 3 Gates Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {gates.map((g) => {
          const Icon = g.icon;
          const isSelected = selectedGate === g.id;
          return (
            <button
              key={g.id}
              onClick={() => setSelectedGate(g.id)}
              className={`text-left p-5 rounded-2xl transition-all duration-200 relative overflow-hidden border-2 ${
                isSelected
                  ? `${g.borderColor} ${g.lightBg} shadow-lg ring-2 ring-pink-400/40 scale-[1.01]`
                  : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 shadow-sm'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${g.badgeBg}`}>
                  ประตูที่ {g.gateNumber}
                </span>
                <div
                  className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${g.gradient} text-white flex items-center justify-center shadow-md`}
                >
                  <Icon className="w-5 h-5" />
                </div>
              </div>

              <h3 className="text-lg font-bold text-slate-900 mb-1 flex items-center justify-between">
                <span>{g.name}</span>
                {isSelected && <CheckCircle2 className="w-4 h-4 text-pink-600" />}
              </h3>
              <p className="text-xs text-slate-500 font-medium mb-3">{g.englishTitle}</p>
              <p className="text-xs text-slate-600 leading-snug line-clamp-2">{g.tagline}</p>
            </button>
          );
        })}
      </div>

      {/* Detailed Gate Information View */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between pb-4 mb-5 border-b border-slate-200 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-xs font-semibold">
                ประตูที่ {currentGateData.gateNumber}
              </span>
              <h3 className="text-xl font-bold text-slate-900">
                แนวคิด: {currentGateData.name} ({currentGateData.englishTitle})
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              <strong>ช่วงเวลาดำเนินการ:</strong> {currentGateData.stage}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateToModule('lab')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 transition"
            >
              <FileSpreadsheet className="w-4 h-4 text-sky-600" />
              <span>ทดลอง Lab Engine</span>
            </button>
            <button
              onClick={() => onNavigateToModule('cases')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-pink-600 hover:bg-pink-700 text-white shadow-sm transition"
            >
              <span>ฝึกกรณีศึกษาที่เกี่ยวข้อง</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mission / Goal */}
        <div className="p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl border border-slate-200 mb-6">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-pink-500" />
            <span>เป้าหมายหลักของการตัดสินใจ (Core Clinical Objective)</span>
          </div>
          <p className="text-sm font-semibold text-slate-800">{currentGateData.mission}</p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Action Checklist */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>ขั้นตอนและบทบาทของพยาบาลในการตัดสินใจ</span>
            </h4>
            <div className="space-y-2">
              {currentGateData.coreActions.map((action, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-50/80 border border-slate-100 text-xs text-slate-700"
                >
                  <span className="w-5 h-5 rounded-full bg-pink-100 text-pink-700 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed font-medium">{action}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Reference Cards */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-pink-600" />
              <span>จุดเน้นสำคัญทางคลินิก (Clinical Highlights)</span>
            </h4>
            <div className="space-y-2.5">
              {currentGateData.severePairs.map((pair, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                >
                  <div className="font-bold text-slate-900 text-[13px] text-pink-900">{pair.name}</div>
                  <div className="text-slate-600 mt-1 leading-relaxed text-[11px]">{pair.risk}</div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-xs text-amber-900 mt-4">
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>คำเตือนสำคัญสำหรับนักศึกษา</span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                การไม่ปฏิบัติตามแนวทางของแต่ละประตูอย่างรอบคอบ อาจนำไปสู่การพลาดโอกาสในการตรวจวินิจฉัยทารก หรือทำให้มารดาเกิดภาวะแทรกซ้อนอันตรายถึงชีวิต เช่น ภาวะหัวใจล้มเหลว หรือตกเลือดหลังคลอด
              </p>
            </div>
          </div>
        </div>

        {/* Quick Check Quiz Section for Active Gate */}
        <div className="mt-8 pt-6 border-t border-slate-200">
          <QuickCheckSection
            moduleId={selectedGate}
            onNavigateToModule={onNavigateToModule}
            onComplete={onCompleteQuickCheck}
          />
        </div>
      </div>
    </div>
  );
};
