import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  FileText, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Calendar, 
  User, 
  Building2, 
  GraduationCap,
  Sparkles,
  Layers,
  Copy,
  Check
} from 'lucide-react';
import { StudentProfile, QuizResult } from '../types';

interface ReportDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
  quizResult: QuizResult | null;
  completedCasesCount: number;
  totalCasesScore: number;
}

export const ReportDownloadModal: React.FC<ReportDownloadModalProps> = ({
  isOpen,
  onClose,
  student,
  quizResult,
  completedCasesCount,
  totalCasesScore,
}) => {
  const [activeView, setActiveView] = useState<'both' | 'report' | 'certificate'>('both');
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const isQuizPassed = quizResult && quizResult.completed && quizResult.passed;
  const isEligibleForCertificate = isQuizPassed && completedCasesCount >= 4;
  const certNumber = `BCNSP-THAL-2026-${student.studentId.slice(-4) || '9999'}`;
  const reportNumber = `TR-2026-BCNSP-${student.studentId.slice(-4) || '9999'}`;
  
  const currentDate = quizResult?.dateCompleted || new Date().toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = () => {
    const summary = `รายงานผลการประเมินการเรียนรู้:
นักศึกษา: ${student.name} (รหัส ${student.studentId})
สถาบัน: ${student.college}
ผลการทดสอบ: ${quizResult ? `${quizResult.score}/40 (${quizResult.percentage}%) - ${quizResult.passed ? 'ผ่านเกณฑ์' : 'ไม่ผ่าน'}` : 'ยังไม่ได้ทดสอบ'}
กรณีศึกษาเสมือนจริง: ผ่าน ${completedCasesCount}/8 เคส (${totalCasesScore} คะแนน)
สถานะเกียรติบัตร: ${isEligibleForCertificate ? 'ผ่านเกณฑ์สมบูรณ์ (ได้รับเกียรติบัตร)' : 'อยู่ระหว่างสะสมผลงาน'}
วันที่ออกเอกสาร: ${currentDate}`;

    navigator.clipboard.writeText(summary);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Determine readiness level
  const getReadinessLevel = () => {
    if (!quizResult) return { title: 'อยู่ระหว่างประเมิน (In Progress)', color: 'text-slate-600 bg-slate-100 border-slate-300' };
    if (quizResult.percentage >= 85 && completedCasesCount >= 6) {
      return { title: 'ระดับดีเยี่ยม (High Distinction / Clinical Ready)', color: 'text-emerald-800 bg-emerald-100 border-emerald-300' };
    }
    if (quizResult.percentage >= 70 && completedCasesCount >= 4) {
      return { title: 'ระดับผ่านเกณฑ์มาตรฐาน (Competent)', color: 'text-sky-800 bg-sky-100 border-sky-300' };
    }
    return { title: 'ระดับควรพัฒนาเพิ่มเติม (Developing)', color: 'text-amber-800 bg-amber-100 border-amber-300' };
  };

  const readiness = getReadinessLevel();

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="relative bg-slate-100 rounded-2xl max-w-5xl w-full shadow-2xl overflow-hidden border border-slate-300 animate-in fade-in zoom-in-95 duration-200 my-4 flex flex-col max-h-[92vh]">
        
        {/* Action Header Bar (Hidden during Print) */}
        <div className="no-print bg-slate-900 text-white p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-500/30 flex items-center justify-center">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
                ดาวน์โหลดรายงานผลและเกียรติบัตร (PDF Export)
                <span className="text-[10px] bg-pink-500/30 text-pink-200 border border-pink-500/40 px-1.5 py-0.5 rounded font-medium">
                  A4 Printable
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                เอกสารบันทึกผลการประเมินสมรรถนะทางคลินิกและใบประกาศนียบัตรดิจิทัล
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* View Selector */}
            <div className="bg-slate-800 p-0.5 rounded-lg flex items-center text-xs text-slate-300">
              <button
                onClick={() => setActiveView('both')}
                className={`px-2.5 py-1 rounded-md transition ${
                  activeView === 'both' ? 'bg-pink-600 text-white font-semibold shadow-xs' : 'hover:text-white'
                }`}
              >
                ทั้งหมด (2 หน้า)
              </button>
              <button
                onClick={() => setActiveView('report')}
                className={`px-2.5 py-1 rounded-md transition ${
                  activeView === 'report' ? 'bg-pink-600 text-white font-semibold shadow-xs' : 'hover:text-white'
                }`}
              >
                รายงาน (หน้า 1)
              </button>
              <button
                onClick={() => setActiveView('certificate')}
                className={`px-2.5 py-1 rounded-md transition ${
                  activeView === 'certificate' ? 'bg-pink-600 text-white font-semibold shadow-xs' : 'hover:text-white'
                }`}
              >
                เกียรติบัตร (หน้า 2)
              </button>
            </div>

            {/* Copy Summary Button */}
            <button
              onClick={handleCopySummary}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition text-xs flex items-center gap-1"
              title="คัดลอกสรุปผลการเรียนรู้"
            >
              {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>

            {/* Print / Save as PDF Button */}
            <button
              id="btn-print-pdf-report"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold shadow transition transform hover:scale-102 active:scale-98"
            >
              <Printer className="w-4 h-4" />
              <span>พิมพ์ / บันทึกเป็น PDF</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="ปิดหน้าต่าง"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tip Banner for saving as PDF (no-print) */}
        <div className="no-print bg-amber-50 border-b border-amber-200 px-4 py-2 text-xs text-amber-900 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="font-bold bg-amber-200 text-amber-950 px-1.5 py-0.5 rounded text-[10px]">
              คำแนะนำ
            </span>
            <span className="text-[11px]">
              ในหน้าต่างสั่งพิมพ์ ให้เลือก <strong>เป้าหมาย (Destination)</strong> เป็น <strong>"Save as PDF"</strong> หรือ <strong>"บันทึกเป็น PDF"</strong> เพื่อเซฟเป็นไฟล์เอกสาร PDF ลงในเครื่องของคุณ
            </span>
          </div>
          <span className="text-[10px] text-amber-700 hidden md:inline">
            รองรับขนาดกระดาษมาตรฐาน A4
          </span>
        </div>

        {/* Scrollable Preview Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-8 bg-slate-200/70">
          
          {/* Main Printable Document Wrapper */}
          <div id="printable-analytics-report" className="space-y-8 max-w-[210mm] mx-auto">
            
            {/* ============================================================ */}
            {/* PAGE 1: STUDENT PERFORMANCE & CLINICAL COMPETENCY TRANSCRIPT */}
            {/* ============================================================ */}
            {(activeView === 'both' || activeView === 'report') && (
              <div className="bg-white rounded-xl shadow-md p-8 sm:p-10 border border-slate-300 text-slate-800 print:shadow-none print:border-none print:p-6 min-h-[297mm] flex flex-col justify-between">
                <div>
                  {/* Institutional Header */}
                  <div className="border-b-2 border-slate-800 pb-4 mb-6">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-0.5">
                          BOROMARAJONANI COLLEGE OF NURSING, SANPASITTHIPRASONG
                        </div>
                        <h1 className="text-lg sm:text-xl font-bold text-slate-900 leading-tight">
                          วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์
                        </h1>
                        <div className="text-xs text-slate-600 mt-0.5">
                          คณะพยาบาลศาสตร์ สถาบันพระบรมราชชนก กระทรวงสาธารณสุข
                        </div>
                        <div className="text-[11px] text-slate-500">
                          กลุ่มวิชาการพยาบาลมารดาทารกและการผดุงครรภ์ &bull; หลักสูตรพยาบาลศาสตรบัณฑิต
                        </div>
                      </div>

                      <div className="text-right flex-shrink-0">
                        <span className="inline-block px-2.5 py-1 rounded bg-slate-100 text-slate-700 border border-slate-300 text-[10px] font-mono font-bold">
                          {reportNumber}
                        </span>
                        <div className="text-[10px] text-slate-500 mt-1">
                          วันที่: {currentDate}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                      <div>
                        <h2 className="text-base font-bold text-pink-950">
                          ใบรายงานผลสัมฤทธิ์การเรียนรู้และสมรรถนะการตัดสินใจทางคลินิก
                        </h2>
                        <div className="text-[11px] text-slate-600">
                          (Student Learning & Clinical Decision Competency Transcript)
                        </div>
                      </div>
                      <span className={`text-xs px-2.5 py-1 rounded-full border font-bold ${readiness.color}`}>
                        {readiness.title}
                      </span>
                    </div>
                  </div>

                  {/* Student Profile Information Box */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">ชื่อ-สกุล นักศึกษา:</span>
                      <strong className="text-slate-900 text-sm">{student.name}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">รหัสนักศึกษา:</span>
                      <strong className="text-slate-900 font-mono text-sm">{student.studentId}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">รุ่นการศึกษา:</span>
                      <span className="text-slate-800 font-medium">{student.cohort}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">สถาบันการศึกษา:</span>
                      <span className="text-slate-800 font-medium">{student.college}</span>
                    </div>
                  </div>

                  {/* Summary of Performance Metrics (Key KPIs) */}
                  <div className="grid grid-cols-3 gap-3 mb-6 text-center">
                    <div className="p-3 bg-pink-50/70 border border-pink-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-pink-700 block">แบบทดสอบความรู้ 40 ข้อ</span>
                      <div className="text-2xl font-black text-pink-950 mt-0.5">
                        {quizResult ? `${quizResult.score} / 40` : '0 / 40'}
                      </div>
                      <span className={`text-[10px] font-bold ${quizResult?.passed ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {quizResult ? `${quizResult.percentage}% (${quizResult.passed ? 'ผ่านเกณฑ์' : 'ไม่ผ่าน'})` : 'ยังไม่ได้สอบ'}
                      </span>
                    </div>

                    <div className="p-3 bg-sky-50/70 border border-sky-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-sky-700 block">กรณีศึกษาเสมือนจริง</span>
                      <div className="text-2xl font-black text-sky-950 mt-0.5">
                        {completedCasesCount} / 8 <span className="text-xs font-normal text-slate-500">เคส</span>
                      </div>
                      <span className="text-[10px] font-bold text-sky-700">
                        คะแนนสะสม {totalCasesScore} คะแนน
                      </span>
                    </div>

                    <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl">
                      <span className="text-[10px] font-bold uppercase text-amber-700 block">สถานะใบประกาศนียบัตร</span>
                      <div className="text-2xl font-black text-amber-950 mt-0.5">
                        {isEligibleForCertificate ? 'อนุมัติ' : 'รอครบ'}
                      </div>
                      <span className={`text-[10px] font-bold ${isEligibleForCertificate ? 'text-emerald-700' : 'text-amber-700'}`}>
                        {isEligibleForCertificate ? 'พร้อมออกเกียรติบัตร' : 'คะแนน ≥70% & เคส ≥4'}
                      </span>
                    </div>
                  </div>

                  {/* Detailed Competency Breakdown Table */}
                  <div className="mb-6">
                    <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-pink-600" />
                      <span>การประเมินสมรรถนะรายหมวดเนื้อหา (Competency Breakdown)</span>
                    </h3>

                    <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                            <th className="p-2.5">หมวดการประเมินสมรรถนะ</th>
                            <th className="p-2.5 text-center">คะแนนที่ได้</th>
                            <th className="p-2.5 text-center">ร้อยละ (%)</th>
                            <th className="p-2.5 text-center">ระดับผลการประเมิน</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-700 text-[11px]">
                          {quizResult ? (
                            Object.entries(quizResult.categoryScores).map(([cat, score], i) => {
                              const pct = Math.round((score.correct / score.total) * 100);
                              return (
                                <tr key={i} className="hover:bg-slate-50">
                                  <td className="p-2.5 font-medium">{cat}</td>
                                  <td className="p-2.5 text-center font-semibold">{score.correct} / {score.total}</td>
                                  <td className="p-2.5 text-center font-bold">{pct}%</td>
                                  <td className="p-2.5 text-center">
                                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                      pct >= 80 
                                        ? 'bg-emerald-100 text-emerald-800' 
                                        : pct >= 70 
                                        ? 'bg-sky-100 text-sky-800' 
                                        : 'bg-rose-100 text-rose-800'
                                    }`}>
                                      {pct >= 80 ? 'ดีเยี่ยม' : pct >= 70 ? 'ผ่านเกณฑ์' : 'ควรทบทวน'}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })
                          ) : (
                            <tr>
                              <td colSpan={4} className="p-4 text-center text-slate-400">
                                ยังไม่มีข้อมูลการทำแบบทดสอบ
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Diagnostic Recommendations: Strengths & Focus Areas */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 text-xs">
                    <div className="p-3.5 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-1">
                      <span className="font-bold text-emerald-950 flex items-center gap-1 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        จุดเด่นด้านสมรรถนะ (Strengths)
                      </span>
                      <p className="text-[11px] text-slate-700 leading-relaxed">
                        {quizResult && quizResult.percentage >= 70
                          ? 'มีความเชี่ยวชาญในการแปลผลตรวจทางห้องปฏิบัติการ (MCV, MCH, DCIP, Hb Typing) และการประเมินคู่เสี่ยง 3 โรคธาลัสซีเมียชนิดรุนแรงตามแนวทางกระทรวงสาธารณสุข'
                          : 'มีความมุ่งมั่นในการเรียนรู้ผ่านบทเรียนและฝึกฝนการตัดสินใจทางคลินิกอย่างต่อเนื่อง'}
                      </p>
                    </div>

                    <div className="p-3.5 bg-amber-50/50 border border-amber-200 rounded-xl space-y-1">
                      <span className="font-bold text-amber-950 flex items-center gap-1 text-[11px]">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                        ข้อเสนอแนะเพื่อการพัฒนา (Clinical Recommendation)
                      </span>
                      <p className="text-[11px] text-slate-700 leading-relaxed">
                        {quizResult && quizResult.percentage >= 85
                          ? 'พร้อมปฏิบัติหน้าที่ในคลินิกฝากครรภ์ (ANC) และห้องคลอด (LR) สรรพสิทธิประสงค์ ในบทบาทผู้นำการแปลผลแล็บและการให้คำปรึกษาทางพันธุศาสตร์'
                          : 'แนะนำให้ทบทวนอัลกอริทึมการส่งตรวจ PCR α-thal 1 และเกณฑ์การงดให้ยาธาตุเหล็กในผู้ป่วยธาลัสซีเมียเพื่อความปลอดภัยสูงสุดของผู้รับบริการ'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Footer Signatures Area */}
                <div className="pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs">
                  <div>
                    <div className="w-36 mx-auto border-b border-slate-400 mb-1.5 h-8"></div>
                    <div className="font-bold text-slate-800">
                      (อาจารย์ผู้รับผิดชอบรายวิชา)
                    </div>
                    <div className="text-[10px] text-slate-500">
                      กลุ่มวิชาการพยาบาลมารดาทารกและการผดุงครรภ์
                    </div>
                  </div>

                  <div>
                    <div className="w-36 mx-auto border-b border-slate-400 mb-1.5 h-8"></div>
                    <div className="font-bold text-slate-800">
                      (ผู้อำนวยการวิทยาลัย)
                    </div>
                    <div className="text-[10px] text-slate-500">
                      วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================ */}
            {/* PAGE BREAK (For Clean PDF Export)                            */}
            {/* ============================================================ */}
            {activeView === 'both' && (
              <div className="page-break hidden print:block" />
            )}

            {/* ============================================================ */}
            {/* PAGE 2: OFFICIAL DIGITAL CERTIFICATE OF COMPLETION          */}
            {/* ============================================================ */}
            {(activeView === 'both' || activeView === 'certificate') && (
              <div 
                id="printable-certificate"
                className="bg-white rounded-xl shadow-md p-6 sm:p-10 border border-slate-300 text-slate-800 print:shadow-none print:border-none print:p-4 min-h-[297mm] flex flex-col justify-center"
              >
                <div className="relative border-8 border-double border-amber-600/70 p-6 sm:p-10 rounded-2xl bg-white text-center space-y-5">
                  {/* Corner Ornaments */}
                  <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-amber-600 pointer-events-none"></div>
                  <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-amber-600 pointer-events-none"></div>
                  <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-amber-600 pointer-events-none"></div>
                  <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-amber-600 pointer-events-none"></div>

                  {/* Institution Header */}
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-amber-800 font-bold mb-1">
                      BOROMARAJONANI COLLEGE OF NURSING, SANPASITTHIPRASONG
                    </div>
                    <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                      วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์
                    </h2>
                    <div className="text-xs text-slate-500 mt-0.5">
                      คณะพยาบาลศาสตร์ สถาบันพระบรมราชชนก กระทรวงสาธารณสุข
                    </div>
                  </div>

                  {/* Title Badge */}
                  <div className="py-2">
                    <span className="inline-block px-4 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-300 text-xs font-semibold uppercase tracking-wider">
                      ประกาศนียบัตรฉบับนี้ให้ไว้เพื่อแสดงว่า
                    </span>
                  </div>

                  {/* Recipient Name */}
                  <div className="space-y-1">
                    <div className="text-2xl sm:text-3xl font-extrabold text-indigo-950 font-serif">
                      {student.name}
                    </div>
                    <div className="text-xs text-slate-600">
                      รหัสนักศึกษา: <strong>{student.studentId}</strong> &bull; {student.cohort}
                    </div>
                  </div>

                  {/* Course Description */}
                  <div className="max-w-xl mx-auto text-xs sm:text-sm text-slate-700 leading-relaxed">
                    ได้ผ่านการฝึกอบรมและประเมินผลสัมฤทธิ์การตัดสินใจทางคลินิกและการพยาบาล
                    <div className="font-bold text-slate-900 text-sm sm:text-base my-1 text-pink-900">
                      "การดูแลสตรีตั้งครรภ์โรคโลหิตจางธาลัสซีเมีย: กรอบแนวคิด เลือกคู่ เลือกครรภ์ เลือกคลอด"
                    </div>
                    ผ่านเกณฑ์การแปลผลการตรวจทางห้องปฏิบัติการ กรณีศึกษาเสมือนจริง และแบบทดสอบมาตรฐาน
                    ด้วยผลการประเมินร้อยละ <strong>{quizResult?.percentage || (isEligibleForCertificate ? 85 : 0)}%</strong> {isEligibleForCertificate ? '(ผ่านเกณฑ์มาตรฐาน)' : '(อยู่ระหว่างสะสมผลงาน)'}
                  </div>

                  {/* Status if not yet eligible */}
                  {!isEligibleForCertificate && (
                    <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 max-w-md mx-auto">
                      * หมายเหตุ: เอกสารฉบับนี้เป็นรายงานความก้าวหน้าการเรียนรู้ จะสมบูรณ์เป็นเกียรติบัตรทางการเมื่อสอบผ่านเกณฑ์ร้อยละ 70 และผ่านกรณีศึกษาอย่างน้อย 4 เคส
                    </div>
                  )}

                  {/* Signatures & Gold Seal */}
                  <div className="pt-6 grid grid-cols-3 items-end text-xs text-slate-600 gap-4 border-t border-slate-200">
                    <div className="text-center">
                      <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                      <div className="font-semibold text-slate-800">อาจารย์ผู้รับผิดชอบรายวิชา</div>
                      <div className="text-[10px] text-slate-400">กลุ่มวิชาการพยาบาลมารดาทารกและการผดุงครรภ์</div>
                    </div>

                    {/* Gold Seal Centerpiece */}
                    <div className="flex flex-col items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 border-2 border-amber-600 shadow-md flex items-center justify-center text-amber-950 font-bold text-center p-1">
                        <div className="w-full h-full rounded-full border border-dashed border-amber-800 flex flex-col items-center justify-center">
                          <ShieldCheck className="w-5 h-5 text-amber-900" />
                          <span className="text-[8px] font-extrabold uppercase">BCNSP SEAL</span>
                        </div>
                      </div>
                      <span className="text-[10px] text-amber-800 font-mono mt-1">{certNumber}</span>
                    </div>

                    <div className="text-center">
                      <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                      <div className="font-semibold text-slate-800">ผู้อำนวยการวิทยาลัย</div>
                      <div className="text-[10px] text-slate-400">วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์</div>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-400 pt-2">
                    ให้ไว้ ณ วันที่ {currentDate} &bull; ตรวจสอบความถูกต้องทางระบบทะเบียนการเรียนรู้ดิจิทัล BCNSP-E-THAL
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

        {/* Footer (Hidden in Print) */}
        <div className="no-print bg-white p-3 border-t border-slate-300 flex items-center justify-between text-xs text-slate-500 flex-shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>ระบบออกเอกสารรายงานผลสัมฤทธิ์และเกียรติบัตรอิเล็กทรอนิกส์มาตรฐาน BCNSP</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold transition"
          >
            ปิด
          </button>
        </div>

      </div>
    </div>
  );
};
