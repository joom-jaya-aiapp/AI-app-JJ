import React from 'react';
import { X, UserCheck, Target, Award, Brain, Stethoscope, AlertTriangle, BookOpen } from 'lucide-react';

interface NeedsAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NeedsAnalysisModal: React.FC<NeedsAnalysisModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-pink-900 text-white p-5 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-500/30 border border-pink-400/40 flex items-center justify-center">
              <Brain className="w-5 h-5 text-pink-300" />
            </div>
            <div>
              <span className="text-xs font-semibold text-pink-300 uppercase tracking-wide">
                Pedagogical Design & Curriculum Framework
              </span>
              <h3 className="text-lg font-bold text-white">
                ผู้เรียนและการวิเคราะห์ความต้องการ (Learners & Needs Analysis)
              </h3>
              <p className="text-xs text-slate-300">
                วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ &bull; หลักสูตรพยาบาลศาสตรบัณฑิต
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-slate-700 text-sm">
          {/* Target Learners Profile */}
          <div className="bg-sky-50/70 border border-sky-200 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-sky-900 mb-2">
              <UserCheck className="w-4 h-4 text-sky-600" />
              <span>1. ข้อมูลผู้เรียนเป้าหมาย (Target Learners Profile)</span>
            </div>
            <p className="text-slate-600 text-xs leading-relaxed mb-3">
              นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4 วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์ ซึ่งกำลังเตรียมพร้อมขึ้นฝึกปฏิบัติงานในห้องคลอด (Labor Room), คลินิกฝากครรภ์ (ANC), และหอผู้ป่วยหลังคลอด (Postpartum Ward) รวมถึงการเตรียมตัวสอบขึ้นทะเบียนรับใบอนุญาตประกอบวิชาชีพการพยาบาลและการผดุงครรภ์ชั้นหนึ่ง (สภาการพยาบาล)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-2.5 rounded-lg border border-sky-100 shadow-sm">
                <span className="font-semibold text-slate-800">บริบทพื้นที่ภาคอีสาน:</span>
                <p className="text-slate-600 text-[11px] mt-0.5">
                  ความชุกของ Hb E สูงสุดในประเทศ (20-60%) ทำให้พบเคสเสี่ยงโรค β-thalassemia / Hb E สูงมากในโรงพยาบาลสรรพสิทธิประสงค์และเขตสุขภาพที่ 10
                </p>
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-sky-100 shadow-sm">
                <span className="font-semibold text-slate-800">บทบาทวิชาชีพที่คาดหวัง:</span>
                <p className="text-slate-600 text-[11px] mt-0.5">
                  พยาบาลวิชาชีพเป็นด่านแรกในการคัดกรองคู่สมรส แปลผล Lab ติดตามสามี ให้คำปรึกษา และดูแลมารดากลุ่มเสี่ยงในระยะคลอดอย่างปลอดภัย
                </p>
              </div>
            </div>
          </div>

          {/* Needs & Gap Analysis */}
          <div>
            <div className="flex items-center gap-2 font-bold text-slate-900 mb-3">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>2. การวิเคราะห์ช่องว่างการเรียนรู้และความต้องการ (Needs & Gap Analysis)</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-pink-50/60 rounded-xl border border-pink-200">
                <div className="font-bold text-pink-900 mb-1">ช่องว่างด้านความรู้ (Knowledge Gap)</div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  มักสับสนระหว่างการตรวจคัดกรองเบื้องต้น (MCV, DCIP, OF) กับการตรวจยืนยัน (Hb typing, PCR) และไม่เข้าใจความต่างระหว่างพาหะ (Carrier) กับผู้ป่วย (Disease)
                </p>
              </div>
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200">
                <div className="font-bold text-blue-900 mb-1">ช่องว่างด้านการตัดสินใจ (Decision Gap)</div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  ขาดทักษะการตัดสินใจทางคลินิกเมื่อเผชิญสถานการณ์จริง เช่น การเลือกชนิดการตรวจ PND ที่เหมาะสมกับอายุครรภ์ และการระบุ 3 โรครุนแรงเป้าหมาย
                </p>
              </div>
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200">
                <div className="font-bold text-emerald-900 mb-1">ช่องว่างด้านการสื่อสาร (Counseling Gap)</div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  ประหม่าเมื่อต้องแจ้งผลตรวจผิดปกติ และยังไม่คุ้นเคยกับการให้คำปรึกษาทางพันธุศาสตร์แบบไม่ชี้นำ (Non-directive) รวมถึงการคลายความรู้สึกผิดของผู้เป็นแม่
                </p>
              </div>
            </div>
          </div>

          {/* Core Learning Outcomes */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
              <Target className="w-4 h-4 text-pink-600" />
              <span>3. ผลลัพธ์การเรียนรู้ที่คาดหวัง (Intended Learning Outcomes - ILOs)</span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-500 mt-1.5 flex-shrink-0"></span>
                <span><strong>ILO 1 (Knowledge):</strong> อธิบายพยาธิสรีรวิทยา แบบแผนการถ่ายทอดทางพันธุกรรม และสถานการณ์ธาลัสซีเมียในไทยและอีสานได้อย่างถูกต้อง</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-sky-500 mt-1.5 flex-shrink-0"></span>
                <span><strong>ILO 2 (Lab Engine):</strong> วิเคราะห์ผลการตรวจเลือด CBC, MCV, MCH, DCIP, Hb typing และ PCR ได้อย่างแม่นยำตามเกณฑ์มาตรฐาน สธ.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0"></span>
                <span><strong>ILO 3 (3 Gates Decision):</strong> ตัดสินใจทางคลินิกในแนวคิด <em>เลือกคู่ เลือกครรภ์ และเลือกคลอด</em> ได้อย่างถูกต้องตามอายุครรภ์และพยาธิสภาพ</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 flex-shrink-0"></span>
                <span><strong>ILO 4 (Clinical Simulation):</strong> ฝึกฝนการแก้ปัญหาและให้การพยาบาลในสถานการณ์เสมือนจริง 8 กรณีศึกษา และผ่านการประเมิน 40 ข้อ</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 p-4 flex justify-end border-t border-slate-200">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gradient-to-r from-pink-600 to-sky-600 hover:from-pink-500 hover:to-sky-500 text-white rounded-lg text-xs font-semibold shadow transition"
          >
            เข้าสู่บทเรียน
          </button>
        </div>
      </div>
    </div>
  );
};
