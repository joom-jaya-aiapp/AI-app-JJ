import React from 'react';
import { 
  HeartHandshake, 
  Baby, 
  ShieldCheck, 
  Sparkles, 
  BookOpen, 
  Award, 
  Stethoscope, 
  FileSpreadsheet 
} from 'lucide-react';
import { GateType, StudentProfile, QuizResult, QuickCheckResult } from '../types';
import { CLINICAL_CASES } from '../data/cases';

export interface LearningRoadmapProps {
  student?: StudentProfile;
  completedCases?: Record<string, { completed: boolean; score: number }>;
  quizResult?: QuizResult | null;
  quickCheckResults?: Record<string, QuickCheckResult>;
  selectedGate: GateType;
  onSelectGate: (gate: GateType) => void;
  onNavigateToModule: (moduleId: string) => void;
}

interface GateRoadmapMeta {
  id: GateType;
  gateNumber: number;
  name: string;
  englishTitle: string;
  tagline: string;
  color: string;
  accentColor: string;
  icon: React.ComponentType<{ className?: string }>;
  caseIds: string[];
  keyCompetencies: string[];
}

export const LearningRoadmap: React.FC<LearningRoadmapProps> = ({
  student,
  completedCases = {},
  quizResult,
  quickCheckResults = {},
  selectedGate,
  onSelectGate,
  onNavigateToModule,
}) => {
  const gatesMeta: GateRoadmapMeta[] = [
    {
      id: 'gate1_match',
      gateNumber: 1,
      name: 'เลือกคู่ (Pair Selection)',
      englishTitle: 'Carrier Screening & Pre-conceptional Mate Selection',
      tagline: 'การคัดกรองพาหะและการวางแผนก่อนการตั้งครรภ์',
      color: 'pink',
      accentColor: 'from-pink-500 to-rose-600',
      icon: HeartHandshake,
      caseIds: ['case-1', 'case-4'],
      keyCompetencies: [
        'คัดกรอง MCV < 80 fL / DCIP (+)',
        'แปลผลยืนยัน Hb Typing (HPLC)',
        'คำนวณโอกาสเสี่ยงทางพันธุศาสตร์',
      ],
    },
    {
      id: 'gate2_pregnancy',
      gateNumber: 2,
      name: 'เลือกครรภ์ (Pregnancy Screening)',
      englishTitle: 'Prenatal Diagnosis & Family Genetic Choices',
      tagline: 'การตรวจวินิจฉัยก่อนคลอดและการตัดสินใจของครอบครัว',
      color: 'sky',
      accentColor: 'from-sky-500 to-blue-600',
      icon: Baby,
      caseIds: ['case-2', 'case-3', 'case-5'],
      keyCompetencies: [
        'เลือกหัตถการ PND ตามอายุครรภ์ (CVS/Amno/Cordo)',
        'แจ้งผลตรวจ PND ในห้องส่วนตัวอย่างเห็นอกเห็นใจ',
        'ให้คำปรึกษาทางพันธุศาสตร์อย่างไม่ชี้นำ',
      ],
    },
    {
      id: 'gate3_birth',
      gateNumber: 3,
      name: 'เลือกคลอด (Birth Planning)',
      englishTitle: 'Intrapartum & Postpartum Nursing Management',
      tagline: 'การพยาบาลสูติกรรมและการจัดการภาวะแทรกซ้อน',
      color: 'indigo',
      accentColor: 'from-indigo-600 to-blue-900',
      icon: ShieldCheck,
      caseIds: ['case-6', 'case-7', 'case-8'],
      keyCompetencies: [
        'ควบคุมระดับ Hb ≥ 7-8 g/dL (งดยาธาตุเหล็ก)',
        'จัดท่านอน Semi-Fowler ลดภาระการทำงานหัวใจ',
        'เฝ้าระวังและป้องกันการตกเลือดหลังคลอด (PPH)',
      ],
    },
  ];

  // Calculate stats for each gate
  const gateStats = gatesMeta.map((gate) => {
    const totalCases = gate.caseIds.length;
    const completedCasesInGate = gate.caseIds.filter(
      (cid) => completedCases[cid]?.completed
    ).length;

    // Quiz score for this gate
    const gateQuiz = quizResult?.gateScores?.[gate.id];
    const quizTotal = gateQuiz?.total || 0;
    const quizCorrect = gateQuiz?.correct || 0;
    const quizScorePct = quizTotal > 0 ? Math.round((quizCorrect / quizTotal) * 100) : 0;
    const isQuizTaken = !!quizResult?.completed && quizTotal > 0;

    // Cases percentage
    const caseProgressPct = totalCases > 0 ? Math.round((completedCasesInGate / totalCases) * 100) : 0;

    // Overall Gate Progress calculation
    // If quiz taken: 60% cases + 40% quiz
    // If quiz not taken: proportional to cases, capped at 80% until quiz done
    let overallProgressPct = 0;
    if (isQuizTaken) {
      overallProgressPct = Math.round(caseProgressPct * 0.6 + quizScorePct * 0.4);
    } else {
      overallProgressPct = Math.round(caseProgressPct * 0.8);
    }

    // Determine status
    // Completed if all cases done and (if quiz taken, gate quiz >= 70%) or explicitly marked
    const isExplicitlyCompleted = student?.completedGates?.includes(gate.id);
    const isCompleted =
      isExplicitlyCompleted ||
      (completedCasesInGate === totalCases && (!isQuizTaken || quizScorePct >= 70));
    
    const isStarted = completedCasesInGate > 0 || isQuizTaken || isExplicitlyCompleted;

    let status: 'completed' | 'in_progress' | 'not_started' = 'not_started';
    if (isCompleted) {
      status = 'completed';
    } else if (isStarted) {
      status = 'in_progress';
    }

    return {
      ...gate,
      totalCases,
      completedCasesInGate,
      caseProgressPct,
      isQuizTaken,
      quizCorrect,
      quizTotal,
      quizScorePct,
      overallProgressPct,
      status,
      isCompleted,
    };
  });

  // Calculate master roadmap metrics
  const totalCompletedGates = gateStats.filter((g) => g.isCompleted).length;
  const totalCompletedCases = Object.values(completedCases).filter((c) => c.completed).length;
  const totalCasesInApp = CLINICAL_CASES.length;
  const masterRoadmapPct = Math.round(
    gateStats.reduce((acc, curr) => acc + curr.overallProgressPct, 0) / gatesMeta.length
  );

  return (
    <section 
      id="learning-roadmap-visualizer"
      aria-label="แผนผังเส้นทางการเรียนรู้ 3 ประตูการตัดสินใจ"
      className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-6"
    >
      {/* Header with Title and Master Progress Summary */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200/80 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Learning Roadmap & Progress Visualizer</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>เส้นทางการเรียนรู้ 3 ประตูการตัดสินใจ</span>
            <span className="text-xs font-medium text-slate-500">
              ({student?.name || 'นักศึกษาพยาบาลศาสตร์'})
            </span>
          </h3>
          <p className="text-xs text-slate-500">
            แสดงสถานะการบรรลุสมรรถนะรายประตู: <strong>เลือกคู่ (Pair Selection)</strong> &bull; <strong>เลือกครรภ์ (Pregnancy Screening)</strong> &bull; <strong>เลือกคลอด (Birth Planning)</strong>
          </p>
        </div>

        {/* Master Roadmap Overall Gauge */}
        <div className="w-full lg:w-80 bg-slate-50/90 border border-slate-200/80 rounded-xl p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-700 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-pink-600" />
              <span>ความก้าวหน้ารวมทั้ง 3 ประตู</span>
            </span>
            <span className="font-black text-sm text-indigo-600 font-mono">
              {masterRoadmapPct}%
            </span>
          </div>

          {/* Master Progress Bar */}
          <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-pink-500 via-indigo-600 to-emerald-500 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${masterRoadmapPct}%` }}
              role="progressbar"
              aria-valuenow={masterRoadmapPct}
              aria-valuemin={0}
              aria-valuemax={100}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
            <span>
              ผ่านเกณฑ์แล้ว: <strong className="text-slate-800">{totalCompletedGates}/3</strong> ประตู
            </span>
            <span>
              กรณีศึกษา: <strong className="text-slate-800">{totalCompletedCases}/{totalCasesInApp}</strong> เคส
            </span>
          </div>
        </div>
      </div>

      {/* Quick Recommendation & Context Banner */}
      <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-pink-100 text-pink-700 flex items-center justify-center flex-shrink-0 font-bold">
            <Stethoscope className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-slate-800">คำแนะนำขั้นตอนการเรียนรู้:</span>
            <p className="text-[11px] text-slate-600 mt-0.5">
              ศึกษาตามลำดับขั้นตอน <strong>ประตู 1 (เลือกคู่)</strong> ➔ <strong>ประตู 2 (เลือกครรภ์)</strong> ➔ <strong>ประตู 3 (เลือกคลอด)</strong> เพื่อความเข้าใจในการประเมินและตัดสินใจดูแลผู้ป่วยอย่างต่อเนื่อง
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto flex-shrink-0">
          <button
            onClick={() => onNavigateToModule('lab')}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white hover:bg-sky-50 text-sky-700 border border-sky-200 shadow-2xs flex items-center gap-1.5 transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-sky-600" />
            <span>ทดลอง Lab Engine</span>
          </button>
          <button
            onClick={() => onNavigateToModule('knowledge')}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-2xs flex items-center gap-1.5 transition"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
            <span>ฐานความรู้</span>
          </button>
        </div>
      </div>
    </section>
  );
};
