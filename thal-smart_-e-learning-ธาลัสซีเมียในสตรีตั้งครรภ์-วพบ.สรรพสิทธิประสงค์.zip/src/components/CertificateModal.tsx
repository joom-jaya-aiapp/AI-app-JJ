import React, { useEffect } from 'react';
import { X, Award, Printer, Download, CheckCircle2, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentProfile, QuizResult } from '../types';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
  quizResult: QuizResult | null;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  student,
  quizResult,
}) => {
  useEffect(() => {
    if (isOpen) {
      // Fire celebratory confetti!
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#ec4899', '#38bdf8', '#6366f1', '#fbbf24'],
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const certNumber = `BCNSP-THAL-2026-${student.studentId.slice(-4) || '9999'}`;
  const currentDate = quizResult?.dateCompleted || new Date().toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="relative bg-white rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Action Header (Hidden in Print) */}
        <div className="no-print bg-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-sm">ใบประกาศนียบัตรอิเล็กทรอนิกส์ (E-Certificate)</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-pink-600 hover:bg-pink-500 text-white rounded-lg text-xs font-semibold shadow transition"
            >
              <Printer className="w-4 h-4" />
              <span>พิมพ์หรือบันทึกเป็น PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Container (A4 Printable Layout) */}
        <div id="printable-certificate" className="p-6 sm:p-10 bg-gradient-to-b from-slate-50 to-white print:p-8">
          <div className="relative border-8 border-double border-amber-600/60 p-6 sm:p-10 rounded-2xl bg-white shadow-xl text-center space-y-5">
            {/* Corner Ornaments */}
            <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-amber-600 pointer-events-none"></div>
            <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-amber-600 pointer-events-none"></div>
            <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-amber-600 pointer-events-none"></div>
            <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-amber-600 pointer-events-none"></div>

            {/* Institution Header */}
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-800 font-bold mb-1">
                BOROMARAJONANI COLLEGE OF NURSING, SANPASITTHIPRASONG
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์
              </h2>
              <div className="text-xs text-slate-500 mt-0.5">
                คณะพยาบาลศาสตร์ สถาบันพระบรมราชชนก กระทรวงสาธารณสุข
              </div>
            </div>

            {/* Title */}
            <div className="py-2">
              <span className="inline-block px-4 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-300 text-xs font-semibold uppercase tracking-wider">
                ประกาศนียบัตรฉบับนี้ให้ไว้เพื่อแสดงว่า
              </span>
            </div>

            {/* Recipient Name */}
            <div className="space-y-1">
              <div className="text-2xl sm:text-3xl font-extrabold text-indigo-950 font-serif">
                {student.name}
              </div>
              <div className="text-xs text-slate-600">
                รหัสนักศึกษา: <strong>{student.studentId}</strong> &bull; {student.cohort}
              </div>
            </div>

            {/* Course Description */}
            <div className="max-w-xl mx-auto text-xs sm:text-sm text-slate-700 leading-relaxed">
              ได้ผ่านการฝึกอบรมและประเมินผลสัมฤทธิ์การตัดสินใจทางคลินิกและการพยาบาล
              <div className="font-bold text-slate-900 text-sm sm:text-base my-1 text-pink-900">
                "การดูแลสตรีตั้งครรภ์โรคโลหิตจางธาลัสซีเมีย: กรอบแนวคิด เลือกคู่ เลือกครรภ์ เลือกคลอด"
              </div>
              ผ่านเกณฑ์การแปลผลการตรวจทางห้องปฏิบัติการ กรณีศึกษาเสมือนจริง และแบบทดสอบมาตรฐาน
              ด้วยผลการประเมินร้อยละ <strong>{quizResult?.percentage || 85}%</strong> (เกณฑ์ผ่านเกณฑ์มาตรฐาน)
            </div>

            {/* Signatures & Seal */}
            <div className="pt-6 grid grid-cols-3 items-end text-xs text-slate-600 gap-4 border-t border-slate-200">
              <div className="text-center">
                <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                <div className="font-semibold text-slate-800">อาจารย์ผู้รับผิดชอบรายวิชา</div>
                <div className="text-[10px] text-slate-400">กลุ่มวิชาการพยาบาลมารดาทารกและการผดุงครรภ์</div>
              </div>

              {/* Gold Seal Centerpiece */}
              <div className="flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 border-2 border-amber-600 shadow-md flex items-center justify-center text-amber-950 font-bold text-center p-1">
                  <div className="w-full h-full rounded-full border border-dashed border-amber-800 flex flex-col items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-amber-900" />
                    <span className="text-[8px] font-extrabold uppercase">BCNSP SEAL</span>
                  </div>
                </div>
                <span className="text-[10px] text-amber-800 font-mono mt-1">{certNumber}</span>
              </div>

              <div className="text-center">
                <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                <div className="font-semibold text-slate-800">ผู้อำนวยการวิทยาลัย</div>
                <div className="text-[10px] text-slate-400">วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์</div>
              </div>
            </div>

            <div className="text-[10px] text-slate-400 pt-2">
              ให้ไว้ ณ วันที่ {currentDate} &bull; ตรวจสอบความถูกต้องทางระบบทะเบียนการเรียนรู้ดิจิทัล
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
