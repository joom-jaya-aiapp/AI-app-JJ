import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Award,
  CheckCircle2,
  AlertCircle,
  Clock,
  LogIn,
  LogOut,
  RefreshCw,
  Trash2,
  UserPlus,
  ShieldCheck,
  FileSpreadsheet,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { User } from 'firebase/auth';
import {
  db,
  COURSE_ID,
  INSTRUCTOR_EMAIL,
  deleteLearnerRecordFromFirestore,
  fetchServerLearnerRecords,
} from '../firebase';
import { LearnerScoreRecord, StudentProfile, QuizResult } from '../types';

interface LearnerRosterViewProps {
  currentUser: User | null;
  authReady: boolean;
  onSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  student: StudentProfile;
  quizResult: QuizResult | null;
  liveQuizProgress: { answeredCount: number; correctCount: number };
  completedCasesCount: number;
  totalCasesScore: number;
  onSyncNow: () => Promise<void>;
  onOpenProfileModal: () => void;
  onGoToQuiz: () => void;
}

export const LearnerRosterView: React.FC<LearnerRosterViewProps> = ({
  currentUser,
  onSignIn,
  onSignOut,
  student,
  quizResult,
  liveQuizProgress,
  completedCasesCount,
  totalCasesScore,
  onSyncNow,
  onOpenProfileModal,
  onGoToQuiz,
}) => {
  const [firestoreRecords, setFirestoreRecords] = useState<LearnerScoreRecord[]>([]);
  const [serverRecords, setServerRecords] = useState<LearnerScoreRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'passed' | 'failed' | 'in_progress'>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const isInstructor = !currentUser || currentUser.email === INSTRUCTOR_EMAIL;

  // 1. Real-time Firestore listener for all learners in the course (works immediately for everyone)
  useEffect(() => {
    const pathForList = 'learnerScores';
    const q = query(
      collection(db, pathForList),
      where('courseId', '==', COURSE_ID)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: LearnerScoreRecord[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            uid: String(data.uid || ''),
            courseId: COURSE_ID,
            studentName: String(data.studentName || 'นักศึกษาพยาบาล'),
            studentId: String(data.studentId || '-'),
            cohort: String(data.cohort || '-'),
            college: String(data.college || 'วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์'),
            status: data.status === 'locked' ? 'locked' : 'active',
            quizCompleted: Boolean(data.quizCompleted),
            quizScore: Number(data.quizScore || 0),
            totalQuestions: Number(data.totalQuestions || 40),
            percentage: Number(data.percentage || 0),
            passed: Boolean(data.passed),
            answeredCount: Number(data.answeredCount || 0),
            completedCasesCount: Number(data.completedCasesCount || 0),
            totalCasesScore: Number(data.totalCasesScore || 0),
            dateCompleted: String(data.dateCompleted || '-'),
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          };
        });

        setFirestoreRecords(list);
        setLoading(false);
      },
      (error) => {
        console.warn('Firestore listener info:', error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // 2. Poll shared server API so students who did not sign in with Google also appear for everyone
  const loadServerRecords = React.useCallback(async () => {
    const records = await fetchServerLearnerRecords();
    setServerRecords(records);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadServerRecords();
    const interval = setInterval(loadServerRecords, 3500);
    return () => clearInterval(interval);
  }, [loadServerRecords]);

  // Build local current student record
  const localRecord: LearnerScoreRecord = {
    id: `std_${student.studentId}`,
    uid: currentUser?.uid || `student_${student.studentId}`,
    courseId: COURSE_ID,
    studentName: student.name,
    studentId: student.studentId,
    cohort: student.cohort,
    college: student.college,
    status: 'active',
    quizCompleted: Boolean(quizResult?.completed),
    quizScore: quizResult?.completed ? quizResult.score : liveQuizProgress.correctCount,
    totalQuestions: 40,
    percentage: quizResult?.completed
      ? quizResult.percentage
      : Math.round((liveQuizProgress.correctCount / 40) * 100),
    passed: quizResult?.completed ? quizResult.passed : false,
    answeredCount: quizResult?.completed ? 40 : liveQuizProgress.answeredCount,
    completedCasesCount,
    totalCasesScore,
    dateCompleted:
      quizResult?.dateCompleted ||
      new Date().toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
  };

  // Merge all records by studentId (keeping the highest/latest progress per studentId)
  const allRecords: LearnerScoreRecord[] = React.useMemo(() => {
    const byStudentId = new Map<string, LearnerScoreRecord>();

    const upsert = (rec: LearnerScoreRecord) => {
      const existing = byStudentId.get(rec.studentId);
      if (!existing) {
        byStudentId.set(rec.studentId, rec);
        return;
      }
      // Prefer the record with more answered questions or higher score or current device live state
      if (
        rec.answeredCount > existing.answeredCount ||
        rec.quizScore > existing.quizScore ||
        (rec.quizCompleted && !existing.quizCompleted)
      ) {
        byStudentId.set(rec.studentId, rec);
      }
    };

    serverRecords.forEach(upsert);
    firestoreRecords.forEach(upsert);
    upsert(localRecord);

    const merged = Array.from(byStudentId.values());
    merged.sort((a, b) => {
      if (b.quizScore !== a.quizScore) return b.quizScore - a.quizScore;
      return b.answeredCount - a.answeredCount;
    });
    return merged;
  }, [serverRecords, firestoreRecords, localRecord]);

  const filteredRecords = allRecords.filter((rec) => {
    const matchesSearch =
      rec.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.cohort.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (statusFilter === 'passed') return rec.quizCompleted && rec.passed;
    if (statusFilter === 'failed') return rec.quizCompleted && !rec.passed;
    if (statusFilter === 'in_progress') return !rec.quizCompleted;
    return true;
  });

  // Summary Statistics
  const totalLearners = allRecords.length;
  const completedExamCount = allRecords.filter((r) => r.quizCompleted).length;
  const passedCount = allRecords.filter((r) => r.quizCompleted && r.passed).length;
  const avgScore =
    totalLearners > 0
      ? (allRecords.reduce((sum, r) => sum + r.quizScore, 0) / totalLearners).toFixed(1)
      : '0.0';
  const avgPercent =
    totalLearners > 0
      ? Math.round(allRecords.reduce((sum, r) => sum + r.percentage, 0) / totalLearners)
      : 0;
  const topScore =
    totalLearners > 0 ? Math.max(...allRecords.map((r) => r.quizScore)) : 0;

  const handleManualSync = async () => {
    setSyncing(true);
    try {
      await onSyncNow();
      await loadServerRecords();
    } finally {
      setSyncing(false);
    }
  };

  const handleDeleteRecord = async (rec: LearnerScoreRecord) => {
    await deleteLearnerRecordFromFirestore(rec.id, rec.studentId);
    await loadServerRecords();
    setConfirmDeleteId(null);
  };

  // Export CSV (Excel compatible with UTF-8 BOM)
  const handleExportCSV = () => {
    const headers = [
      'ลำดับ',
      'รหัสนักศึกษา',
      'ชื่อ-สกุล',
      'ชั้นปี/รุ่น',
      'สถาบัน',
      'สถานะการสอบ',
      'จำนวนข้อที่ทำ',
      'คะแนนสอบ (เต็ม 40)',
      'คิดเป็นร้อยละ (%)',
      'ผลการประเมิน (เกณฑ์ 70%)',
      'กรณีศึกษาที่ทำ (เต็ม 8)',
      'คะแนนกรณีศึกษา',
      'วันที่บันทึกผล',
    ];

    const rows = filteredRecords.map((r, idx) => [
      idx + 1,
      `"${r.studentId.replace(/"/g, '""')}"`,
      `"${r.studentName.replace(/"/g, '""')}"`,
      `"${r.cohort.replace(/"/g, '""')}"`,
      `"${r.college.replace(/"/g, '""')}"`,
      r.quizCompleted ? 'ส่งข้อสอบแล้ว' : `กำลังทำ (${r.answeredCount}/40 ข้อ)`,
      `${r.answeredCount}/40`,
      r.quizScore,
      `${r.percentage}%`,
      r.quizCompleted ? (r.passed ? 'ผ่านเกณฑ์' : 'ไม่ผ่านเกณฑ์') : 'รอส่งข้อสอบ',
      `${r.completedCasesCount}/8`,
      r.totalCasesScore,
      `"${r.dateCompleted.replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `BCNSP_ThalSmart_Scores_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-800/40">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold mb-2">
              <Users className="w-3.5 h-3.5" />
              <span>ระบบแสดงผลคะแนนผู้เรียนทุกคนแบบเรียลไทม์ (Live All-Learners Scoreboard)</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mb-1">
              ตารางรายชื่อผู้เรียนและคะแนนแบบทดสอบ 40 ข้อของทุกคน
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              แสดงรายชื่อผู้เข้าเรียนทุกคนที่เข้าทำข้อสอบ ความคืบหน้ารายข้อ และคะแนนผลการทดสอบแบบอัตโนมัติทันทีที่ทำข้อสอบ โดยไม่ต้องล็อกอินซ้ำ พร้อมส่งออกไฟล์ตารางคะแนน (CSV / Excel)
            </p>
          </div>

          {/* Sync & Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
            <button
              onClick={onOpenProfileModal}
              className="px-3.5 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold shadow transition flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ เพิ่มผู้เรียนคนใหม่ / เปลี่ยนผู้เข้าสอบ</span>
            </button>

            <button
              onClick={handleManualSync}
              disabled={syncing}
              className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-bold shadow transition flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
              <span>รีเฟรชข้อมูลคะแนนล่าสุด</span>
            </button>

            {currentUser ? (
              <button
                onClick={onSignOut}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1"
                title="ออกจากระบบ Google"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{currentUser.displayName || currentUser.email}</span>
                <LogOut className="w-3.5 h-3.5 ml-1" />
              </button>
            ) : (
              <button
                onClick={onSignIn}
                className="px-3 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5 text-sky-400" />
                <span>เชื่อมต่อบัญชีอาจารย์ (Google)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4 Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block">
              ผู้เรียนที่เข้าทำทั้งหมด
            </span>
            <div className="text-2xl font-extrabold text-slate-900 mt-1">
              {totalLearners} <span className="text-xs font-semibold text-slate-500">คน</span>
            </div>
            <span className="text-[11px] text-sky-600 font-medium">
              ส่งข้อสอบครบแล้ว {completedExamCount} คน
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-sky-50 border border-sky-200 text-sky-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block">
              สอบผ่านเกณฑ์ (&ge; 70%)
            </span>
            <div className="text-2xl font-extrabold text-emerald-600 mt-1">
              {passedCount} <span className="text-xs font-semibold text-slate-500">คน</span>
            </div>
            <span className="text-[11px] text-emerald-700 font-medium">
              เกณฑ์ผ่าน 28 / 40 คะแนนขึ้นไป
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block">
              คะแนนเฉลี่ยของทุกคน
            </span>
            <div className="text-2xl font-extrabold text-indigo-600 mt-1">
              {avgScore} <span className="text-xs font-semibold text-slate-500">/ 40 ({avgPercent}%)</span>
            </div>
            <span className="text-[11px] text-slate-500">
              จากแบบทดสอบมาตรฐาน 40 ข้อ
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block">
              คะแนนสูงสุด (Top Score)
            </span>
            <div className="text-2xl font-extrabold text-pink-600 mt-1">
              {topScore} <span className="text-xs font-semibold text-slate-500">/ 40 ข้อ</span>
            </div>
            <span className="text-[11px] text-pink-600 font-medium">
              คิดเป็น {Math.round((topScore / 40) * 100)}%
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-pink-50 border border-pink-200 text-pink-600 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search, Filter & Actions Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ค้นหาชื่อ-สกุล, รหัสนักศึกษา หรือรุ่นชั้นปี..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-pink-500"
          />
        </div>

        {/* Status Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {[
            { id: 'all', label: `ทุกคน (${allRecords.length})` },
            {
              id: 'passed',
              label: `ผ่านเกณฑ์ (${allRecords.filter((r) => r.quizCompleted && r.passed).length})`,
            },
            {
              id: 'failed',
              label: `ยังไม่ผ่าน (${allRecords.filter((r) => r.quizCompleted && !r.passed).length})`,
            },
            {
              id: 'in_progress',
              label: `กำลังทำข้อสอบ (${allRecords.filter((r) => !r.quizCompleted).length})`,
            },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as typeof statusFilter)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                statusFilter === tab.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>ดาวน์โหลดคะแนนทุกคน (CSV / Excel)</span>
          </button>
        </div>
      </div>

      {/* Learner Roster Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <span>รายชื่อผู้เข้าสอบและคะแนนของทุกคน</span>
              {loading && (
                <span className="text-[11px] text-sky-600 font-normal animate-pulse">
                  กำลังซิงค์ข้อมูลล่าสุด...
                </span>
              )}
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              แสดงข้อมูลผู้เรียนทั้งหมด {filteredRecords.length} คน (เรียงลำดับตามคะแนนสอบ)
            </p>
          </div>

          <button
            onClick={onGoToQuiz}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>ไปหน้าข้อสอบ 40 ข้อ</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-4 w-12 text-center">ลำดับ</th>
                <th className="py-3 px-4">รหัสนักศึกษา</th>
                <th className="py-3 px-4">ชื่อ - สกุล</th>
                <th className="py-3 px-4">ชั้นปี / รุ่น</th>
                <th className="py-3 px-4">ความคืบหน้าข้อสอบ</th>
                <th className="py-3 px-4">คะแนนสอบ (เต็ม 40)</th>
                <th className="py-3 px-4">ผลการประเมิน</th>
                <th className="py-3 px-4">กรณีศึกษา</th>
                <th className="py-3 px-4">วันที่บันทึก</th>
                {isInstructor && <th className="py-3 px-4 text-right">จัดการ</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td
                    colSpan={isInstructor ? 10 : 9}
                    className="py-10 text-center text-slate-400"
                  >
                    ไม่พบรายชื่อผู้เรียนที่ตรงกับเงื่อนไขการค้นหา
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec, idx) => {
                  const isCurrentDeviceUser = rec.studentId === student.studentId;

                  return (
                    <tr
                      key={rec.studentId}
                      className={`hover:bg-slate-50/80 transition ${
                        isCurrentDeviceUser ? 'bg-pink-50/30' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4 text-center font-bold text-slate-500">
                        {idx + 1}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                        {rec.studentId}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{rec.studentName}</span>
                          {isCurrentDeviceUser && (
                            <span className="px-1.5 py-0.5 text-[10px] rounded bg-pink-100 text-pink-700 font-semibold">
                              ผู้เรียนปัจจุบัน
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400">{rec.college}</div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{rec.cohort}</td>
                      <td className="py-3.5 px-4">
                        {rec.quizCompleted ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>ทำครบ 40/40 ข้อ</span>
                          </span>
                        ) : rec.answeredCount > 0 ? (
                          <span className="inline-flex items-center gap-1 text-amber-700 font-semibold">
                            <Clock className="w-3.5 h-3.5 text-amber-500" />
                            <span>ทำแล้ว {rec.answeredCount}/40 ข้อ</span>
                          </span>
                        ) : (
                          <span className="text-slate-400">เข้าเรียนแล้ว (0/40 ข้อ)</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-extrabold text-sm text-slate-900">
                            {rec.quizScore} / 40
                          </span>
                          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                            {rec.percentage}%
                          </span>
                        </div>
                        <div className="w-28 bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1">
                          <div
                            className={`h-full rounded-full ${
                              rec.percentage >= 70
                                ? 'bg-emerald-500'
                                : rec.answeredCount > 0
                                  ? 'bg-amber-500'
                                  : 'bg-slate-300'
                            }`}
                            style={{ width: `${Math.min(100, rec.percentage)}%` }}
                          />
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        {rec.quizCompleted ? (
                          rec.passed ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>ผ่านเกณฑ์ ({rec.percentage}%)</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                              <AlertCircle className="w-3 h-3" />
                              <span>ไม่ผ่านเกณฑ์ ({rec.percentage}%)</span>
                            </span>
                          )
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3 h-3" />
                            <span>คะแนนสะสม {rec.quizScore}/40</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        {rec.completedCasesCount} / 8 เคส ({rec.totalCasesScore} คะแนน)
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">{rec.dateCompleted}</td>
                      {isInstructor && (
                        <td className="py-3.5 px-4 text-right">
                          {confirmDeleteId === rec.studentId ? (
                            <div className="inline-flex items-center gap-1">
                              <button
                                onClick={() => handleDeleteRecord(rec)}
                                className="px-2 py-1 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-500"
                              >
                                ยืนยันลบ
                              </button>
                              <button
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-2 py-1 rounded bg-slate-200 text-slate-700 text-[10px] font-semibold hover:bg-slate-300"
                              >
                                ยกเลิก
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setConfirmDeleteId(rec.studentId)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                              title="ลบรายการนี้"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
