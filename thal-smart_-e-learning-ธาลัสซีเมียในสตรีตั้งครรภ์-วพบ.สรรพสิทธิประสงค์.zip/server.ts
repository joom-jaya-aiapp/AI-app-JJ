import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_FILE = path.join(__dirname, 'learner-scores-data.json');

interface StoredLearnerRecord {
  id: string;
  uid: string;
  courseId: 'bcnsp-thal-smart';
  studentName: string;
  studentId: string;
  cohort: string;
  college: string;
  status: 'active' | 'locked';
  quizCompleted: boolean;
  quizScore: number;
  totalQuestions: number;
  percentage: number;
  passed: boolean;
  answeredCount: number;
  completedCasesCount: number;
  totalCasesScore: number;
  dateCompleted: string;
  updatedAtIso: string;
}

function readScoresFromDisk(): StoredLearnerRecord[] {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return [];
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to read learner-scores-data.json:', err);
    return [];
  }
}

function writeScoresToDisk(records: StoredLearnerRecord[]): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write learner-scores-data.json:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '100kb' }));

  // GET all learner scores
  app.get('/api/learner-scores', (_req, res) => {
    const records = readScoresFromDisk();
    res.json({ records });
  });

  // POST upsert a learner score by studentId
  app.post('/api/learner-scores', (req, res) => {
    const body = req.body || {};
    const rawStudentId = String(body.studentId || '').replace(/[^a-zA-Z0-9_\-]/g, '').slice(0, 40);
    if (!rawStudentId) {
      res.status(400).json({ error: 'Invalid studentId' });
      return;
    }

    const studentName = String(body.studentName || 'นักศึกษาพยาบาล').trim().slice(0, 120) || 'นักศึกษาพยาบาล';
    const cohort = String(body.cohort || 'นักศึกษาพยาบาลศาสตร์ชั้นปีที่ 4').trim().slice(0, 120);
    const college =
      String(body.college || 'วิทยาลัยพยาบาลบรมราชชนนี สรรพสิทธิประสงค์').trim().slice(0, 150);
    const uid = String(body.uid || `student_${rawStudentId}`).replace(/[^a-zA-Z0-9_\-]/g, '').slice(0, 128);
    const quizCompleted = Boolean(body.quizCompleted);
    const quizScore = Math.max(0, Math.min(40, Math.round(Number(body.quizScore) || 0)));
    const totalQuestions = 40;
    const answeredCount = Math.max(0, Math.min(40, Math.round(Number(body.answeredCount) || 0)));
    const percentage = Math.max(
      0,
      Math.min(100, Math.round(Number(body.percentage ?? (quizScore / 40) * 100) || 0))
    );
    const passed = quizCompleted ? percentage >= 70 : false;
    const completedCasesCount = Math.max(
      0,
      Math.min(8, Math.round(Number(body.completedCasesCount) || 0))
    );
    const totalCasesScore = Math.max(
      0,
      Math.min(200, Math.round(Number(body.totalCasesScore) || 0))
    );
    const dateCompleted =
      String(
        body.dateCompleted ||
          new Date().toLocaleDateString('th-TH', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })
      )
        .trim()
        .slice(0, 80);

    const records = readScoresFromDisk();
    const recordId = `std_${rawStudentId}`;
    const existingIdx = records.findIndex((r) => r.studentId === rawStudentId || r.id === recordId);

    const newRecord: StoredLearnerRecord = {
      id: recordId,
      uid,
      courseId: 'bcnsp-thal-smart',
      studentName,
      studentId: rawStudentId,
      cohort,
      college,
      status: 'active',
      quizCompleted,
      quizScore,
      totalQuestions,
      percentage,
      passed,
      answeredCount,
      completedCasesCount,
      totalCasesScore,
      dateCompleted,
      updatedAtIso: new Date().toISOString(),
    };

    if (existingIdx >= 0) {
      records[existingIdx] = newRecord;
    } else {
      records.push(newRecord);
    }

    writeScoresToDisk(records);
    res.json({ ok: true, record: newRecord, records });
  });

  // DELETE a learner score by studentId or id
  app.delete('/api/learner-scores/:id', (req, res) => {
    const target = String(req.params.id || '').trim();
    const records = readScoresFromDisk();
    const filtered = records.filter((r) => r.id !== target && r.studentId !== target);
    writeScoresToDisk(filtered);
    res.json({ ok: true, records: filtered });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
