/**
 * Firestore Security Rules Test Specification (Dirty Dozen Verification)
 * Verifies that all 12 adversarial payloads in security_spec.md return PERMISSION_DENIED.
 */

export interface DirtyDozenTestCase {
  id: number;
  name: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  auth: {
    uid: string;
    email: string;
    email_verified: boolean;
  } | null;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_TESTS: DirtyDozenTestCase[] = [
  {
    id: 1,
    name: 'Identity Spoofing on Create (uid mismatch)',
    operation: 'create',
    path: '/learnerScores/victim_6611400088',
    auth: { uid: 'attacker_1', email: 'attacker@example.com', email_verified: true },
    payload: {
      uid: 'victim_1',
      courseId: 'bcnsp-thal-smart',
      studentName: 'Attacker',
      studentId: '6611400088',
      cohort: 'Year 4',
      college: 'BCNSP',
      status: 'active',
      quizCompleted: true,
      quizScore: 40,
      totalQuestions: 40,
      percentage: 100,
      passed: true,
      answeredCount: 40,
      completedCasesCount: 4,
      totalCasesScore: 80,
      dateCompleted: '2026-10-01',
      createdAt: 'REQUEST_TIME',
      updatedAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Unverified Email Spoof Attack on Admin',
    operation: 'delete',
    path: '/learnerScores/student1_6611400088',
    auth: { uid: 'spoof_admin', email: 'sunanthajaya23@gmail.com', email_verified: false },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Shadow/Ghost Field Injection on Create',
    operation: 'create',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      uid: 'user1',
      courseId: 'bcnsp-thal-smart',
      studentName: 'Student One',
      studentId: '6611400088',
      cohort: 'Year 4',
      college: 'BCNSP',
      status: 'active',
      quizCompleted: false,
      quizScore: 0,
      totalQuestions: 40,
      percentage: 0,
      passed: false,
      answeredCount: 0,
      completedCasesCount: 0,
      totalCasesScore: 0,
      dateCompleted: '2026-10-01',
      createdAt: 'REQUEST_TIME',
      updatedAt: 'REQUEST_TIME',
      isVerifiedAdmin: true,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Shadow Field Injection on Update',
    operation: 'update',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      quizScore: 35,
      ghostField: 'injected',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Value Poisoning on Whitelisted Key (quizScore > 40)',
    operation: 'update',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      quizScore: 999,
      updatedAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Resource Poisoning (Oversized studentName > 120 chars)',
    operation: 'create',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      uid: 'user1',
      courseId: 'bcnsp-thal-smart',
      studentName: 'A'.repeat(500),
      studentId: '6611400088',
      cohort: 'Year 4',
      college: 'BCNSP',
      status: 'active',
      quizCompleted: false,
      quizScore: 0,
      totalQuestions: 40,
      percentage: 0,
      passed: false,
      answeredCount: 0,
      completedCasesCount: 0,
      totalCasesScore: 0,
      dateCompleted: '2026-10-01',
      createdAt: 'REQUEST_TIME',
      updatedAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Path ID Poisoning (Invalid characters in recordId)',
    operation: 'create',
    path: '/learnerScores/bad$id!@#',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Timestamp Forgery on Create (createdAt != request.time)',
    operation: 'create',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      createdAt: '2020-01-01T00:00:00Z',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Immortal Field Mutation on Update (changing createdAt or uid)',
    operation: 'update',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      uid: 'another_user',
      updatedAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Terminal State Bypass (updating when status == locked)',
    operation: 'update',
    path: '/learnerScores/user1_6611400088',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      quizScore: 40,
      updatedAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Self-Assigned Admin Role Creation',
    operation: 'create',
    path: '/admins/user1',
    auth: { uid: 'user1', email: 'user1@example.com', email_verified: true },
    payload: {
      uid: 'user1',
      role: 'instructor',
      createdAt: 'REQUEST_TIME',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Unauthenticated List Scraping',
    operation: 'list',
    path: '/learnerScores',
    auth: null,
    expectedResult: 'PERMISSION_DENIED',
  },
];
