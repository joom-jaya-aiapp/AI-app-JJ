# Security Specification (Phase 0: Payload-First Security TDD)

## 1. Data Invariants
1. **Default Deny:** Any path not explicitly matched (`/learnerScores/{recordId}`, `/admins/{adminUid}`) is denied for all reads and writes.
2. **Verified Authentication Required:** All reads and writes require `request.auth != null && request.auth.token.email_verified == true`.
3. **Identity Integrity (`LearnerScore`):**
   - `data.uid` MUST equal `request.auth.uid` on creation and cannot be mutated on update (`incoming().uid == existing().uid`).
   - `recordId` path variable MUST match `^[a-zA-Z0-9_\-]+$` with length 1..128.
4. **Schema & Boundary Integrity (`LearnerScore`):**
   - Exact key allowlist (`hasAll` and `hasOnly`) with zero ghost/shadow fields permitted.
   - All string fields (`uid`, `courseId`, `studentName`, `studentId`, `cohort`, `college`, `status`, `dateCompleted`) must enforce strict `.size()` bounds.
   - `courseId` must equal `'bcnsp-thal-smart'`.
   - `status` must be in `['active', 'locked']`. Learners can only create with `status == 'active'`.
   - `quizScore` and `answeredCount` must be `int` in `[0, 40]`. `totalQuestions` must equal `40`. `percentage` must be `int` in `[0, 100]`.
5. **Temporal Integrity:**
   - On `create`: `incoming().createdAt == request.time && incoming().updatedAt == request.time`.
   - On `update`: `incoming().createdAt == existing().createdAt && incoming().updatedAt == request.time`.
6. **Terminal State Locking:**
   - Once `existing().status == 'locked'`, no learner update is permitted (`existing().status != 'locked' || isAdmin()`).
7. **Query Enforcer & Cost-Optimized List:**
   - `allow list` on `/learnerScores/{recordId}` must evaluate `existing().uid == request.auth.uid || existing().courseId == 'bcnsp-thal-smart'` without any `get()` or `exists()` calls.
8. **Admin Isolation:**
   - Only bootstrapped verified admin (`sunanthajaya23@gmail.com` with `email_verified == true`) or existing document in `/admins/{uid}` is recognized as `isAdmin()`.

## 2. The "Dirty Dozen" Payloads

1. **Payload 1 (Identity Spoofing on Create):** `uid: "victim-uid"` when `request.auth.uid == "attacker-uid"`.
2. **Payload 2 (Unverified Email Spoof Attack):** `request.auth.token.email == "sunanthajaya23@gmail.com"` with `email_verified: false`.
3. **Payload 3 (Shadow/Ghost Field Injection on Create):** Valid `LearnerScore` payload plus `"isAdmin": true`.
4. **Payload 4 (Shadow/Ghost Field Injection on Update):** Updating `quizScore` plus an unauthorized field `"hacked": "yes"`.
5. **Payload 5 (Value Poisoning on Whitelisted Key):** Updating `quizScore` to `9999` (out of range `0..40`) or a string `"40"`.
6. **Payload 6 (Resource Poisoning / Oversized String):** Setting `studentName` to a 5,000-character string (`> 120`).
7. **Payload 7 (Path ID Poisoning):** Creating a document at `/learnerScores/invalid$id!with@spaces`.
8. **Payload 8 (Timestamp Forgery on Create):** Setting `createdAt` to a past/future client timestamp (`!= request.time`).
9. **Payload 9 (Immortal Field Mutation on Update):** Attempting to mutate `createdAt`, `uid`, or `courseId` during an update.
10. **Payload 10 (Terminal State Bypass):** Learner attempting to update `quizScore` when `existing().status == 'locked'`.
11. **Payload 11 (Self-Assigned Admin Role):** Non-admin user attempting to create `/admins/attacker-uid`.
12. **Payload 12 (Unscoped List Scraping):** Listing `/learnerScores` without matching `courseId == 'bcnsp-thal-smart'` or `uid == request.auth.uid`.
